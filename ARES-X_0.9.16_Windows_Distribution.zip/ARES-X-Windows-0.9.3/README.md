# ARES-X 0.9.16 — Windows Distribution

ARES-X by N2MDX is an experimental Windows amateur-radio digital-mode and station-tools application.

**Start here:** read `ARES-X_USER_INSTRUCTIONS.txt` or `ARES-X_USER_GUIDE.pdf`.

This ZIP contains source code and a Windows build script, not a prebuilt installer. On Windows 10/11, install 64-bit Python 3.11, extract the package, and run `build_windows.bat`. Launch the built application from `dist\\ARES-X\\ARES-X.exe`.

The instructions cover CAT setup, VAC audio, WSJT-X UDP integration, X-TRACKER, spectrum/waterfall, transmit safety, troubleshooting, and known limitations.

Important: ARES-X is experimental. WSJT-X performs FT4/FT8 decoding and modulation. A 48 kHz VAC stream provides a 0–24 kHz one-sided audio spectrum; the 16,384-point FFT does not create a 192 kHz RF/IQ span. Review the complete user guide before connecting a radio or using any reply/transmit control.
