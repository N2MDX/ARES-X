"""Native Yaesu FTDX10 CAT driver based on Yaesu CAT Operation Reference Manual.
Uses Enhanced COM for CAT frequency/mode control. TX Standard COM/PTT is intentionally
not asserted as implemented in this release.
"""
from __future__ import annotations
import threading, time

MODE_NAMES = {
    "1":"LSB", "2":"USB", "3":"CWU", "4":"FM", "5":"AM",
    "6":"RTTY", "7":"CWL", "8":"DATA-L", "9":"RTTY-U",
    "A":"DATA-FM", "B":"FM-N", "C":"DATA-U", "D":"AM-N",
    "E":"PSK", "F":"DATA-FM-N"
}

class YaesuFTDX10CAT:
    def __init__(self, port: str, baudrate: int = 38400, on_update=None, on_error=None):
        self.port=port; self.baudrate=int(baudrate)
        self.on_update=on_update; self.on_error=on_error
        self._serial=None; self._thread=None; self._stop=threading.Event()
        self._io_lock=threading.RLock()
        self.frequency_hz=None; self.mode=None; self.mode_code=None

    @staticmethod
    def available_ports():
        try:
            from serial.tools import list_ports
            return [p.device for p in list_ports.comports()]
        except Exception:
            return []

    def connect(self):
        try:
            import serial
        except ImportError as exc:
            raise RuntimeError("pyserial is missing. Install requirements.txt.") from exc
        if self._serial:
            self.disconnect()
        # Yaesu CAT port: 8 data bits, no parity, 2 stop bits; no hardware flow control.
        self._serial=serial.Serial(
            self.port, self.baudrate, bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_TWO,
            timeout=0.25, write_timeout=1.0,
            xonxoff=False, rtscts=False, dsrdtr=False
        )
        self._stop.clear()
        # Verify the correct radio/profile/COM port before reporting connected.
        fa=self._query("FA")
        md=self._query("MD0")
        self.frequency_hz=self._parse_frequency(fa)
        self.mode_code=self._parse_mode(md)
        if self.frequency_hz is None or self.mode_code is None:
            self._serial.close(); self._serial=None
            raise RuntimeError(
                "No valid FTDX10 CAT response. Check Enhanced COM port, CAT RATE, "
                "CAT TIME OUT TIMER, and that no other program is using the port."
            )
        self.mode=MODE_NAMES.get(self.mode_code, "MD"+self.mode_code)
        self._thread=threading.Thread(target=self._poll, daemon=True)
        self._thread.start()

    def _query(self, command):
        with self._io_lock:
            if not self._serial or not self._serial.is_open:
                raise RuntimeError("FTDX10 CAT port is closed.")
            self._serial.reset_input_buffer()
            self._serial.write((command+";").encode("ascii"))
            self._serial.flush()
            deadline=time.monotonic()+1.5
            data=bytearray()
            while time.monotonic()<deadline:
                b=self._serial.read(1)
                if b == b";":
                    break
                if b:
                    data.extend(b)
            return data.decode("ascii","ignore").strip()

    @staticmethod
    def _parse_frequency(reply):
        m=__import__("re").search(r"FA(\d{9})", reply or "")
        if not m:
            return None
        value=int(m.group(1))
        return value if 30000 <= value <= 75000000 else None

    @staticmethod
    def _parse_mode(reply):
        m=__import__("re").search(r"MD0([1-9A-F])", (reply or "").upper())
        return m.group(1) if m else None

    def _poll(self):
        while not self._stop.is_set():
            try:
                f=self._parse_frequency(self._query("FA"))
                m=self._parse_mode(self._query("MD0"))
                if f is not None: self.frequency_hz=f
                if m is not None:
                    self.mode_code=m
                    self.mode=MODE_NAMES.get(m, "MD"+m)
                if self.on_update:
                    self.on_update(self.frequency_hz, self.mode)
                self._stop.wait(0.5)
            except Exception as exc:
                if self.on_error: self.on_error(str(exc))
                self._stop.wait(1.0)

    def set_frequency(self, frequency_hz: int):
        frequency_hz=int(frequency_hz)
        if not 30000 <= frequency_hz <= 75000000:
            raise ValueError("FTDX10 frequency must be between 30 kHz and 75 MHz.")
        self._query(f"FA{frequency_hz:09d}")
        self.frequency_hz=frequency_hz

    def set_mode(self, mode: str):
        codes={"LSB":"1","USB":"2","CWU":"3","FM":"4","AM":"5",
               "RTTY":"6","CWL":"7","DATA-L":"8","RTTY-U":"9",
               "DATA-FM":"A","FM-N":"B","DATA-U":"C","AM-N":"D",
               "PSK":"E","DATA-FM-N":"F"}
        key=str(mode).upper()
        if key not in codes:
            raise ValueError("Unsupported FTDX10 mode: "+key)
        self._query("MD0"+codes[key])
        self.mode_code=codes[key]
        self.mode=MODE_NAMES[codes[key]]

    def disconnect(self):
        self._stop.set()
        thread=self._thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=1.0)
        with self._io_lock:
            ser=self._serial
            self._serial=None
            if ser:
                try: ser.close()
                except Exception: pass
