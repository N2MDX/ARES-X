ARES-X 0.9.16 WINDOWS DISTRIBUTION

Start with ARES-X_USER_INSTRUCTIONS.txt or ARES-X_USER_GUIDE.pdf.
This package is source + build script, not a prebuilt installer.
Extract the ZIP, install 64-bit Python 3.11, run build_windows.bat,
then launch dist\ARES-X\ARES-X.exe.

Review the safety notes before using any reply/transmit function.
73 DE N2MDX
