from __future__ import annotations
import threading
import os, queue, ctypes
import time, wave, json, urllib.request, urllib.parse, webbrowser, datetime, sys, math, sqlite3
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, colorchooser

import numpy as np
from PIL import Image, ImageDraw, ImageTk
import ares_x_ax1_v02 as ax

APP_VERSION = "0.9.16 Distribution"
from thetis_cat import ThetisCAT
from yaesu_ftdx10_cat import YaesuFTDX10CAT
from wsjtx_bridge import WSJTXBridge

class AresXApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"ARES-X by N2MDX — {APP_VERSION}")
        self.geometry("1440x900")
        self.minsize(1100, 720)
        # Start maximized on Windows so controls and tables are not clipped.
        try:
            self.state("zoomed")
        except tk.TclError:
            pass
        self.configure(bg="#07111e")
        self.withdraw()
        self._startup_splash = None
        self._startup_progress = 0
        self._startup_display_progress = 0.0
        self._show_startup_splash()
        self.last_wave = None
        self.audio_stream = None
        self.audio_thread = None
        self.recording = False
        self.rx_buffer = np.zeros(0, dtype=np.float32)
        # Bundled Natural Earth world geography; no internet connection required.
        self.world_geo_data = {"land_polygons": [], "country_lines": []}
        self._hf_sun_photo = None
        self._hf_map_photo = None
        self._hf_earth_base = None
        self._hf_solar_asset = None
        try:
            # PyInstaller stores bundled data under sys._MEIPASS. When running
            # from source, load the same file relative to this script.
            bundle_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
            geo_path = bundle_root / "assets" / "world_map.json"
            if not geo_path.is_file():
                geo_path = Path(__file__).resolve().parent / "assets" / "world_map.json"
            with geo_path.open("r", encoding="utf-8") as geo_file:
                self.world_geo_data = json.load(geo_file)
            if not self.world_geo_data.get("land_polygons"):
                raise ValueError("World map data file loaded but contains no land polygons")
            print(f"Loaded world map data: {len(self.world_geo_data['land_polygons'])} land polygons")
        except Exception as exc:
            print(f"World map data could not be loaded: {exc}")
            self.world_geo_data = {"land_polygons": [], "country_lines": []}
        self._startup_update(18, "LOADING RADIO MAP DATA")
        self._hf_sun_photo = None
        self._hf_map_photo = None
        self._hf_earth_base = None
        self._hf_solar_asset = None
        self.world_atlas = {"countries": [], "cities": []}
        try:
            bundle_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
            atlas_path = bundle_root / "assets" / "world_atlas.json"
            if not atlas_path.is_file():
                atlas_path = Path(__file__).resolve().parent / "assets" / "world_atlas.json"
            with atlas_path.open("r", encoding="utf-8") as atlas_file:
                self.world_atlas = json.load(atlas_file)
            print(f"Loaded atlas: {len(self.world_atlas.get('countries', []))} countries/territories, {len(self.world_atlas.get('cities', []))} cities")
        except Exception as exc:
            print(f"Detailed atlas unavailable; using legacy map: {exc}")
        try:
            asset_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / "assets"
            if not (asset_root / "earth_base.png").is_file():
                asset_root = Path(__file__).resolve().parent / "assets"
            self._hf_earth_base = Image.open(asset_root / "earth_base.png").convert("RGB")
            self._hf_solar_asset = Image.open(asset_root / "solar_disc.png").convert("RGBA")
        except Exception as exc:
            print(f"HF dashboard artwork unavailable; using vector fallback: {exc}")

        self._startup_update(32, "INITIALIZING PROPAGATION DATA")
        self.map_zoom = 1.0
        self.map_pan_x = 0.0
        self.map_pan_y = 0.0
        self.map_language = tk.StringVar(value="English")
        self.map_drag_anchor = None
        self.map_continent_colors = {
            "North America": "#245b78", "South America": "#28705e",
            "Europe": "#725b91", "Africa": "#967044",
            "Asia": "#8a5665", "Oceania": "#547b85", "Other": "#345568"
        }
        self.map_country_labels = [
            (-98,39,"United States","Estados Unidos","États-Unis","Vereinigte Staaten"),
            (-102,23,"Mexico","México","Mexique","Mexiko"),
            (-75, -10,"Brazil","Brasil","Brésil","Brasilien"),
            (-71,-35,"Argentina","Argentina","Argentine","Argentinien"),
            (-102,57,"Canada","Canadá","Canada","Kanada"),
            (-3,55,"United Kingdom","Reino Unido","Royaume-Uni","Vereinigtes Königreich"),
            (10,51,"Germany","Alemania","Allemagne","Deutschland"),
            (2,47,"France","Francia","France","Frankreich"),
            (25,39,"Turkey","Turquía","Turquie","Türkei"),
            (20,0,"Democratic Republic of the Congo","República Democrática del Congo","République démocratique du Congo","Demokratische Republik Kongo"),
            (20,-29,"South Africa","Sudáfrica","Afrique du Sud","Südafrika"),
            (18, -1,"Republic of the Congo","República del Congo","République du Congo","Republik Kongo"),
            (30,27,"Egypt","Egipto","Égypte","Ägypten"),
            (35,39,"Saudi Arabia","Arabia Saudita","Arabie saoudite","Saudi-Arabien"),
            (78,22,"India","India","Inde","Indien"),
            (105,35,"China","China","Chine","China"),
            (138,37,"Japan","Japón","Japon","Japan"),
            (134,-25,"Australia","Australia","Australie","Australien"),
            (122,-5,"Indonesia","Indonesia","Indonésie","Indonesien"),
            (45,24,"Iran","Irán","Iran","Iran"),
            (30,49,"Ukraine","Ucrania","Ukraine","Ukraine"),
            (24,56,"Sweden","Suecia","Suède","Schweden"),
            (8,47,"Switzerland","Suiza","Suisse","Schweiz"),
            (12,42,"Italy","Italia","Italie","Italien"),
            (-4,40,"Spain","España","Espagne","Spanien"),
            (32,1,"Uganda","Uganda","Ouganda","Uganda"),
            (29,-3,"Rwanda","Ruanda","Rwanda","Ruanda"),
            (47,-19,"Madagascar","Madagascar","Madagascar","Madagaskar"),
            (90,24,"Bangladesh","Bangladés","Bangladesh","Bangladesch"),
            (103,46,"Mongolia","Mongolia","Mongolie","Mongolei"),
        ]
        self.map_city_labels = [
            (-74.0,40.7,"New York"),(-118.2,34.1,"Los Angeles"),(-87.6,41.9,"Chicago"),
            (-99.1,19.4,"Mexico City"),(-46.6,-23.5,"São Paulo"),(-58.4,-34.6,"Buenos Aires"),
            (-0.1,51.5,"London"),(2.35,48.86,"Paris"),(13.4,52.5,"Berlin"),
            (12.5,41.9,"Rome"),(37.6,55.8,"Moscow"),(28.0,-26.2,"Johannesburg"),
            (31.2,30.0,"Cairo"),(3.4,6.5,"Lagos"),(36.8,-1.3,"Nairobi"),
            (72.9,19.1,"Mumbai"),(77.2,28.6,"New Delhi"),(116.4,39.9,"Beijing"),
            (121.5,31.2,"Shanghai"),(139.7,35.7,"Tokyo"),(126.98,37.56,"Seoul"),
            (103.8,1.35,"Singapore"),(151.2,-33.9,"Sydney"),(144.96,-37.8,"Melbourne"),
            (28.0,-26.2,"Johannesburg"),(-99.1,19.4,"Mexico City"),(-43.2,-22.9,"Rio de Janeiro"),
            (18.4,-33.9,"Cape Town"),(55.3,25.2,"Dubai"),(10.0,56.0,"Copenhagen"),
            (4.9,52.4,"Amsterdam"),(-3.7,40.4,"Madrid"),(30.5,50.45,"Kyiv"),
        ]
        self.last_decode_key = None
        self.cat = None
        self.cat_connected = False
        import threading
        self._cw_stop_event = threading.Event()
        self._cw_serial = None
        self._cw_rx_stream = None
        self._cw_rx_thread = None
        self._cw_rx_stop = threading.Event()
        self._cw_rx_queue = queue.Queue()
        self._cw_rx_active = False
        self._startup_update(45, "INITIALIZING RADIO AND DIGITAL ENGINES")
        self._cw_rx_text = ""
        self._cw_rx_symbols = ""
        self._cw_rx_last_edge = None
        self._cw_rx_key_state = False
        self._cw_rx_signal_floor = 0.0015
        self._cw_live_frequency = None
        # Initialize before the bridge button can be pressed.
        self.wsjtx_bridge = None
        self.station_rows = {}
        self.worked_stations = {}
        self.logbook_path = Path.home() / ".ares_x_logbook.sqlite3"
        self.logbook_db = sqlite3.connect(str(self.logbook_path))
        self.logbook_db.row_factory = sqlite3.Row
        self._init_logbook_db()
        self.logbook_selected_id = None
        self.worked_window = None
        self.worked_tree = None
        self.audio_devices = []
        self.latest_audio_block = np.zeros(0, dtype=np.float32)
        self.audio_sample_rate = None
        self.audio_level = tk.StringVar(value="Audio: —")
        self.settings_path = Path.home() / ".ares_x_settings.json"
        self.saved_settings = self._load_settings()
        self.wsjtx_host=tk.StringVar(value=self.saved_settings.get("wsjtx_host", "127.0.0.1"))
        self.wsjtx_port=tk.StringVar(value=str(self.saved_settings.get("wsjtx_port", "2237")))
        self._style()
        self._startup_update(58, "BUILDING ARES-X WORKSPACE")
        self._build()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._startup_update(96, "FINALIZING USER INTERFACE")
        self._finish_startup_splash()
        self._log("ARES-X AX-1 audio lab initialized.")
        self._log("Receive/decode from WAV and optional live audio input are available.")
        self._log("FT4/FT8 reply control is routed through WSJT-X; verify rig PTT and VAC setup before any on-air use.")

    def _show_startup_splash(self):
        """Display the branded startup artwork while ARES-X initializes."""
        try:
            asset_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / "assets"
            splash_path = asset_root / "ares_x_splash.png"
            if not splash_path.is_file():
                splash_path = Path(__file__).resolve().parent / "assets" / "ares_x_splash.png"
            source = Image.open(splash_path).convert("RGB")
            sw, sh = source.size
            max_w, max_h = 1120, 630
            scale = min(max_w / sw, max_h / sh)
            self._splash_w, self._splash_h = int(sw * scale), int(sh * scale)
            self._splash_photo = ImageTk.PhotoImage(source.resize((self._splash_w, self._splash_h), Image.Resampling.LANCZOS))
            splash = tk.Toplevel(self)
            self._startup_splash = splash
            splash.overrideredirect(True)
            splash.configure(bg="#020914")
            # Place the splash on the monitor where the user launched ARES-X
            # (normally the monitor containing the mouse after double-clicking
            # the EXE in Explorer), including monitors left/above the primary.
            left, top, right, bottom = 0, 0, splash.winfo_screenwidth(), splash.winfo_screenheight()
            if sys.platform == "win32":
                try:
                    class POINT(ctypes.Structure):
                        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
                    class RECT(ctypes.Structure):
                        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                                    ("right", ctypes.c_long), ("bottom", ctypes.c_long)]
                    class MONITORINFO(ctypes.Structure):
                        _fields_ = [("cbSize", ctypes.c_ulong), ("rcMonitor", RECT),
                                    ("rcWork", RECT), ("dwFlags", ctypes.c_ulong)]
                    point = POINT()
                    ctypes.windll.user32.GetCursorPos(ctypes.byref(point))
                    monitor = ctypes.windll.user32.MonitorFromPoint(point, 2)  # nearest monitor
                    info = MONITORINFO()
                    info.cbSize = ctypes.sizeof(MONITORINFO)
                    if monitor and ctypes.windll.user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
                        left, top = info.rcMonitor.left, info.rcMonitor.top
                        right, bottom = info.rcMonitor.right, info.rcMonitor.bottom
                except Exception as monitor_exc:
                    print(f"Could not identify launch monitor; using primary display: {monitor_exc}")
            x = left + max(0, (right - left - self._splash_w) // 2)
            y = top + max(0, (bottom - top - self._splash_h) // 2)
            splash.geometry(f"{self._splash_w}x{self._splash_h}{x:+d}{y:+d}")
            canvas = tk.Canvas(splash, width=self._splash_w, height=self._splash_h,
                               bg="#020914", highlightthickness=0)
            canvas.pack(fill="both", expand=True)
            canvas.create_image(0, 0, image=self._splash_photo, anchor="nw")
            # Cover the artwork's static progress graphic with a live progress bar.
            bx0, bx1 = int(self._splash_w * .222), int(self._splash_w * .778)
            by0, by1 = int(self._splash_h * .755), int(self._splash_h * .805)
            canvas.create_rectangle(bx0, by0, bx1, by1, fill="#020b18", outline="#b9eaff", width=2)
            self._splash_bar = canvas.create_rectangle(bx0 + 5, by0 + 5, bx0 + 5, by1 - 5,
                                                       fill="#00cfff", outline="")
            self._splash_bar_bounds = (bx0, bx1, by0, by1)
            self._splash_status = canvas.create_text(self._splash_w / 2, int(self._splash_h * .845),
                text="STARTING ARES-X...", fill="#e7f7ff", font=("Segoe UI", 12, "bold"),
                anchor="center")
            splash.update_idletasks()
            splash.update()
        except Exception as exc:
            print(f"Startup splash unavailable: {exc}")
            self._startup_splash = None

    def _startup_update(self, percent, status):
        """Smoothly animate the bar to each completed startup milestone."""
        self._startup_progress = max(self._startup_progress, min(99, int(percent)))
        splash = self._startup_splash
        if splash is None:
            return
        try:
            canvas = splash.winfo_children()[0]
            bx0, bx1, by0, by1 = self._splash_bar_bounds
            start = float(self._startup_display_progress)
            target = float(self._startup_progress)
            # A short eased animation prevents the bar racing through milestones.
            duration = 0.70
            began = time.perf_counter()
            while True:
                elapsed = time.perf_counter() - began
                t = min(1.0, elapsed / duration)
                eased = 1.0 - (1.0 - t) ** 3
                shown = start + (target - start) * eased
                right = bx0 + 5 + (bx1 - bx0 - 10) * shown / 100.0
                canvas.coords(self._splash_bar, bx0 + 5, by0 + 5, right, by1 - 5)
                canvas.itemconfigure(self._splash_status, text=f"{status}  •  {int(shown)}%")
                splash.update_idletasks()
                splash.update()
                if t >= 1.0:
                    break
                time.sleep(0.015)
            self._startup_display_progress = target
        except Exception as exc:
            print(f"Startup progress update skipped: {exc}")

    def _finish_startup_splash(self):
        splash = self._startup_splash
        if splash is not None:
            try:
                # Finish with a brief smooth final fill instead of an instant jump.
                self._startup_progress = 100
                canvas = splash.winfo_children()[0]
                bx0, bx1, by0, by1 = self._splash_bar_bounds
                start = float(self._startup_display_progress)
                began = time.perf_counter()
                duration = 0.45
                while True:
                    t = min(1.0, (time.perf_counter() - began) / duration)
                    eased = 1.0 - (1.0 - t) ** 3
                    shown = start + (100.0 - start) * eased
                    right = bx0 + 5 + (bx1 - bx0 - 10) * shown / 100.0
                    canvas.coords(self._splash_bar, bx0 + 5, by0 + 5, right, by1 - 5)
                    canvas.itemconfigure(self._splash_status, text=f"ARES-X READY — {int(shown)}%")
                    splash.update_idletasks()
                    splash.update()
                    if t >= 1.0:
                        break
                    time.sleep(0.015)
                self._startup_display_progress = 100.0
                splash.after(350, splash.destroy)
            except Exception:
                try: splash.destroy()
                except Exception: pass
        self.deiconify()
        try: self.state("zoomed")
        except tk.TclError: pass

    def _on_close(self):
        self._save_settings()
        try:
            if hasattr(self,"logbook_db"):
                self.logbook_db.commit()
                self.logbook_db.close()
        except Exception:
            pass
        try:
            if self.cat_connected and self.cat:
                self.cat.disconnect()
        except Exception:
            pass
        self.destroy()

    def _load_settings(self):
        try:
            data=json.loads(self.settings_path.read_text(encoding="utf-8"))
            return data if isinstance(data,dict) else {}
        except Exception:
            return {}

    def _save_settings(self):
        try:
            self.settings_path.write_text(json.dumps({
                "callsign": self.lookup_call.get().strip().upper() if hasattr(self,"lookup_call") else "",
                "locator": self.lookup_grid.get().strip().upper() if hasattr(self,"lookup_grid") else "",
                "band": self.band_choice.get() if hasattr(self,"band_choice") else "20 m — FT8 14.074 MHz",
                "radio_model": self.radio_model.get() if hasattr(self,"radio_model") else self.saved_settings.get("radio_model", "Thetis / Hermes / ANAN"),
                "com_port": self.com_port.get() if hasattr(self,"com_port") else self.saved_settings.get("com_port", "COM3"),
                "baud": self.baud.get() if hasattr(self,"baud") else self.saved_settings.get("baud", "9600"),
                "audio_device": self.audio_device.get() if hasattr(self,"audio_device") else self.saved_settings.get("audio_device", "Default input"),
                "wsjtx_host": self.wsjtx_host.get() if hasattr(self,"wsjtx_host") else self.saved_settings.get("wsjtx_host", "127.0.0.1"),
                "wsjtx_port": self.wsjtx_port.get() if hasattr(self,"wsjtx_port") else self.saved_settings.get("wsjtx_port", "2237"),
                "waterfall_palette": self.waterfall_palette.get() if hasattr(self,"waterfall_palette") else self.saved_settings.get("waterfall_palette", "Classic"),
                "waterfall_custom_colors": getattr(self, "waterfall_custom_colors", self.saved_settings.get("waterfall_custom_colors", ["#000018", "#00bec0", "#fffff5"])),
                "cw_mode": self.cw_mode.get() if hasattr(self,"cw_mode") else self.saved_settings.get("cw_mode","CWU"),
                "cw_method": self.cw_method.get() if hasattr(self,"cw_method") else self.saved_settings.get("cw_method","VAC AUDIO"),
                "cw_wpm": self.cw_wpm.get() if hasattr(self,"cw_wpm") else self.saved_settings.get("cw_wpm",20),
                "cw_tone": self.cw_tone.get() if hasattr(self,"cw_tone") else self.saved_settings.get("cw_tone",700),
                "cw_key_port": self.cw_key_port.get() if hasattr(self,"cw_key_port") else self.saved_settings.get("cw_key_port","COM4"),
                "cw_skimmer_path": self.cw_skimmer_path.get() if hasattr(self,"cw_skimmer_path") else self.saved_settings.get("cw_skimmer_path",""),
                "cw_audio_output": self.cw_audio_output.get() if hasattr(self,"cw_audio_output") else self.saved_settings.get("cw_audio_output","Default output"),
            }, indent=2), encoding="utf-8")
        except Exception as exc:
            if hasattr(self,"_log"):
                self._log("Could not save preferences: " + str(exc))

    @staticmethod
    def _band_table():
        # Common FT8 dial frequencies; 60 m is region/channel restricted.
        return [("160 m",1_840_000),("80 m",3_573_000),("60 m",5_357_000),
                ("40 m",7_074_000),("30 m",10_136_000),("20 m",14_074_000),
                ("17 m",18_100_000),("15 m",21_074_000),("12 m",24_915_000),
                ("10 m",28_074_000),("6 m",50_313_000)]

    @classmethod
    def _band_choices(cls):
        return [f"{name} — FT8 {freq/1e6:.3f} MHz" for name,freq in cls._band_table()]

    def tune_selected_band(self):
        choice=self.band_choice.get()
        try:
            name=choice.split(" — ",1)[0]
            freq=dict(self._band_table())[name]
        except Exception:
            messagebox.showwarning("Band selection","Choose a valid band first."); return
        if not self.cat_connected or not self.cat:
            messagebox.showwarning("Radio not connected","Connect Thetis CAT first. The band selection has not changed your radio.")
            return
        try:
            self.cat.set_frequency(freq)
            self._save_settings()
            self._log(f"Requested {name} FT8 dial frequency {freq/1e6:.3f} MHz through Thetis CAT. WSJT-X should follow if it is configured to control the same rig.")
        except Exception as exc:
            messagebox.showerror("Band tuning failed",str(exc))
            self._log("Band tune failed: " + str(exc))

    def _tune_clicked_propagation_band(self, _event=None):
        selected=self.band_tree.selection()
        if not selected: return
        band=self.band_tree.item(selected[0],"values")[0]
        for choice in self._band_choices():
            if choice.startswith(band + " — "):
                self.band_choice.set(choice)
                self.tune_selected_band()
                return

    def _draw_activity_bar(self, canvas, label, color, active):
        canvas.delete("all")
        width=max(canvas.winfo_width(),220)
        height=25
        canvas.create_rectangle(0,0,width,height,fill="#10283d",outline="#24435b")
        pad=4; gap=3; label_w=150
        segments=18
        available=max(1,width-label_w-pad*2)
        seg_w=max(2,(available-gap*(segments-1))/segments)
        for i in range(segments):
            x=pad+label_w+i*(seg_w+gap)
            lit=active and i < segments
            canvas.create_rectangle(x,5,x+seg_w,height-5,fill=color if lit else "#1b2b3a",outline="")
        suffix="ACTIVE" if active else "STANDBY"
        canvas.create_text(8,height/2,anchor="w",text=f"{label}  •  {suffix}",fill=color if active else "#9db2c5",font=("Segoe UI",9,"bold"))

    def _set_rx_activity(self, active):
        active = bool(active)
        if getattr(self, "_rx_active", False) == active:
            return
        self._rx_active = active
        self._draw_activity_bar(self.rx_activity, "RX / DECODING", "#20df85", active)

    def _set_tx_activity(self, active):
        active = bool(active)
        if getattr(self, "_tx_active", False) == active:
            return
        self._tx_active = active
        self._draw_activity_bar(self.tx_activity, "TX / ON AIR", "#ff414d", active)

    def _style(self):
        s=ttk.Style(self)
        try: s.theme_use("clam")
        except tk.TclError: pass
        s.configure("TFrame",background="#07111e")
        s.configure("Panel.TFrame",background="#0c1b2b")
        s.configure("TLabel",background="#07111e",foreground="#e6f2ff",font=("Segoe UI",10))
        s.configure("Title.TLabel",font=("Segoe UI",24,"bold"),foreground="#f3f8ff")
        s.configure("Sub.TLabel",font=("Segoe UI",10),foreground="#43c8ff")
        s.configure("PanelTitle.TLabel",background="#0c1b2b",foreground="#63d5ff",font=("Segoe UI",11,"bold"))
        s.configure("TButton",font=("Segoe UI",10,"bold"),padding=7)
        s.configure("Accent.TButton",background="#087bdc",foreground="white")
        s.map("Accent.TButton",background=[("active","#1598ff")])
        s.configure("TEntry",fieldbackground="#10283d",foreground="#ffffff")
        s.configure("TCombobox",fieldbackground="#10283d",foreground="#ffffff")

    @staticmethod
    def _radio_models():
        # Model names are selectable profiles; the current direct CAT adapter is
        # intentionally limited to Kenwood-compatible CAT implementations.
        return ["Thetis / Hermes / ANAN", "FlexRadio (CAT compatible)",
                "Kenwood (CAT profile)", "Yaesu FTDX10", "Yaesu (other model - unsupported)",
                "Icom (CI-V adapter - planned)", "Elecraft (CAT profile)",
                "Other / Generic CAT"]


    def _build_hf_conditions_dashboard(self):
        """Three-panel live HF dashboard: band outlook, solar data, and global day/night."""
        shell=tk.Frame(self,bg="#07111e")
        shell.pack(fill="x",padx=18,pady=(0,7))
        toolbar=tk.Frame(shell,bg="#07111e")
        toolbar.pack(fill="x",pady=(0,3))
        tk.Label(toolbar,text="HF PROPAGATION DASHBOARD",bg="#07111e",fg="#63d5ff",font=("Segoe UI",8,"bold")).pack(side="left",padx=5)
        ttk.Button(toolbar,text="REFRESH",width=9,command=self.refresh_hf_conditions).pack(side="right",padx=(5,0))
        self.hf_toggle_button=ttk.Button(toolbar,text="CLOSE ▲",width=11,command=self._toggle_hf_dashboard)
        self.hf_toggle_button.pack(side="right",padx=5)
        frame=tk.Frame(shell,bg="#07111e",highlightthickness=1,highlightbackground="#1b5a79")
        frame.pack(fill="x")
        self.hf_dashboard_shell=shell
        self.hf_dashboard_frame=frame
        self.hf_dashboard_visible=True
        self.hf_dashboard_animating=False
        self.hf_dashboard_expanded_height=220
        frame.grid_columnconfigure(0,weight=44,uniform="hf_dash")
        frame.grid_columnconfigure(1,weight=27,uniform="hf_dash")
        frame.grid_columnconfigure(2,weight=29,uniform="hf_dash")
        def panel(col,title):
            box=tk.Frame(frame,bg="#081827",highlightthickness=1,highlightbackground="#173c55")
            box.grid(row=0,column=col,sticky="nsew",padx=(3,2),pady=3)
            tk.Label(box,text=title,bg="#081827",fg="#63d5ff",font=("Segoe UI",9,"bold"),anchor="w").pack(fill="x",padx=7,pady=(5,2))
            return box
        bands_panel=panel(0,"HF BAND CONDITIONS • 24-HOUR FORECAST (UTC)")
        legend=tk.Frame(bands_panel,bg="#081827"); legend.pack(fill="x",padx=7)
        for label,color in (("GOOD","#20b85a"),("FAIR","#e2bd35"),("POOR","#e36b32"),("VARIABLE","#536477")):
            tk.Label(legend,text="  ",bg=color,width=2).pack(side="left",padx=(0,3))
            tk.Label(legend,text=label,bg="#081827",fg="#b9cbd9",font=("Segoe UI",6,"bold")).pack(side="left",padx=(0,8))
        self.hf_chart=tk.Canvas(bands_panel,height=132,bg="#07111e",highlightthickness=0)
        self.hf_chart.pack(fill="both",expand=True,padx=5,pady=(0,4))
        solar_panel=panel(1,"SOLAR / GEOMAGNETIC DATA • LIVE")
        self.hf_solar_status=tk.StringVar(value="WAITING FOR SPACE-WEATHER FEEDS")
        tk.Label(solar_panel,textvariable=self.hf_solar_status,bg="#081827",fg="#ffca69",font=("Segoe UI",7,"bold")).pack(anchor="w",padx=8)
        hero=tk.Frame(solar_panel,bg="#081827"); hero.pack(fill="x",expand=True,padx=5,pady=2)
        self.hf_sun_canvas=tk.Canvas(hero,width=116,height=112,bg="#07111e",highlightthickness=0)
        self.hf_sun_canvas.pack(side="left",fill="y",padx=(1,5))
        metric_area=tk.Frame(hero,bg="#081827"); metric_area.pack(side="left",fill="both",expand=True)
        metrics=tk.Frame(metric_area,bg="#081827"); metrics.pack(fill="x",expand=True)
        self.hf_metric_vars={}
        for i,(key,label) in enumerate((("sfi","SFI"),("ssn","SUNSPOTS"),("a","A-INDEX"),("kp","KP"))):
            cell=tk.Frame(metrics,bg="#0c2032",highlightthickness=1,highlightbackground="#23607b")
            cell.grid(row=0,column=i,sticky="nsew",padx=2,pady=2)
            metrics.grid_columnconfigure(i,weight=1)
            tk.Label(cell,text=label,bg="#0c2032",fg="#8fb2c8",font=("Segoe UI",7,"bold")).pack(pady=(5,0))
            var=tk.StringVar(value="--"); self.hf_metric_vars[key]=var
            tk.Label(cell,textvariable=var,bg="#0c2032",fg="#f4dc55",font=("Segoe UI",15,"bold")).pack(pady=(0,5))
        charts=tk.Frame(metric_area,bg="#081827"); charts.pack(fill="both",expand=True,pady=(3,0))
        trend_box=tk.Frame(charts,bg="#081827"); trend_box.pack(side="left",fill="both",expand=True,padx=(0,3))
        kp_box=tk.Frame(charts,bg="#081827"); kp_box.pack(side="left",fill="both",expand=True,padx=(3,0))
        tk.Label(trend_box,text="SOLAR FLUX TREND (72H)",bg="#081827",fg="#8fb2c8",font=("Segoe UI",7,"bold")).pack(anchor="w")
        self.hf_sfi_chart=tk.Canvas(trend_box,height=46,bg="#07111e",highlightthickness=0)
        self.hf_sfi_chart.pack(fill="both",expand=True)
        tk.Label(kp_box,text="KP FORECAST (24H)",bg="#081827",fg="#8fb2c8",font=("Segoe UI",7,"bold")).pack(anchor="w")
        self.hf_kp_chart=tk.Canvas(kp_box,height=46,bg="#07111e",highlightthickness=0)
        self.hf_kp_chart.pack(fill="both",expand=True)
        self.hf_geo_var=tk.StringVar(value="GEOMAGNETIC: --")
        tk.Label(solar_panel,textvariable=self.hf_geo_var,bg="#081827",fg="#20df85",font=("Segoe UI",9,"bold")).pack(anchor="w",padx=8,pady=(1,5))
        self.hf_solar_history=[]
        self.hf_sun_canvas.bind("<Configure>",lambda _e:self._draw_hf_sun())
        self.hf_sfi_chart.bind("<Configure>",lambda _e:self._draw_hf_sfi_trend())
        map_panel=panel(2,"CURRENT GLOBAL CONDITIONS • DAY / NIGHT")
        map_top=tk.Frame(map_panel,bg="#081827"); map_top.pack(fill="x",padx=7)
        self.hf_map_time=tk.StringVar(value="UTC --:--")
        tk.Label(map_top,textvariable=self.hf_map_time,bg="#081827",fg="#8ba6bc",font=("Segoe UI",7)).pack(side="left")
        tk.Label(map_top,text="DAYLIGHT  •  NIGHT",bg="#081827",fg="#c4d7e8",font=("Segoe UI",7,"bold")).pack(side="right")
        self.hf_global_map=tk.Canvas(map_panel,height=132,bg="#06101d",highlightthickness=0)
        self.hf_global_map.pack(fill="both",expand=True,padx=5,pady=(0,4))
        bottom=tk.Frame(frame,bg="#07111e"); bottom.grid(row=1,column=0,columnspan=3,sticky="ew",padx=5,pady=(0,4))
        self.hf_live_status_var=tk.StringVar(value="● CONNECTING")
        self.hf_updated_var=tk.StringVar(value="LAST UPDATE: NEVER")
        tk.Label(bottom,textvariable=self.hf_live_status_var,bg="#07111e",fg="#ffca69",font=("Segoe UI",8,"bold")).pack(side="left",padx=5)
        self.hf_indices_var=tk.StringVar(value="SFI: --   SSN: --   A: --   Kp: --")
        tk.Label(bottom,textvariable=self.hf_indices_var,bg="#07111e",fg="#c4d7e8",font=("Segoe UI",8)).pack(side="left",padx=10)
        tk.Label(bottom,textvariable=self.hf_updated_var,bg="#07111e",fg="#8ba6bc",font=("Segoe UI",8)).pack(side="right",padx=8)
        self.hf_status_var=tk.StringVar(value="Estimates only — not a guarantee of propagation. Day/night map is calculated from UTC solar position.")
        tk.Label(frame,textvariable=self.hf_status_var,bg="#07111e",fg="#8ba6bc",font=("Segoe UI",7),anchor="w").grid(row=2,column=0,columnspan=3,sticky="ew",padx=8,pady=(0,4))
        self.hf_live_data=None; self.hf_kp_forecast=[]; self.hf_last_success=None; self.hf_kp_ok=False
        self.hf_chart.bind("<Configure>",lambda _e:self._draw_hf_conditions())
        self.hf_kp_chart.bind("<Configure>",lambda _e:self._draw_hf_kp_forecast())
        self.hf_global_map.bind("<Configure>",lambda _e:self._draw_hf_global_map())
        self.after(900,self.refresh_hf_conditions)
        self.after(300000,self._schedule_hf_refresh)
        self.after(60000,self._tick_hf_global_map)

    def _toggle_hf_dashboard(self):
        """Slide only the HF propagation dashboard closed/open; leave all radio panes untouched."""
        if self.hf_dashboard_animating:
            return
        frame=self.hf_dashboard_frame
        if self.hf_dashboard_visible:
            frame.update_idletasks()
            self.hf_dashboard_expanded_height=max(frame.winfo_height(),frame.winfo_reqheight(),180)
            frame.pack_propagate(False)
            self.hf_dashboard_visible=False
            self.hf_toggle_button.configure(text="OPEN ▼")
            self._animate_hf_dashboard(self.hf_dashboard_expanded_height,0,-1)
        else:
            frame.pack(fill="x")
            frame.pack_propagate(False)
            frame.configure(height=1)
            self.hf_dashboard_visible=True
            self.hf_toggle_button.configure(text="CLOSE ▲")
            self._animate_hf_dashboard(1,self.hf_dashboard_expanded_height,1)

    def _animate_hf_dashboard(self,current,target,direction):
        frame=self.hf_dashboard_frame
        if not frame.winfo_exists():
            self.hf_dashboard_animating=False
            return
        self.hf_dashboard_animating=True
        step=18
        next_height=current + direction*step
        if (direction < 0 and next_height <= target) or (direction > 0 and next_height >= target):
            next_height=target
        frame.configure(height=max(0,next_height))
        if next_height == target:
            self.hf_dashboard_animating=False
            if direction < 0:
                frame.pack_forget()
                frame.pack_propagate(True)
            else:
                frame.pack_propagate(True)
            return
        self.after(12,lambda:self._animate_hf_dashboard(next_height,target,direction))

    def _tick_hf_global_map(self):
        if not self.winfo_exists(): return
        self._draw_hf_global_map()
        self.after(60000,self._tick_hf_global_map)

    def _draw_hf_sun(self):
        c=getattr(self,"hf_sun_canvas",None)
        if c is None or not c.winfo_exists(): return
        c.delete("all"); w=max(90,c.winfo_width()); h=max(90,c.winfo_height())
        if self._hf_solar_asset is not None:
            size=max(88,min(h-12,w-8,190))
            art=self._hf_solar_asset.resize((size,size),Image.Resampling.LANCZOS)
            self._hf_sun_photo=ImageTk.PhotoImage(art)
            c.create_image(w/2,h/2-3,image=self._hf_sun_photo,anchor="center")
            c.create_text(w/2,h-2,text="SOLAR ACTIVITY",fill="#ffca69",font=("Segoe UI",6,"bold"))
            return
        cx,cy=w/2,h/2; radius=min(w,h)*.29
        for i in range(9,0,-1):
            r=radius*(1+i*.16)
            c.create_oval(cx-r,cy-r,cx+r,cy+r,fill="#%02x%02x%02x"%(int(90+i*15),int(24+i*5),int(4+i)),outline="")
        c.create_oval(cx-radius,cy-radius,cx+radius,cy+radius,fill="#ff6a12",outline="#ffc04a",width=2)
        c.create_text(cx,cy+radius+10,text="SOLAR ACTIVITY",fill="#ffca69",font=("Segoe UI",6,"bold"))

    def _draw_hf_sfi_trend(self):
        c=getattr(self,"hf_sfi_chart",None)
        if c is None or not c.winfo_exists(): return
        c.delete("all"); w=max(130,c.winfo_width()); h=max(38,c.winfo_height())
        for i in range(1,4):
            y=i*h/4; c.create_line(2,y,w-2,y,fill="#173247")
        vals=[v for _,v in getattr(self,"hf_solar_history",[]) if v>0]
        current=float((getattr(self,"hf_live_data",{}) or {}).get("solar_flux",0) or 0)
        if current>0 and (not vals or vals[-1]!=current): vals.append(current)
        if len(vals)<2:
            c.create_text(w/2,h/2,text=f"SFI {current:g}  •  HISTORY BUILDS WHILE RUNNING" if current else "WAITING FOR SOLAR HISTORY",fill="#8ba6bc",font=("Segoe UI",7))
            return
        lo=min(vals); hi=max(vals); span=max(1,hi-lo)
        pts=[]
        for i,v in enumerate(vals[-36:]):
            x=4+i*(w-8)/max(1,min(36,len(vals))-1); y=h-5-(v-lo)/span*(h-12); pts.extend((x,y))
        if len(pts)>=4:
            c.create_line(*pts,fill="#32df75",width=2,smooth=True)
            c.create_oval(pts[-2]-3,pts[-1]-3,pts[-2]+3,pts[-1]+3,fill="#d8ff68",outline="")
        c.create_text(4,3,anchor="nw",text=f"{lo:.0f}",fill="#8ba6bc",font=("Segoe UI",6))
        c.create_text(w-4,3,anchor="ne",text=f"{hi:.0f}",fill="#8ba6bc",font=("Segoe UI",6))

    def _draw_hf_kp_forecast(self):
        c=getattr(self,"hf_kp_chart",None)
        if c is None or not c.winfo_exists(): return
        c.delete("all"); w=max(180,c.winfo_width()); h=max(40,c.winfo_height())
        rows=[]
        for row in self.hf_kp_forecast:
            try:
                # NOAA's JSON endpoint may return a list-of-lists with a header row,
                # or a list of dictionaries depending on product revision.
                if isinstance(row,dict):
                    tag=row.get("time_tag") or row.get("time") or row.get("date")
                    kval=row.get("kp") or row.get("Kp")
                elif isinstance(row,(list,tuple)) and len(row)>=2:
                    if str(row[0]).lower() in ("time_tag","time","date"): continue
                    tag=row[0]; kval=row[1]
                else: continue
                stamp=datetime.datetime.fromisoformat(str(tag).replace("Z","+00:00"))
                if stamp.tzinfo is None: stamp=stamp.replace(tzinfo=datetime.timezone.utc)
                kp=float(kval)
                if math.isfinite(kp) and 0<=kp<=9: rows.append((stamp.astimezone(datetime.timezone.utc),kp))
            except Exception: pass
        now=datetime.datetime.now(datetime.timezone.utc)
        rows=sorted((r for r in rows if now-datetime.timedelta(hours=1)<=r[0]<=now+datetime.timedelta(hours=27)),key=lambda x:x[0])[:9]
        if not rows:
            c.create_text(w/2,h/2,text="NOAA Kp forecast unavailable",fill="#8ba6bc",font=("Segoe UI",8)); return
        c.create_line(4,h-14,w-4,h-14,fill="#426078")
        gap=4; bw=max(6,(w-gap*(len(rows)+1))/len(rows)); base=h-15
        for i,(stamp,kp) in enumerate(rows):
            x=gap+i*(bw+gap); bh=max(2,min(h-25,kp/9*(h-25)))
            color="#20df65" if kp<4 else ("#e2bd35" if kp<5 else ("#ed8a24" if kp<7 else "#f04438"))
            c.create_rectangle(x,base-bh,x+bw,base,fill=color,outline="")
            c.create_text(x+bw/2,max(5,base-bh-5),text=f"{kp:g}",fill="#dceaf5",font=("Segoe UI",6))
            c.create_text(x+bw/2,h-6,text=stamp.strftime("%H"),fill="#8ba6bc",font=("Segoe UI",6))

    def _draw_hf_global_map(self):
        c=getattr(self,"hf_global_map",None)
        if c is None or not c.winfo_exists(): return
        c.delete("all"); w=max(220,c.winfo_width()); h=max(85,c.winfo_height())
        now=datetime.datetime.now(datetime.timezone.utc); self.hf_map_time.set("UTC "+now.strftime("%H:%M"))
        if self._hf_earth_base is not None:
            # Render the Earth texture at the current panel size, then calculate the
            # day/night terminator from UTC solar position for every map pixel.
            mw=max(420,w*2); mh=max(180,h*2)
            base=self._hf_earth_base.resize((mw,mh),Image.Resampling.BILINEAR)
            rgb=np.asarray(base).astype(np.float32)
            lon=np.linspace(-180,180,mw,dtype=np.float32)[None,:]
            lat=np.linspace(85,-85,mh,dtype=np.float32)[:,None]
            daynum=now.timetuple().tm_yday
            gamma=2*math.pi/365.0*(daynum-1+(now.hour-12)/24+now.minute/1440)
            decl=(0.006918-0.399912*math.cos(gamma)+0.070257*math.sin(gamma)-0.006758*math.cos(2*gamma)+0.000907*math.sin(2*gamma)-0.002697*math.cos(3*gamma)+0.00148*math.sin(3*gamma))
            subsolar_lon=((12-now.hour-now.minute/60-now.second/3600)*15+180)%360-180
            hour=np.radians(lon-subsolar_lon); latr=np.radians(lat)
            cosz=np.sin(latr)*math.sin(decl)+np.cos(latr)*math.cos(decl)*np.cos(hour)
            # Smooth twilight band and deep-night dimming.
            day=np.clip((cosz+0.12)/0.24,0,1)[...,None]
            night_rgb=rgb*np.array([0.30,0.40,0.62],dtype=np.float32)
            day_rgb=rgb*np.array([1.16,1.12,1.03],dtype=np.float32)
            out=np.clip(night_rgb*(1-day)+day_rgb*day,0,255).astype(np.uint8)
            # Night-side city lights use the atlas populated-place locations.
            mapim=Image.fromarray(out,"RGB"); draw=ImageDraw.Draw(mapim,"RGBA")
            for city in self.world_atlas.get("cities",[]):
                try:
                    clon=float(city.get("lon",0)); clat=float(city.get("lat",0))
                    if clon < -180 or clon > 180 or clat < -85 or clat > 85: continue
                    if self._hf_sun_elevation(clat,clon,now)>-8: continue
                    px=(clon+180)/360*(mw-1); py=(85-clat)/170*(mh-1)
                    draw.ellipse((px-2,py-2,px+2,py+2),fill=(255,190,85,190))
                except Exception: pass
            # Draw a precise, sampled solar terminator curve.
            term=[]
            for lo in np.linspace(-180,180,361):
                Hangle=math.radians(lo-subsolar_lon)
                denom=math.sin(decl)
                if abs(denom)<1e-5: latterm=90 if math.cos(Hangle)<0 else -90
                else: latterm=math.degrees(math.atan(-math.cos(decl)*math.cos(Hangle)/denom))
                term.append(((lo+180)/360*(mw-1),(85-latterm)/170*(mh-1)))
            draw.line(term,fill=(255,210,70,235),width=max(2,int(mw/700)))
            # Subsolar point and soft gold halo.
            sx=(subsolar_lon+180)/360*(mw-1); sy=(85-math.degrees(decl))/170*(mh-1)
            for rr,fill in ((22,(255,190,35,35)),(14,(255,205,60,90)),(7,(255,220,80,220))):
                draw.ellipse((sx-rr,sy-rr,sx+rr,sy+rr),fill=fill)
            draw.ellipse((sx-4,sy-4,sx+4,sy+4),fill=(255,250,190,255),outline=(255,255,255,255))
            # Reusable raster image reference prevents Tk from releasing it.
            display=mapim.resize((w,h),Image.Resampling.LANCZOS)
            self._hf_map_photo=ImageTk.PhotoImage(display)
            c.create_image(w/2,h/2,image=self._hf_map_photo,anchor="center")
            c.create_rectangle(1,1,w-1,h-1,outline="#2a708e")
            c.create_text(8,h-5,anchor="sw",text="DAYLIGHT",fill="#f4d77b",font=("Segoe UI",6,"bold"))
            c.create_text(w-8,h-5,anchor="se",text="NIGHT",fill="#9bbbd7",font=("Segoe UI",6,"bold"))
            return
        # Fallback to the original offline vector map if artwork is unavailable.
        left,right,top,bottom=4,w-4,3,h-3
        def xy(lon,lat): return left+(lon+180)/360*(right-left), top+(85-lat)/170*(bottom-top)
        for country in self.world_atlas.get("countries",[]):
            label=country.get("label",[0,0]); daylight=self._hf_sun_elevation(label[1],label[0],now)>0
            for ring in country.get("rings",[]):
                pts=[]
                for plon,plat in ring: pts.extend(xy(plon,plat))
                if len(pts)>=6: c.create_polygon(*pts,fill="#397f91" if daylight else "#10243f",outline="#6f9cac",width=1)

    def _schedule_hf_refresh(self):
        self.refresh_hf_conditions()
        self.after(300000,self._schedule_hf_refresh)

    def refresh_hf_conditions(self):
        if getattr(self,"_hf_fetching",False): return
        self._hf_fetching=True
        self.hf_live_status_var.set("● CONNECTING TO LIVE FEEDS")
        def worker():
            data=None; forecast=[]; solar_error=None; kp_error=None
            try:
                req=urllib.request.Request("https://www.mapforham.com/hf-propagation/data/solar.json",
                    headers={"User-Agent":"ARES-X-N2MDX/0.9.0 (amateur radio propagation dashboard)"})
                with urllib.request.urlopen(req,timeout=12) as response: data=json.loads(response.read().decode("utf-8"))
            except Exception as exc: solar_error=str(exc)
            try:
                req=urllib.request.Request("https://services.swpc.noaa.gov/products/noaa-planetary-k-index-forecast.json",
                    headers={"User-Agent":"ARES-X-N2MDX/0.9.0"})
                with urllib.request.urlopen(req,timeout=12) as response: forecast=json.loads(response.read().decode("utf-8"))
            except Exception as exc: kp_error=str(exc)
            def apply():
                self._hf_fetching=False
                if data:
                    self.hf_live_data=data; self.hf_last_success=datetime.datetime.now(datetime.timezone.utc)
                    try:
                        point=(self.hf_last_success,float(data.get("solar_flux",0) or 0))
                        if point[1]>0:
                            self.hf_solar_history.append(point)
                            cutoff=self.hf_last_success-datetime.timedelta(hours=72)
                            self.hf_solar_history=[p for p in self.hf_solar_history if p[0]>=cutoff][-100:]
                    except Exception: pass
                    if isinstance(forecast,list) and forecast: self.hf_kp_forecast=forecast; self.hf_kp_ok=True
                    else: self.hf_kp_ok=False
                    self._draw_hf_conditions(); self._draw_hf_kp_forecast(); self._draw_hf_sun(); self._draw_hf_sfi_trend(); self._draw_hf_global_map()
                    updated=data.get("updated","")
                    self.hf_updated_var.set("LAST UPDATE: "+(updated.replace("T"," ")[:16]+" UTC" if updated else self.hf_last_success.strftime("%Y-%m-%d %H:%M UTC")))
                    sfi=data.get("solar_flux","--"); ssn=data.get("sunspots","--"); aidx=data.get("a_index","--"); kp=data.get("kp","--")
                    self.hf_indices_var.set(f"SFI: {sfi}   SSN: {ssn}   A: {aidx}   Kp: {kp}")
                    for key,value in (("sfi",sfi),("ssn",ssn),("a",aidx),("kp",kp)): self.hf_metric_vars[key].set(str(value))
                    geo=str(data.get("geomagnetic_field","--")).upper()
                    self.hf_geo_var.set("GEOMAGNETIC: "+geo)
                    if self.hf_kp_ok:
                        self.hf_live_status_var.set("● LIVE  •  SOLAR + NOAA KP FORECAST")
                        self.hf_live_status_var.set("● LIVE  •  5-MINUTE AUTO REFRESH")
                        self.hf_status_var.set("LIVE feeds connected. HF colors are simplified estimates, not guaranteed openings; path, antenna, season, noise and sporadic-E matter.")
                    else:
                        self.hf_live_status_var.set("● PARTIAL  •  SOLAR LIVE / NOAA KP OFFLINE")
                        self.hf_status_var.set("Solar feed live; NOAA Kp forecast unavailable: "+str(kp_error or "no forecast rows")+". Last Kp forecast retained if available.")
                else:
                    age=""
                    if self.hf_last_success:
                        mins=int((datetime.datetime.now(datetime.timezone.utc)-self.hf_last_success).total_seconds()/60)
                        age=f" Last successful update {mins} min ago."
                    self.hf_live_status_var.set("● OFFLINE  •  SHOWING LAST AVAILABLE DATA" if self.hf_live_data else "● OFFLINE  •  NO DATA YET")
                    self.hf_status_var.set("Live solar feed unavailable: "+str(solar_error or "unknown error")+"."+age)
                    if self.hf_live_data: self._draw_hf_conditions(); self._draw_hf_kp_forecast()
            try: self.after(0,apply)
            except Exception: self._hf_fetching=False
        threading.Thread(target=worker,daemon=True).start()

    @staticmethod
    def _hf_sun_elevation(lat, lon, when_utc):
        # Compact NOAA solar-position approximation; positive elevation means local daylight.
        day=when_utc.timetuple().tm_yday
        hour=when_utc.hour+when_utc.minute/60+when_utc.second/3600
        gamma=2*3.141592653589793/365*(day-1+(hour-12)/24)
        decl=(0.006918-0.399912*math.cos(gamma)+0.070257*math.sin(gamma)
              -0.006758*math.cos(2*gamma)+0.000907*math.sin(2*gamma)
              -0.002697*math.cos(3*gamma)+0.00148*math.sin(3*gamma))
        eqtime=229.18*(0.000075+0.001868*math.cos(gamma)-0.032077*math.sin(gamma)
              -0.014615*math.cos(2*gamma)-0.040849*math.sin(2*gamma))
        solar_minutes=(hour*60+eqtime+4*lon)%1440
        ha=solar_minutes/4-180
        latr=math.radians(lat); decr=decl
        cosz=(math.sin(latr)*math.sin(decr)
              +math.cos(latr)*math.cos(decr)*math.cos(math.radians(ha)))
        return 90-math.degrees(math.acos(max(-1,min(1,cosz))))

    def _hf_grid_latlon(self):
        try:
            locator=self.lookup_grid.get().strip().upper()
            if len(locator)<4 or not all(c.isalpha() for c in locator[:2]) or not all(c.isdigit() for c in locator[2:4]):
                return None
            lon=-180+(ord(locator[0])-ord("A"))*20+(int(locator[2]))*2+1
            lat=-90+(ord(locator[1])-ord("A"))*10+int(locator[3])+0.5
            if len(locator)>=6 and locator[4].isalpha() and locator[5].isalpha():
                lon+=(ord(locator[4])-ord("A")+0.5)/12
                lat+=(ord(locator[5])-ord("A")+0.5)/24
            return lat,lon
        except Exception:
            return None

    def _hf_condition_for(self, band, day, kp, sfi, aindex, live_bands):
        # MapForHam supplies live group day/night estimates; NOAA Kp forecast adjusts the outlook.
        groups={"160m":"80m-40m","80m":"80m-40m","60m":"80m-40m","40m":"80m-40m",
                "30m":"30m-20m","20m":"30m-20m","17m":"17m-15m","15m":"17m-15m",
                "12m":"12m-10m","10m":"12m-10m"}
        if band=="6m":
            return "VAR"
        group=groups.get(band)
        entry=next((x for x in live_bands if x.get("name")==group),None)
        rating=(entry.get("day" if day else "night","Fair") if entry else "Fair").lower()
        score={"poor":0,"fair":1,"good":2}.get(rating,1)
        if band=="160m" and day: score=max(0,score-1)
        if band=="60m" and day: score=max(0,score-1)
        if band in ("12m","10m") and sfi<90: score=max(0,score-1)
        if band in ("12m","10m") and sfi>=130: score=min(2,score+1)
        if kp>=7: score=max(0,score-2)
        elif kp>=5: score=max(0,score-1)
        elif kp>=4 and not day and band in ("160m","80m","60m","40m"):
            score=max(0,score-1)
        if aindex>=20 and not day and band in ("160m","80m","60m","40m") and kp<5:
            score=max(0,score-1)
        return ("Poor","Fair","Good")[score]

    def _draw_hf_conditions(self):
        canvas=getattr(self,"hf_chart",None)
        if canvas is None or not canvas.winfo_exists():
            return
        canvas.delete("all")
        w=max(400,canvas.winfo_width()); h=max(90,canvas.winfo_height())
        bands=["160m","80m","60m","40m","30m","20m","17m","15m","12m","10m","6m"]
        left=42; right=6; top=18; bottom=5
        label_w=42; cols=8
        cell_w=max(20,(w-left-right)/cols); cell_h=max(6,(h-top-bottom)/len(bands))
        now=datetime.datetime.now(datetime.timezone.utc)
        slots=[(now.replace(minute=0,second=0,microsecond=0)+datetime.timedelta(hours=3*i)) for i in range(cols)]
        live=self.hf_live_data or {}
        solar_bands=live.get("bands",[]) if isinstance(live.get("bands",[]),list) else []
        sfi=float(live.get("solar_flux",100) or 100); aidx=float(live.get("a_index",5) or 5)
        kp_now=float(live.get("kp",0) or 0)
        # Forecast rows are UTC, 3-hourly; use the closest matching forecast step.
        kp_rows=[]
        for row in self.hf_kp_forecast:
            try:
                stamp=datetime.datetime.fromisoformat(row.get("time_tag","").replace("Z","+00:00"))
                if stamp.tzinfo is None: stamp=stamp.replace(tzinfo=datetime.timezone.utc)
                kp_rows.append((stamp.astimezone(datetime.timezone.utc),float(row.get("kp",kp_now)),row.get("observed","")))
            except Exception: pass
        qth=self._hf_grid_latlon()
        self.hf_chart.create_text(5,3,anchor="nw",text="BAND",fill="#8ba6bc",font=("Segoe UI",7,"bold"))
        for col,slot in enumerate(slots):
            x=left+col*cell_w
            self.hf_chart.create_text(x+cell_w/2,3,anchor="n",text=slot.strftime("%H")+"Z",
                                      fill="#c4d7e8",font=("Segoe UI",7))
        for ri,band in enumerate(bands):
            y=top+ri*cell_h
            self.hf_chart.create_text(5,y+cell_h/2,anchor="w",text=band,fill="#c4d7e8",font=("Segoe UI",7,"bold"))
            for ci,slot in enumerate(slots):
                nearest=min(kp_rows,key=lambda r:abs((r[0]-slot).total_seconds())) if kp_rows else None
                kp=nearest[1] if nearest else kp_now
                if qth:
                    elev=self._hf_sun_elevation(qth[0],qth[1],slot)
                    is_day=elev>0
                else:
                    # Without a saved Maidenhead grid, use the PC's local day/night as a coarse fallback.
                    local=slot.astimezone()
                    is_day=6<=local.hour<18
                cond=self._hf_condition_for(band,is_day,kp,sfi,aidx,solar_bands)
                colors={"Good":"#20b85a","Fair":"#e2bd35","Poor":"#e36b32","VAR":"#536477"}
                color=colors.get(cond,"#536477")
                x=left+ci*cell_w
                self.hf_chart.create_rectangle(x+1,y+1,x+cell_w-1,y+cell_h-1,fill=color,outline="#10283d")
                self.hf_chart.create_text(x+cell_w/2,y+cell_h/2,text=cond if cell_w>48 else cond[:1],
                                          fill="#07111e",font=("Segoe UI",6,"bold"))
        self.hf_chart.create_text(w-8,h-1,anchor="se",text="UTC • 3-hour steps • 24h outlook",
                                  fill="#8ba6bc",font=("Segoe UI",6))

    def _build_menubar(self):
        bar=tk.Menu(self)
        file_menu=tk.Menu(bar,tearoff=False)
        file_menu.add_command(label="Save Settings",command=self._save_settings)
        file_menu.add_separator(); file_menu.add_command(label="Exit",command=self._on_close)
        bar.add_cascade(label="File",menu=file_menu)
        radio_menu=tk.Menu(bar,tearoff=False)
        self.radio_menu_var=tk.StringVar(value=self.radio_model.get())
        for model in self._radio_models():
            radio_menu.add_radiobutton(label=model,variable=self.radio_menu_var,value=model,
                                       command=lambda m=model:self._select_radio_model(m))
        radio_menu.add_separator(); radio_menu.add_command(label="Connect / Disconnect CAT",command=self.toggle_cat)
        bar.add_cascade(label="Radio",menu=radio_menu)
        settings_menu=tk.Menu(bar,tearoff=False)
        settings_menu.add_command(label="Preferences…",command=self.open_settings)
        settings_menu.add_command(label="Station Profile…",command=self.open_settings)
        bar.add_cascade(label="Settings",menu=settings_menu)
        help_menu=tk.Menu(bar,tearoff=False)
        help_menu.add_command(label="About ARES-X",command=lambda:messagebox.showinfo("About ARES-X",f"ARES-X by N2MDX\n{APP_VERSION}\n\nWSJT-X remains the external digital-mode modem and decoder."))
        bar.add_cascade(label="Help",menu=help_menu)
        self.config(menu=bar)

    def _select_radio_model(self, model):
        self.radio_model.set(model)
        if hasattr(self,"radio_menu_var"): self.radio_menu_var.set(model)
        if hasattr(self,"radio_box"): self.radio_box.set(model)
        self._save_settings()
        self._radio_model_changed()

    def _radio_model_changed(self):
        model=self.radio_model.get()
        if model == "Yaesu FTDX10":
            self._log("Yaesu FTDX10 profile selected. Use the Enhanced COM Port and match the radio CAT RATE; native Yaesu CAT is active.")
            if self.baud.get() == "9600": self.baud.set("38400")
        elif "Icom" in model or "Yaesu" in model:
            self._log(f"{model} selected. A native adapter for this profile is not implemented; connection is disabled.")
        else:
            self._log(f"Radio profile selected: {model}. Direct connection uses the Kenwood-compatible CAT adapter; verify your radio's CAT personality and settings.")
        if hasattr(self,"radio_menu_var"): self.radio_menu_var.set(model)
        self._save_settings()

    def open_settings(self):
        win=tk.Toplevel(self); win.title("ARES-X Preferences"); win.configure(bg="#07111e")
        win.transient(self); win.grab_set(); win.resizable(False,False)
        outer=ttk.Frame(win,padding=18); outer.pack(fill="both",expand=True)
        ttk.Label(outer,text="ARES-X SETTINGS",style="Title.TLabel").grid(row=0,column=0,columnspan=2,sticky="w",pady=(0,14))
        ttk.Label(outer,text="Station callsign").grid(row=1,column=0,sticky="w",pady=5)
        call=tk.StringVar(value=self.lookup_call.get() if hasattr(self,"lookup_call") else self.saved_settings.get("callsign",""))
        ttk.Entry(outer,textvariable=call,width=30).grid(row=1,column=1,sticky="ew",pady=5)
        ttk.Label(outer,text="Maidenhead locator").grid(row=2,column=0,sticky="w",pady=5)
        grid=tk.StringVar(value=self.lookup_grid.get() if hasattr(self,"lookup_grid") else self.saved_settings.get("locator",""))
        ttk.Entry(outer,textvariable=grid,width=30).grid(row=2,column=1,sticky="ew",pady=5)
        ttk.Label(outer,text="Radio profile").grid(row=3,column=0,sticky="w",pady=5)
        model=tk.StringVar(value=self.radio_model.get())
        ttk.Combobox(outer,textvariable=model,state="readonly",values=self._radio_models(),width=28).grid(row=3,column=1,sticky="ew",pady=5)
        ttk.Label(outer,text="CAT COM port").grid(row=4,column=0,sticky="w",pady=5)
        port=tk.StringVar(value=self.com_port.get()); ttk.Combobox(outer,textvariable=port,values=ThetisCAT.available_ports(),width=28).grid(row=4,column=1,sticky="ew",pady=5)
        ttk.Label(outer,text="CAT baud rate").grid(row=5,column=0,sticky="w",pady=5)
        baud=tk.StringVar(value=self.baud.get()); ttk.Combobox(outer,textvariable=baud,values=["9600","19200","38400","57600","115200"],width=28).grid(row=5,column=1,sticky="ew",pady=5)
        ttk.Label(outer,text="WSJT-X UDP host").grid(row=6,column=0,sticky="w",pady=5)
        host=tk.StringVar(value=self.wsjtx_host.get()); ttk.Entry(outer,textvariable=host,width=30).grid(row=6,column=1,sticky="ew",pady=5)
        ttk.Label(outer,text="WSJT-X UDP port").grid(row=7,column=0,sticky="w",pady=5)
        udp=tk.StringVar(value=self.wsjtx_port.get()); ttk.Entry(outer,textvariable=udp,width=30).grid(row=7,column=1,sticky="ew",pady=5)
        ttk.Label(outer,text="Audio input").grid(row=8,column=0,sticky="w",pady=5)
        audio=tk.StringVar(value=self.audio_device.get()); ttk.Combobox(outer,textvariable=audio,values=self.audio_box.cget("values"),width=28).grid(row=8,column=1,sticky="ew",pady=5)
        ttk.Label(outer,text="CAT note: Yaesu FTDX10 uses its native CAT protocol on the Enhanced COM port (8-N-2; default CAT RATE 38400). Other Yaesu models and Icom CI-V are not implemented.",wraplength=460,foreground="#ffca69").grid(row=9,column=0,columnspan=2,sticky="w",pady=(10,4))
        def save_close():
            try:
                p=int(udp.get()); b=int(baud.get())
                if not (1<=p<=65535): raise ValueError("UDP port must be between 1 and 65535.")
                if b not in (9600,19200,38400,57600,115200): raise ValueError("Choose a supported baud rate.")
                if not host.get().strip(): raise ValueError("WSJT-X UDP host cannot be blank.")
            except Exception as exc:
                messagebox.showerror("Invalid settings",str(exc),parent=win); return
            if self.cat_connected and (port.get()!=self.com_port.get() or baud.get()!=self.baud.get() or model.get()!=self.radio_model.get()):
                messagebox.showwarning("Radio connected","Disconnect CAT before changing the radio profile, COM port, or baud rate.",parent=win); return
            if hasattr(self,"lookup_call"): self.lookup_call.set(call.get().strip().upper())
            if hasattr(self,"lookup_grid"): self.lookup_grid.set(grid.get().strip().upper())
            self._select_radio_model(model.get()); self.com_port.set(port.get()); self.baud.set(str(b))
            self.wsjtx_host.set(host.get().strip()); self.wsjtx_port.set(str(p)); self.audio_device.set(audio.get())
            self._save_settings(); self._log("Preferences saved. CAT changes apply on the next connection.")
            win.destroy()
        buttons=ttk.Frame(outer); buttons.grid(row=10,column=0,columnspan=2,sticky="e",pady=(14,0))
        ttk.Button(buttons,text="CANCEL",command=win.destroy).pack(side="right",padx=(6,0))
        ttk.Button(buttons,text="SAVE SETTINGS",style="Accent.TButton",command=save_close).pack(side="right")
        outer.columnconfigure(1,weight=1)

    def _build(self):
        header=ttk.Frame(self,padding=(18,14,18,10)); header.pack(fill="x")
        ttk.Label(header,text="ARES-X",style="Title.TLabel").pack(side="left")
        ttk.Label(header,text="  N2MDX  |  DIGITAL MODE LAB",style="Sub.TLabel").pack(side="left",padx=(12,0),pady=(10,0))
        ttk.Label(header,text="0.9.9 • ANIMATED SPLASH",foreground="#ffca69").pack(side="right",pady=(10,0))
        self._build_hf_conditions_dashboard()
        self._startup_update(66, "LOADING HF CONDITIONS DASHBOARD")
        self.status=tk.StringVar(value="READY — AUDIO LAB")
        tk.Label(self,textvariable=self.status,bg="#10283d",fg="#6fe3a2",anchor="w",padx=16,pady=8,
                 font=("Segoe UI",10,"bold")).pack(fill="x",padx=18,pady=(0,6))
        # RX follows WSJT-X decoding state; TX follows WSJT-X transmitting state.
        # These are software-reported states, not independent RF power measurements.
        activity=tk.Frame(self,bg="#07111e")
        activity.pack(fill="x",padx=18,pady=(0,8))
        self.rx_activity=tk.Canvas(activity,height=25,bg="#07111e",highlightthickness=0)
        self.rx_activity.pack(side="left",fill="x",expand=True,padx=(0,8))
        self.tx_activity=tk.Canvas(activity,height=25,bg="#07111e",highlightthickness=0)
        self.tx_activity.pack(side="left",fill="x",expand=True)
        self._draw_activity_bar(self.rx_activity,"RX INCOMING","#20df85",False)
        self._draw_activity_bar(self.tx_activity,"TX OUTGOING / REQUEST","#ff414d",False)
        self.rx_activity.bind("<Configure>",lambda _e:self._draw_activity_bar(self.rx_activity,"RX INCOMING","#20df85",getattr(self,"_rx_active",False)))
        self.tx_activity.bind("<Configure>",lambda _e:self._draw_activity_bar(self.tx_activity,"TX OUTGOING / REQUEST","#ff414d",getattr(self,"_tx_active",False)))
        self._rx_active=False
        self._tx_active=False
        radio=ttk.Frame(self,padding=(18,0,18,8)); radio.pack(fill="x")
        self.radio_model=tk.StringVar(value=self.saved_settings.get("radio_model", "Thetis / Hermes / ANAN"))
        ttk.Label(radio,text="RADIO").pack(side="left")
        self.radio_box=ttk.Combobox(radio,textvariable=self.radio_model,width=22,state="readonly",values=self._radio_models())
        self.radio_box.pack(side="left",padx=(6,10))
        self.radio_box.bind("<<ComboboxSelected>>",lambda _e:self._radio_model_changed())
        ttk.Label(radio,text="CAT COM").pack(side="left")
        self.com_port=tk.StringVar(value=self.saved_settings.get("com_port", "COM3"))
        self.com_box=ttk.Combobox(radio,textvariable=self.com_port,width=9,values=ThetisCAT.available_ports())
        self.com_box.pack(side="left",padx=(6,8))
        ttk.Label(radio,text="Baud").pack(side="left")
        self.baud=tk.StringVar(value=self.saved_settings.get("baud", "9600"))
        ttk.Combobox(radio,textvariable=self.baud,width=7,state="readonly",values=["9600","19200","38400","57600","115200"]).pack(side="left",padx=(5,8))
        self.cat_button=ttk.Button(radio,text="CONNECT CAT",style="Accent.TButton",command=self.toggle_cat); self.cat_button.pack(side="left",padx=(0,14))
        self.radio_readout=tk.StringVar(value="Frequency: —   Mode: —")
        ttk.Label(radio,textvariable=self.radio_readout,style="Sub.TLabel").pack(side="left",padx=4)
        ttk.Label(radio,text="Band").pack(side="left",padx=(10,4))
        self.band_choice=tk.StringVar(value=self.saved_settings.get("band", "20 m — FT8 14.074 MHz"))
        self.band_box=ttk.Combobox(radio,textvariable=self.band_choice,width=25,state="readonly",values=self._band_choices())
        self.band_box.pack(side="left",padx=(0,6))
        self.band_box.bind("<<ComboboxSelected>>",lambda _e:self.tune_selected_band())
        ttk.Button(radio,text="TUNE BAND",command=self.tune_selected_band).pack(side="left",padx=(0,8))
        ttk.Label(radio,text="VAC input").pack(side="left",padx=(8,4))
        self.audio_device=tk.StringVar(value=self.saved_settings.get("audio_device", "Default input"))
        self.audio_box=ttk.Combobox(radio,textvariable=self.audio_device,width=24,state="readonly",values=["Default input"])
        self.audio_box.pack(side="left",padx=(0,5))
        ttk.Button(radio,text="REFRESH",command=self.refresh_audio_devices).pack(side="left")
        ttk.Label(radio,textvariable=self.audio_level,style="Sub.TLabel").pack(side="left",padx=(8,0))
        self.refresh_audio_devices()
        self._build_menubar()
        self._startup_update(72, "INITIALIZING RADIO CONTROLS")
        self.main_tabs = ttk.Notebook(self)
        self.main_tabs.pack(fill="both", expand=True, padx=12, pady=(0,8))
        radio_tab = ttk.Frame(self.main_tabs, padding=(8,4,8,8))
        tools_tab = ttk.Frame(self.main_tabs, padding=(8,8,8,8))
        self.main_tabs.add(radio_tab, text="  RADIO / DIGITAL  ")
        self.main_tabs.add(tools_tab, text="  TOOLS  ")
        body=ttk.Frame(radio_tab,padding=(6,4,6,6)); body.pack(fill="both",expand=True)
        # Outer splitter reserves a dedicated expansion bay on the far right.
        # Drag its right-edge sash to resize the existing workspace vs future WSJT-X tools.
        body.columnconfigure(0,weight=1); body.rowconfigure(0,weight=1)
        self.workspace_splitter = ttk.Panedwindow(body, orient="horizontal")
        self.workspace_splitter.grid(row=0,column=0,sticky="nsew")
        self.main_splitter = ttk.Panedwindow(self.workspace_splitter, orient="horizontal")
        self.workspace_splitter.add(self.main_splitter, weight=5)
        self.future_wsjt_panel = ttk.Frame(self.workspace_splitter,style="Panel.TFrame",padding=12)
        self.workspace_splitter.add(self.future_wsjt_panel, weight=1)
        # Event Log now sits above the WSJT-X Functions workspace in the far-right panel.
        event_log_panel = ttk.Frame(self.future_wsjt_panel, style="Panel.TFrame")
        event_log_panel.pack(fill="x", expand=False, pady=(0,8))
        ttk.Label(event_log_panel,text="EVENT LOG",style="PanelTitle.TLabel").pack(anchor="w")
        event_log_wrap = ttk.Frame(event_log_panel, style="Panel.TFrame")
        event_log_wrap.pack(fill="x", expand=False, pady=(6,0))
        self.log=tk.Text(event_log_wrap,bg="#06101b",fg="#8fe4b0",insertbackground="white",
                         font=("Consolas",9),relief="flat",height=8,wrap="word")
        event_log_scroll=ttk.Scrollbar(event_log_wrap,orient="vertical",command=self.log.yview)
        self.log.configure(yscrollcommand=event_log_scroll.set)
        self.log.pack(side="left",fill="both",expand=True)
        event_log_scroll.pack(side="right",fill="y")
        self._build_wsjtx_functions_panel(self.future_wsjt_panel)
        self._startup_update(79, "CONNECTING DIGITAL MODE WORKSPACE")
        left=ttk.Frame(self.main_splitter,style="Panel.TFrame",padding=14)
        right=ttk.Frame(self.main_splitter,style="Panel.TFrame",padding=14)
        self.main_splitter.add(left, weight=3)
        self.main_splitter.add(right, weight=2)
        self.after(250, self._set_main_splitter_position)
        self.after(650, self._set_workspace_splitter_position)
        ttk.Label(left,text="PACKET FORMAT / DIGITAL MODE",style="PanelTitle.TLabel").pack(anchor="w")
        ttk.Label(left,text="Payload (ASCII, up to 7 bytes in this experimental packet format)").pack(anchor="w",pady=(12,4))
        row=ttk.Frame(left,style="Panel.TFrame"); row.pack(fill="x")
        self.payload=tk.StringVar(value="N2MDX")
        ttk.Entry(row,textvariable=self.payload,font=("Consolas",13)).pack(side="left",fill="x",expand=True)
        self.kind=tk.StringVar(value="CQ / Beacon (type 1)")
        self.digital_mode_box=ttk.Combobox(row,textvariable=self.kind,state="readonly",width=22,
          values=["CQ / Beacon (type 1)","Call (type 2)","Report (type 3)","Ack (type 4)",
                  "FST4","FT4","FT8","JT4","JT9","JT65","Q65","MSK144","FST4W","WSPR","Echo","FreqCal"])
        self.digital_mode_box.pack(side="left",padx=(8,0))
        self.digital_mode_box.bind("<<ComboboxSelected>>", self._on_digital_mode_selected)
        ttk.Label(left,text="Channel simulation SNR").pack(anchor="w",pady=(12,4))
        row=ttk.Frame(left,style="Panel.TFrame"); row.pack(fill="x")
        self.snr=tk.DoubleVar(value=8.0); self.snr_label=tk.StringVar(value="8.0 dB")
        ttk.Scale(row,from_=-18,to=25,variable=self.snr,command=lambda _:self.snr_label.set(f"{self.snr.get():.1f} dB")).pack(side="left",fill="x",expand=True)
        ttk.Label(row,textvariable=self.snr_label,style="PanelTitle.TLabel",width=8).pack(side="left",padx=8)
        ttk.Label(left,text="Injected frequency offset (Hz; current decoder assumes near-zero offset)").pack(anchor="w",pady=(10,4))
        row=ttk.Frame(left,style="Panel.TFrame"); row.pack(fill="x")
        self.freq=tk.DoubleVar(value=0.0); self.freq_label=tk.StringVar(value="0.0 Hz")
        ttk.Scale(row,from_=-8,to=8,variable=self.freq,command=lambda _:self.freq_label.set(f"{self.freq.get():+.1f} Hz")).pack(side="left",fill="x",expand=True)
        ttk.Label(row,textvariable=self.freq_label,style="PanelTitle.TLabel",width=8).pack(side="left",padx=8)
        buttons=ttk.Frame(left,style="Panel.TFrame"); buttons.pack(fill="x",pady=(15,8))
        ttk.Button(buttons,text="ENCODE + SIMULATE",style="Accent.TButton",command=self.run_sim).pack(side="left",fill="x",expand=True,padx=(0,4))
        ttk.Button(buttons,text="SELF-TEST",command=self.run_test).pack(side="left",fill="x",expand=True,padx=4)
        ttk.Button(buttons,text="EXPORT WAV",command=self.export_wav).pack(side="left",fill="x",expand=True,padx=(4,0))
        ttk.Label(left,text="AUDIO FILE / LIVE INPUT",style="PanelTitle.TLabel").pack(anchor="w",pady=(10,4))
        row=ttk.Frame(left,style="Panel.TFrame"); row.pack(fill="x")
        ttk.Button(row,text="OPEN WAV + DECODE",command=self.open_wav).pack(side="left",fill="x",expand=True,padx=(0,4))
        ttk.Button(row,text="LISTEN TO INPUT",command=self.start_listen).pack(side="left",fill="x",expand=True,padx=4)
        ttk.Button(row,text="STOP",command=self.stop_listen).pack(side="left",fill="x",expand=True,padx=(4,0))
        ttk.Button(row,text="CONNECT WSJT-X",command=self.start_wsjtx_bridge).pack(side="left",fill="x",expand=True,padx=(6,0))
        ttk.Label(left,text="DECODER WORKSPACE",style="PanelTitle.TLabel").pack(anchor="w",pady=(10,4))
        self.decoder_splitter=ttk.Panedwindow(left,orient="horizontal")
        self.decoder_splitter.pack(fill="both",expand=True)
        decoder_output_panel=ttk.Frame(self.decoder_splitter,style="Panel.TFrame")
        dx_intel_panel=ttk.Frame(self.decoder_splitter,style="Panel.TFrame",padding=(8,4))
        self.decoder_splitter.add(decoder_output_panel,weight=3)
        self.decoder_splitter.add(dx_intel_panel,weight=2)
        self.after(500,self._set_decoder_splitter_position)
        ttk.Label(decoder_output_panel,text="DECODER OUTPUT",style="PanelTitle.TLabel").pack(anchor="w",pady=(2,4))
        self.result=tk.Text(decoder_output_panel,height=8,bg="#06101b",fg="#b9eaff",insertbackground="white",font=("Consolas",10),relief="flat",wrap="word")
        self.result.pack(fill="both",expand=True); self.result.insert("end","Ready. Run a simulation or open an ARES-X WAV file.\n")
        self._build_dx_intelligence_panel(dx_intel_panel)
        self._startup_update(86, "PREPARING DECODE AND STATION PANELS")
        # Vertical splitter lets the operator enlarge Incoming Stations to show more decodes.
        self.right_splitter = ttk.Panedwindow(right, orient="vertical")
        self.right_splitter.pack(fill="both",expand=True)
        stations_panel = ttk.Frame(self.right_splitter,style="Panel.TFrame")
        display_panel = ttk.Frame(self.right_splitter,style="Panel.TFrame")
        self.right_splitter.add(stations_panel, weight=2)
        self.right_splitter.add(display_panel, weight=3)
        self.after(300, self._set_right_splitter_position)
        ttk.Label(stations_panel,text="INCOMING STATIONS — SELECT A CQ TO REPLY",style="PanelTitle.TLabel").pack(anchor="w")
        station_wrap=ttk.Frame(stations_panel,style="Panel.TFrame"); station_wrap.pack(fill="both",expand=True,pady=(6,8))
        columns=("utc","mode","call","snr","dt","df")
        self.station_tree=ttk.Treeview(station_wrap,columns=columns,show="headings",height=5,selectmode="browse")
        for col,title,width in [("utc","UTC",60),("mode","Mode",48),("call","Decoded message",205),("snr","SNR",42),("dt","DT",42),("df","DF Hz",54)]:
            self.station_tree.heading(col,text=title); self.station_tree.column(col,width=width,stretch=(col=="call"),anchor="w")
        station_scroll=ttk.Scrollbar(station_wrap,orient="vertical",command=self.station_tree.yview)
        self.station_tree.configure(yscrollcommand=station_scroll.set)
        self.station_tree.pack(side="left",fill="both",expand=True); station_scroll.pack(side="right",fill="y")
        self.station_tree.bind("<<TreeviewSelect>>",self._update_dx_intelligence)
        station_actions=ttk.Frame(stations_panel,style="Panel.TFrame"); station_actions.pack(fill="x",pady=(0,8))
        ttk.Button(station_actions,text="REPLY TO SELECTED CQ / QRZ",style="Accent.TButton",command=self.reply_selected_station).pack(side="left",fill="x",expand=True,padx=(0,4))
        ttk.Button(station_actions,text="WORKED STATIONS…",command=self.open_worked_stations).pack(side="left",padx=(4,0))
        ttk.Label(stations_panel,text="Selecting is receive-only. Reply can initiate RF transmission; Halt TX is available in Worked Stations.",foreground="#ffca69",wraplength=440).pack(anchor="w",pady=(0,8))
        ttk.Label(display_panel,text="SPECTRUM / WATERFALL",style="PanelTitle.TLabel").pack(anchor="w")
        # Drag the horizontal sash between these two panes to resize Spectrum vs Waterfall.
        self.spectrum_waterfall_splitter=ttk.Panedwindow(display_panel,orient="vertical")
        self.spectrum_waterfall_splitter.pack(fill="both",expand=True,pady=(6,4))
        self.spectrum_pane=ttk.Frame(self.spectrum_waterfall_splitter,style="Panel.TFrame")
        self.waterfall_pane=ttk.Frame(self.spectrum_waterfall_splitter,style="Panel.TFrame")
        self.spectrum_waterfall_splitter.add(self.spectrum_pane,weight=3)
        self.spectrum_waterfall_splitter.add(self.waterfall_pane,weight=2)
        self.after(450,self._set_spectrum_waterfall_sash)
        self.canvas=tk.Canvas(self.spectrum_pane,height=210,bg="#030a12",highlightthickness=0); self.canvas.pack(fill="both",expand=True,pady=(2,4))
        # RF band viewport controls: these show the selected amateur-band frequency window.
        # The current plotted trace remains the VAC audio FFT until an RF spectrum source is connected.
        self.band_view_center = tk.DoubleVar(value=50.0)
        self.band_view_zoom = tk.DoubleVar(value=4.0)
        self.band_view_readout = tk.StringVar(value="")
        self._spectrum_auto_centered = False
        band_controls=ttk.Frame(self.spectrum_pane,style="Panel.TFrame"); band_controls.pack(fill="x",pady=(0,8))
        ttk.Label(band_controls,text="SPECTRUM").grid(row=0,column=0,sticky="w",padx=(0,6))
        self.band_pan_scale=ttk.Scale(band_controls,from_=0,to=100,variable=self.band_view_center,command=lambda _v:self._update_band_view())
        self.band_pan_scale.grid(row=0,column=1,sticky="ew",padx=(0,10))
        ttk.Label(band_controls,text="ZOOM").grid(row=0,column=2,sticky="w",padx=(0,6))
        self.band_zoom_scale=ttk.Scale(band_controls,from_=1,to=32,variable=self.band_view_zoom,command=lambda _v:self._update_band_view())
        self.band_zoom_scale.grid(row=0,column=3,sticky="ew",padx=(0,8))
        ttk.Label(band_controls,textvariable=self.band_view_readout,style="Sub.TLabel").grid(row=0,column=4,sticky="e")
        band_controls.columnconfigure(1,weight=1)
        self.band_frequency_ruler=tk.Canvas(self.spectrum_pane,height=30,bg="#071522",highlightthickness=0)
        self.band_frequency_ruler.pack(fill="x",pady=(0,4))
        waterfall_header=ttk.Frame(self.waterfall_pane,style="Panel.TFrame"); waterfall_header.pack(fill="x",pady=(2,3))
        ttk.Label(waterfall_header,text="WATERFALL",style="PanelTitle.TLabel").pack(side="left")
        ttk.Label(waterfall_header,text="COLOR",style="Sub.TLabel").pack(side="left",padx=(12,4))
        self.waterfall_palette=tk.StringVar(value=self.saved_settings.get("waterfall_palette","Classic"))
        self.waterfall_custom_colors=self.saved_settings.get("waterfall_custom_colors",["#000018","#00bec0","#fffff5"])
        self.waterfall_palette_box=ttk.Combobox(waterfall_header,textvariable=self.waterfall_palette,
            values=("Classic","Fire","Ice","Spectrum","Green","Custom…"),state="readonly",width=11)
        self.waterfall_palette_box.pack(side="left")
        self.waterfall_palette_box.bind("<<ComboboxSelected>>",lambda _e:self._on_waterfall_palette_selected())
        self.waterfall_canvas=tk.Canvas(self.waterfall_pane,height=105,bg="#030a12",highlightthickness=0)
        self.waterfall_canvas.pack(fill="both",expand=True,pady=(0,8))
        self._waterfall_rows=[]
        self._waterfall_max_rows=300
        self._waterfall_bins=180
        self._waterfall_last_values=None
        self.waterfall_canvas.bind("<Configure>",lambda _e:self._redraw_waterfall())
        self.band_box.bind("<<ComboboxSelected>>",lambda _e:self._on_band_view_changed(), add="+")
        self.band_frequency_ruler.bind("<Configure>",lambda _e:self._draw_band_frequency_ruler())
        self._draw_placeholder()
        self.after(350,self._on_band_view_changed)
        self.after(150, self._refresh_live_display)
        self._build_tools_tab(tools_tab)
        self._startup_update(92, "LOADING TOOLS AND EXTENSIONS")
        self._build_extension_tabs()
        tk.Label(self,text="N2MDX • WSJT-X DIGITAL MODE LINK • VERIFY RADIO TX CONFIGURATION",bg="#07111e",fg="#6d8aa3",font=("Segoe UI",8),pady=6).pack(fill="x")



    def _set_decoder_splitter_position(self):
        try:
            width=self.decoder_splitter.winfo_width()
            if width>240:
                self.decoder_splitter.sashpos(0,int(width*0.60))
        except tk.TclError:
            pass

    def _build_dx_intelligence_panel(self,parent):
        ttk.Label(parent,text="DX INTELLIGENCE",style="PanelTitle.TLabel").pack(anchor="w",pady=(2,6))
        self.dx_call_var=tk.StringVar(value="NO STATION SELECTED")
        ttk.Label(parent,textvariable=self.dx_call_var,foreground="#43c5ff",
                  background="#0b1a29",font=("Segoe UI",15,"bold")).pack(anchor="w",pady=(0,4))
        self.dx_message=tk.Text(parent,height=3,bg="#06101b",fg="#b9eaff",relief="flat",
                                wrap="word",font=("Consolas",9),state="disabled")
        self.dx_message.pack(fill="x",pady=(0,6))
        self.dx_detail_vars={}
        for label,initial in [("MODE","—"),("SNR","—"),("DELTA TIME","—"),("AUDIO FREQ","—"),
                              ("GRID","—"),("DISTANCE","—"),("BEARING","—"),("STATUS","—")]:
            row=ttk.Frame(parent,style="Panel.TFrame"); row.pack(fill="x",pady=1)
            ttk.Label(row,text=label,foreground="#7897ad",width=13).pack(side="left")
            value=tk.StringVar(value=initial); self.dx_detail_vars[label]=value
            ttk.Label(row,textvariable=value,foreground="#d7eaf7").pack(side="left",fill="x",expand=True)
        actions=ttk.Frame(parent,style="Panel.TFrame"); actions.pack(fill="x",pady=(7,0))
        ttk.Button(actions,text="LOOKUP",command=self._dx_lookup_selected).pack(side="left",fill="x",expand=True,padx=(0,3))
        ttk.Button(actions,text="ADD TO LOG",command=self._dx_add_selected_to_log).pack(side="left",fill="x",expand=True,padx=3)
        ttk.Button(actions,text="MARK WORKED",command=self._dx_mark_selected_worked).pack(side="left",fill="x",expand=True,padx=(3,0))
        self.dx_activity_var=tk.StringVar(value="LIVE DX ACTIVITY  •  0 stations  |  0 new  |  0 worked")
        ttk.Label(parent,textvariable=self.dx_activity_var,foreground="#7dd3fc",
                  background="#0b1a29",font=("Segoe UI",8)).pack(anchor="w",pady=(8,0))
        self._refresh_dx_activity()

    def _decode_identity(self,message):
        import re
        words=message.strip().upper().split()
        call=self._callsign_from_cq(message) or next(
            (w for w in words if re.fullmatch(r"(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]{3,12}(?:/[A-Z0-9]{1,5})?",w)),"Unknown")
        locator=next((w for w in words if re.fullmatch(r"[A-R]{2}[0-9]{2}(?:[A-X]{2}(?:[0-9]{2})?)?",w)),"—")
        return call,locator

    def _update_dx_intelligence(self,_event=None):
        selected=self.station_tree.selection()
        if not selected: return
        item=self.station_rows.get(selected[0])
        if not item: return
        call,locator=self._decode_identity(item.message)
        self.dx_call_var.set(call)
        self.dx_message.configure(state="normal")
        self.dx_message.delete("1.0","end"); self.dx_message.insert("end",item.message)
        self.dx_message.configure(state="disabled")
        vals={"MODE":item.mode,"SNR":f"{item.snr_db:+d} dB",
              "DELTA TIME":f"{item.delta_time:+.1f} s","AUDIO FREQ":f"{item.audio_hz} Hz",
              "GRID":locator,"DISTANCE":"—","BEARING":"—",
              "STATUS":"Worked" if call in self.worked_stations else "New"}
        if locator!="—" and hasattr(self,"lookup_grid"):
            try:
                own=self.lookup_grid.get().strip().upper()
                if len(own)>=4:
                    lat1,lon1=self._maidenhead_center(own); lat2,lon2=self._maidenhead_center(locator)
                    import math
                    r=math.pi/180; dl=(lat2-lat1)*r; dn=(lon2-lon1)*r
                    a=math.sin(dl/2)**2+math.cos(lat1*r)*math.cos(lat2*r)*math.sin(dn/2)**2
                    km=6371*2*math.atan2(math.sqrt(a),math.sqrt(max(0,1-a)))
                    y=math.sin(dn)*math.cos(lat2*r)
                    x=math.cos(lat1*r)*math.sin(lat2*r)-math.sin(lat1*r)*math.cos(lat2*r)*math.cos(dn)
                    vals["DISTANCE"]=f"{km:.0f} km"; vals["BEARING"]=f"{(math.degrees(math.atan2(y,x))+360)%360:.0f}°"
            except Exception: pass
        for key,value in vals.items(): self.dx_detail_vars[key].set(value)
        self._refresh_dx_activity()

    def _refresh_dx_activity(self):
        if not hasattr(self,"dx_activity_var"): return
        calls=set()
        for item in getattr(self,"station_rows",{}).values():
            call,_=self._decode_identity(item.message)
            if call!="Unknown": calls.add(call)
        worked=set(self.worked_stations.keys()) if isinstance(self.worked_stations,dict) else set()
        done=len(calls & worked)
        self.dx_activity_var.set(f"LIVE DX ACTIVITY  •  {len(calls)} stations  |  {len(calls)-done} new  |  {done} worked")

    def _dx_lookup_selected(self):
        selected=self.station_tree.selection()
        if not selected: messagebox.showinfo("DX Lookup","Select a decoded station first."); return
        item=self.station_rows.get(selected[0])
        if not item: return
        call,_=self._decode_identity(item.message)
        if call=="Unknown": messagebox.showinfo("DX Lookup","No callsign found in this decode."); return
        self.lookup_call.set(call); self.main_tabs.select(1); self.tools_tabs.select(1)

    def _dx_add_selected_to_log(self):
        selected=self.station_tree.selection()
        if not selected: messagebox.showinfo("Add to Log","Select a decoded station first."); return
        item=self.station_rows.get(selected[0])
        if not item:return
        call,locator=self._decode_identity(item.message)
        if call=="Unknown": messagebox.showinfo("Add to Log","No callsign found in this decode."); return
        if not hasattr(self,"lb_vars"):
            messagebox.showinfo("Logbook","Open the LOGBOOK tab first, then use Add to Log."); return
        self.lb_vars["call"].set(call)
        self.lb_vars["grid"].set("" if locator=="—" else locator)
        self.lb_vars["mode"].set(item.mode.upper())
        self.lb_vars["rst_rcvd"].set(str(item.snr_db))
        self.lb_vars["comment"].set(f"Prefilled from received decode: {item.message}")
        self.main_tabs.select(4)
        self.status.set(f"QSO FORM PREPARED — {call} — REVIEW BEFORE ADDING")
        self._log(f"Prepared a manual QSO form for {call} from a decode. No contact was logged.")

    def _dx_mark_selected_worked(self):
        selected=self.station_tree.selection()
        if not selected: messagebox.showinfo("Mark Worked","Select a decoded station first."); return
        item=self.station_rows.get(selected[0])
        if not item: return
        call,_=self._decode_identity(item.message)
        if call=="Unknown": messagebox.showinfo("Mark Worked","No callsign found in this decode."); return
        self.worked_stations[call]={"call":call,"manual":True,"utc":item.utc}
        self._update_dx_intelligence()
        self._log(f"{call} manually marked WORKED in DX Intelligence; this is not automatic QSO confirmation.")

    def _set_spectrum_waterfall_sash(self):
        """Set a useful initial split; the operator can drag it vertically afterward."""
        try:
            height=self.spectrum_waterfall_splitter.winfo_height()
            if height>180:
                self.spectrum_waterfall_splitter.sashpos(0,int(height*0.67))
        except tk.TclError:
            pass

    def _build_wsjtx_functions_panel(self, parent):
        """Scrollable WSJT-X operating workspace; local message preparation is clearly separated from TX."""
        shell = ttk.Frame(parent, style="Panel.TFrame")
        shell.pack(fill="both", expand=True)
        canvas = tk.Canvas(shell, bg="#0b1a2a", highlightthickness=0)
        vbar = ttk.Scrollbar(shell, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)
        vbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        content = ttk.Frame(canvas, style="Panel.TFrame", padding=4)
        window_id = canvas.create_window((0,0), window=content, anchor="nw")
        content.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window_id, width=e.width))
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
        self.wsjtx_panel_canvas = canvas

        ttk.Label(content, text="WSJT-X FUNCTIONS", style="PanelTitle.TLabel").pack(anchor="w")
        ttk.Label(content, text="RECEIVE / DECODE", style="PanelTitle.TLabel").pack(anchor="w", pady=(8,3))
        row=ttk.Frame(content,style="Panel.TFrame"); row.pack(fill="x",pady=2)
        ttk.Button(row,text="MONITOR",style="Accent.TButton",command=self.start_listen).pack(side="left",fill="x",expand=True,padx=(0,3))
        ttk.Button(row,text="STOP",command=self.stop_listen).pack(side="left",fill="x",expand=True,padx=(3,0))
        ttk.Button(content,text="CONNECT WSJT-X",command=self.start_wsjtx_bridge).pack(fill="x",pady=2)
        ttk.Button(content,text="ERASE DECODE TEXT",command=self._panel_erase_decode).pack(fill="x",pady=2)

        ttk.Separator(content).pack(fill="x",pady=7)
        ttk.Label(content,text="QSO SETUP",style="PanelTitle.TLabel").pack(anchor="w")
        grid=ttk.Frame(content,style="Panel.TFrame"); grid.pack(fill="x",pady=3)
        ttk.Label(grid,text="DX CALL").grid(row=0,column=0,sticky="w")
        ttk.Label(grid,text="DX GRID").grid(row=0,column=1,sticky="w",padx=(6,0))
        self.panel_dx_call_edit=tk.StringVar(value="")
        self.panel_dx_grid_edit=tk.StringVar(value="")
        ttk.Entry(grid,textvariable=self.panel_dx_call_edit,width=13).grid(row=1,column=0,sticky="ew")
        ttk.Entry(grid,textvariable=self.panel_dx_grid_edit,width=9).grid(row=1,column=1,sticky="ew",padx=(6,0))
        grid.columnconfigure(0,weight=3); grid.columnconfigure(1,weight=2)
        row=ttk.Frame(content,style="Panel.TFrame"); row.pack(fill="x",pady=2)
        ttk.Button(row,text="LOOKUP",command=self._panel_lookup).pack(side="left",fill="x",expand=True,padx=(0,3))
        ttk.Button(row,text="ADD TO LOG",command=self._panel_add_log).pack(side="left",fill="x",expand=True,padx=(3,0))
        self.panel_az_distance=tk.StringVar(value="Az: —     Distance: —")
        ttk.Label(content,textvariable=self.panel_az_distance,style="Sub.TLabel").pack(anchor="w",pady=(2,4))

        ttk.Separator(content).pack(fill="x",pady=7)
        ttk.Label(content,text="TRANSMIT / RECEIVE SETTINGS",style="PanelTitle.TLabel").pack(anchor="w")
        self.panel_tx_even=tk.BooleanVar(value=True)
        self.panel_hold_tx=tk.BooleanVar(value=False)
        row=ttk.Frame(content,style="Panel.TFrame"); row.pack(fill="x",pady=2)
        ttk.Checkbutton(row,text="TX EVEN / 1ST",variable=self.panel_tx_even).pack(side="left")
        ttk.Checkbutton(row,text="HOLD TX FREQ",variable=self.panel_hold_tx).pack(side="left",padx=(8,0))
        self.panel_tx_hz=tk.IntVar(value=1500)
        self.panel_rx_hz=tk.IntVar(value=1500)
        self.panel_report=tk.StringVar(value="-10")
        for label,var in [("TX Hz",self.panel_tx_hz),("RX Hz",self.panel_rx_hz)]:
            r=ttk.Frame(content,style="Panel.TFrame"); r.pack(fill="x",pady=1)
            ttk.Label(r,text=label,width=8).pack(side="left")
            ttk.Spinbox(r,from_=200,to=5000,increment=1,textvariable=var,width=8).pack(side="left")
            ttk.Button(r,text="−",width=3,command=lambda v=var:self._panel_adjust_hz(v,-10)).pack(side="left",padx=2)
            ttk.Button(r,text="+",width=3,command=lambda v=var:self._panel_adjust_hz(v,10)).pack(side="left")
        row=ttk.Frame(content,style="Panel.TFrame"); row.pack(fill="x",pady=2)
        ttk.Label(row,text="REPORT").pack(side="left")
        ttk.Combobox(row,textvariable=self.panel_report,state="readonly",width=8,
                     values=["-30","-24","-20","-18","-15","-12","-10","-8","-5","-3","0","+3","+5"]).pack(side="left",padx=6)
        self.panel_auto_seq=tk.BooleanVar(value=False)
        self.panel_cq_distance=tk.StringVar(value="Max Dist")
        row=ttk.Frame(content,style="Panel.TFrame"); row.pack(fill="x",pady=2)
        ttk.Checkbutton(row,text="AUTO SEQ (local preference)",variable=self.panel_auto_seq).pack(side="left")
        ttk.Combobox(row,textvariable=self.panel_cq_distance,state="readonly",width=12,
                     values=["Max Dist","Any Distance","Within 500 km","Within 1000 km","Within 3000 km"]).pack(side="right")

        ttk.Separator(content).pack(fill="x",pady=7)
        ttk.Label(content,text="STANDARD MESSAGE SEQUENCER",style="PanelTitle.TLabel").pack(anchor="w")
        ttk.Button(content,text="GENERATE STANDARD MESSAGES",style="Accent.TButton",
                   command=self._panel_generate_messages).pack(fill="x",pady=3)
        self.panel_message_vars=[tk.StringVar(value="") for _ in range(6)]
        self.panel_message_choice=tk.IntVar(value=0)
        for n,var in enumerate(self.panel_message_vars,1):
            r=ttk.Frame(content,style="Panel.TFrame"); r.pack(fill="x",pady=1)
            ttk.Radiobutton(r,variable=self.panel_message_choice,value=n-1).pack(side="left")
            ttk.Entry(r,textvariable=var).pack(side="left",fill="x",expand=True,padx=3)
            ttk.Button(r,text=f"TX {n}",width=5,command=lambda k=n-1:self._panel_select_message(k)).pack(side="right")
        row=ttk.Frame(content,style="Panel.TFrame"); row.pack(fill="x",pady=4)
        ttk.Button(row,text="NEXT",command=self._panel_next_message).pack(side="left",fill="x",expand=True,padx=(0,3))
        ttk.Button(row,text="NOW",command=self._panel_now_message).pack(side="left",fill="x",expand=True,padx=(3,0))
        ttk.Label(content,text="Message selection and generation are local preparation only. WSJT-X UDP does not expose direct editing of these six Tx message slots or its Enable Tx / Tune / power controls. TX buttons here do not key the transmitter.",
                  wraplength=330,justify="left",foreground="#ffca69").pack(anchor="w",pady=(5,8))
        ttk.Separator(content).pack(fill="x",pady=7)
        ttk.Label(content,text="TRANSMITTER SAFETY",style="PanelTitle.TLabel").pack(anchor="w")
        row=ttk.Frame(content,style="Panel.TFrame"); row.pack(fill="x",pady=2)
        ttk.Button(row,text="REPLY TO SELECTED CQ / QRZ",style="Accent.TButton",
                   command=self.reply_selected_station).pack(side="left",fill="x",expand=True,padx=(0,3))
        ttk.Button(row,text="HALT TX NOW",command=self.halt_tx).pack(side="left",fill="x",expand=True,padx=(3,0))
        ttk.Button(content,text="WORKED STATIONS / LOG",command=self.open_worked_stations).pack(fill="x",pady=2)
        self.panel_dx_call=tk.StringVar(value="No station selected")
        self.panel_dx_message=tk.StringVar(value="Select a row in Incoming Stations.")
        try:
            self.station_tree.bind("<<TreeviewSelect>>",self._update_wsjtx_panel_selection,add="+")
        except Exception:
            pass

    def _panel_adjust_hz(self, variable, delta):
        try: variable.set(max(200,min(5000,int(variable.get())+delta)))
        except Exception: variable.set(1500)

    def _panel_select_message(self, index):
        self.panel_message_choice.set(index)
        # Deliberately selection-only: no RF transmission is triggered here.
        self.status.set(f"TX MESSAGE {index+1} SELECTED — NOT SENT")

    def _panel_next_message(self):
        self.panel_message_choice.set((self.panel_message_choice.get()+1)%6)
        self._panel_now_message()

    def _panel_now_message(self):
        index=self.panel_message_choice.get()
        value=self.panel_message_vars[index].get().strip()
        self.status.set(f"TX MESSAGE {index+1} READY — NOT SENT")
        self._log(f"Message {index+1} selected for operator review: {value or '[empty]'}. No transmission requested.")

    def _panel_generate_messages(self):
        call=self.panel_dx_call_edit.get().strip().upper()
        own=self.lookup_call.get().strip().upper()
        grid=self.panel_dx_grid_edit.get().strip().upper()
        report=self.panel_report.get().strip()
        if not call or call=="UNKNOWN":
            messagebox.showinfo("Standard messages","Select a decoded station or enter its callsign first."); return
        if not own:
            messagebox.showinfo("Standard messages","Set your own callsign in Settings first."); return
        msgs=[f"{call} {own} {report}",f"{call} {own} R{report}",
              f"{call} {own} RR73",f"{call} {own} 73",
              f"{own} {call} 73",f"CQ {own} {self.lookup_grid.get().strip().upper()}".strip()]
        if grid and len(grid)>=4:
            msgs[0]=f"{call} {own} {report}"
        for var,value in zip(self.panel_message_vars,msgs): var.set(value[:37])
        self.panel_message_choice.set(0)
        self.status.set("STANDARD MESSAGES GENERATED — REVIEW BEFORE USE")
        self._log(f"Generated six local standard-message drafts for {call}; no TX command was sent.")

    def _panel_lookup(self):
        call=self.panel_dx_call_edit.get().strip().upper()
        if not call:
            messagebox.showinfo("Lookup","Enter or select a DX callsign first."); return
        self.lookup_call.set(call)
        self._dx_lookup_selected()

    def _panel_add_log(self):
        call=self.panel_dx_call_edit.get().strip().upper()
        if not call:
            messagebox.showinfo("Add to log","Enter or select a DX callsign first."); return
        self.lookup_call.set(call)
        self._log(f"Operator added {call} as a DX log candidate. This is not a completed ADIF QSO.")
        messagebox.showinfo("DX candidate",f"{call} added to the ARES-X event log as a candidate. It is not marked QSO complete.")

    def _update_wsjtx_panel_selection(self, _event=None):
        try:
            selected = self.station_tree.selection()
            if not selected:
                self.panel_dx_call.set("No station selected")
                self.panel_dx_message.set("Select a row in Incoming Stations.")
                return
            item = self.station_rows.get(selected[0])
            if not item:
                return
            tokens = item.message.split()
            call = next((t for t in tokens if any(c.isdigit() for c in t) and any(c.isalpha() for c in t)), "Station")
            self.panel_dx_call.set(call)
            self.panel_dx_message.set(f"{item.mode}  |  {item.snr_db:+d} dB  |  {item.audio_hz} Hz\\n{item.message}")
            if hasattr(self,"panel_dx_call_edit"):
                parsed_call, parsed_grid = self._decode_identity(item.message)
                self.panel_dx_call_edit.set(parsed_call if parsed_call != "Unknown" else call)
                self.panel_dx_grid_edit.set(parsed_grid if parsed_grid != "—" else "")
                self.panel_rx_hz.set(int(item.audio_hz))
                if not self.panel_hold_tx.get():
                    self.panel_tx_hz.set(int(item.audio_hz))
                self.panel_az_distance.set("Grid: " + (parsed_grid if parsed_grid != "—" else "not decoded"))
        except Exception:
            pass

    def _panel_erase_decode(self):
        # Clears only ARES-X's local decoder text view; it does not alter WSJT-X's own decode panes.
        try:
            self.result.delete("1.0", "end")
            self.result.insert("end", "Decoder output cleared in ARES-X. Incoming Stations history is unchanged.\\n")
            self._log("ARES-X decoder text view cleared from the right-side functions panel.")
        except Exception as exc:
            self._log(f"Could not clear decoder text: {exc}")

    def _set_workspace_splitter_position(self):
        try:
            width = self.workspace_splitter.winfo_width()
            if width > 500:
                # Keep a useful right-side expansion bay visible on first launch.
                self.workspace_splitter.sashpos(0, max(500, width - 485))
        except Exception:
            pass

    def _set_main_splitter_position(self):
        """Start with the digital workspace slightly wider; user can drag either way."""
        try:
            width = self.main_splitter.winfo_width()
            if width > 100:
                self.main_splitter.sashpos(0, int(width * 0.53))
        except tk.TclError:
            pass

    def _set_right_splitter_position(self):
        """Give Incoming Stations a useful initial height while keeping spectrum/log visible."""
        try:
            height = self.right_splitter.winfo_height()
            if height > 180:
                self.right_splitter.sashpos(0, int(height * 0.43))
        except tk.TclError:
            pass

    def _build_extension_tabs(self):
        """Additive UI scaffolding for the standalone roadmap. Existing tabs and behavior remain unchanged."""
        pages = [
            ("WIDE GRAPH", "WIDE GRAPH", [
                ("Display", "Expanded spectrum and waterfall workspace is planned for a later tested increment."),
                ("Controls", "Frequency range, gain, averaging, and palette controls will be wired to a real signal source in a future version."),
            ]),
            ("DECODE", "CW DECODER / ENCODER", []),
            ("LOGBOOK", "QSO LOGBOOK", [
                ("Contact records", "The existing worked-station and event tools remain available under TOOLS."),
                ("Future additions", "A dedicated QSO logbook, search, and ADIF export will be added and tested in a later version."),
            ]),
        ]
        for tab_title, heading, items in pages:
            page = ttk.Frame(self.main_tabs, padding=18)
            self.main_tabs.add(page, text=f"  {tab_title}  ")
            if tab_title == "LOGBOOK":
                self._build_logbook_page(page)
                continue
            if tab_title == "WIDE GRAPH":
                self._build_wide_graph_page(page)
                continue
            if tab_title == "DECODE":
                self._build_cw_page(page)
                continue
            panel = ttk.Frame(page, style="Panel.TFrame", padding=22)
            panel.pack(fill="both", expand=True)
            ttk.Label(panel, text=heading, style="Title.TLabel").pack(anchor="w", pady=(0, 8))
            ttk.Label(
                panel,
                text="STANDALONE EVOLUTION • UI PREVIEW",
                style="Sub.TLabel",
            ).pack(anchor="w", pady=(0, 18))
            for label, description in items:
                row = ttk.Frame(panel, style="Panel.TFrame", padding=(12, 10))
                row.pack(fill="x", pady=5)
                ttk.Label(row, text=label.upper(), style="PanelTitle.TLabel", width=20).pack(side="left", anchor="n")
                ttk.Label(row, text=description, wraplength=850, justify="left").pack(side="left", fill="x", expand=True, padx=(12, 0))
            ttk.Label(
                panel,
                text="This page is an additive scaffold. Existing ARES-X functions and WSJT-X integration are unchanged.",
                style="Sub.TLabel",
                wraplength=900,
                justify="left",
            ).pack(anchor="w", pady=(20, 0))



    _MORSE = {
        "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".", "F": "..-.",
        "G": "--.", "H": "....", "I": "..", "J": ".---", "K": "-.-", "L": ".-..",
        "M": "--", "N": "-.", "O": "---", "P": ".--.", "Q": "--.-", "R": ".-.",
        "S": "...", "T": "-", "U": "..-", "V": "...-", "W": ".--", "X": "-..-",
        "Y": "-.--", "Z": "--..", "0": "-----", "1": ".----", "2": "..---",
        "3": "...--", "4": "....-", "5": ".....", "6": "-....", "7": "--...",
        "8": "---..", "9": "----.", ".": ".-.-.-", ",": "--..--", "?": "..--..",
        "/": "-..-.", "=": "-...-", "+": ".-.-.", "-": "-....-", "'": ".----.",
        "(": "-.--.", ")": "-.--.-", ":": "---...", ";": "-.-.-.", "@": ".--.-."
    }

    def _build_cw_page(self, parent):
        shell=ttk.Frame(parent,style="Panel.TFrame",padding=18); shell.pack(fill="both",expand=True)
        ttk.Label(shell,text="CW DECODER / ENCODER",style="Title.TLabel").pack(anchor="w")
        ttk.Label(shell,text="LIVE CW RECEIVE • CWU / CWL • VAC AUDIO OR SERIAL KEYING",style="Sub.TLabel").pack(anchor="w",pady=(2,10))
        radio=ttk.Frame(shell,style="Panel.TFrame"); radio.pack(fill="x",pady=(0,8))
        self.cw_frequency=tk.StringVar(value="CAT FREQUENCY: NOT CONNECTED")
        self.cw_band=tk.StringVar(value="ARES BAND: " + (self.band_choice.get().split(" — ",1)[0] if hasattr(self,"band_choice") else "20 m"))
        ttk.Label(radio,textvariable=self.cw_frequency,style="PanelTitle.TLabel").pack(side="left",padx=(0,24))
        ttk.Label(radio,textvariable=self.cw_band,style="PanelTitle.TLabel").pack(side="left")
        ttk.Label(radio,text="Frequency follows live CAT; band follows ARES band selection.",style="Sub.TLabel").pack(side="right")
        rx=ttk.Frame(shell,style="Panel.TFrame"); rx.pack(fill="x",pady=(0,8))
        ttk.Label(rx,text="RECEIVE AUDIO INPUT").pack(side="left")
        self.cw_audio_input=tk.StringVar(value=self.audio_device.get() if hasattr(self,"audio_device") else "Default input")
        self.cw_audio_input_box=ttk.Combobox(rx,textvariable=self.cw_audio_input,state="readonly",width=36,values=self.audio_box.cget("values") if hasattr(self,"audio_box") else ["Default input"])
        self.cw_audio_input_box.pack(side="left",padx=8)
        ttk.Button(rx,text="REFRESH INPUTS",command=self._cw_refresh_inputs).pack(side="left",padx=4)
        ttk.Button(rx,text="CONNECT",style="Accent.TButton",command=self._cw_connect_rx).pack(side="left",padx=(12,4))
        ttk.Button(rx,text="DISCONNECT",command=self._cw_disconnect_rx).pack(side="left",padx=4)
        self.cw_mode=tk.StringVar(value=self.saved_settings.get("cw_mode","CWU"))
        controls=ttk.Frame(shell,style="Panel.TFrame"); controls.pack(fill="x",pady=(0,8))
        ttk.Label(controls,text="MODE").pack(side="left")
        ttk.Combobox(controls,textvariable=self.cw_mode,state="readonly",values=["CWU","CWL"],width=8).pack(side="left",padx=(6,18))
        self.cw_method=tk.StringVar(value=self.saved_settings.get("cw_method","VAC AUDIO"))
        ttk.Label(controls,text="KEYING").pack(side="left")
        ttk.Combobox(controls,textvariable=self.cw_method,state="readonly",values=["VAC AUDIO","SERIAL RTS","SERIAL DTR"],width=14).pack(side="left",padx=6)
        self.cw_wpm=tk.IntVar(value=int(self.saved_settings.get("cw_wpm",20)))
        ttk.Label(controls,text="WPM").pack(side="left",padx=(14,4)); ttk.Spinbox(controls,from_=5,to=60,textvariable=self.cw_wpm,width=5).pack(side="left")
        self.cw_tone=tk.IntVar(value=int(self.saved_settings.get("cw_tone",700)))
        ttk.Label(controls,text="TONE Hz").pack(side="left",padx=(14,4)); ttk.Spinbox(controls,from_=300,to=1200,textvariable=self.cw_tone,width=6).pack(side="left")
        self.cw_key_port=tk.StringVar(value=self.saved_settings.get("cw_key_port","COM4"))
        ttk.Label(controls,text="KEY PORT").pack(side="left",padx=(14,4)); ttk.Entry(controls,textvariable=self.cw_key_port,width=8).pack(side="left")
        self.cw_audio_output=tk.StringVar(value=self.saved_settings.get("cw_audio_output","Default output"))
        try:
            import sounddevice as sd
            self._cw_output_devices=[(i,d["name"]) for i,d in enumerate(sd.query_devices()) if d.get("max_output_channels",0)>0]
            output_names=["Default output"]+[f"{i}: {name}" for i,name in self._cw_output_devices]
        except Exception:
            self._cw_output_devices=[]; output_names=["Default output"]
        ttk.Label(controls,text="VAC OUT").pack(side="left",padx=(12,4)); ttk.Combobox(controls,textvariable=self.cw_audio_output,state="readonly",values=output_names,width=22).pack(side="left")
        self.cw_tx_enable=tk.BooleanVar(value=False)
        ttk.Checkbutton(shell,text="TX ENABLE — required before TRANSMIT can key the transmitter",variable=self.cw_tx_enable).pack(anchor="w",pady=(3,8))
        ttk.Label(shell,text="LIVE CW DECODES",style="PanelTitle.TLabel").pack(anchor="w")
        self.cw_decode_text=tk.Text(shell,height=8,bg="#06101b",fg="#9fffc2",insertbackground="white",font=("Consolas",13),relief="flat",wrap="word")
        self.cw_decode_text.pack(fill="both",expand=True,pady=(5,10)); self.cw_decode_text.configure(state="disabled")
        ttk.Label(shell,text="CW MESSAGE — TYPE TEXT AND PRESS ENTER TO TRANSMIT",style="PanelTitle.TLabel").pack(anchor="w")
        self.cw_message=tk.Text(shell,height=4,bg="#06101b",fg="#b9eaff",insertbackground="white",font=("Consolas",14),relief="flat",wrap="word")
        self.cw_message.pack(fill="x",pady=(5,8)); self.cw_message.insert("1.0","CQ CQ CQ DE N2MDX K"); self.cw_message.bind("<Return>",self._cw_enter_transmit)
        row=ttk.Frame(shell,style="Panel.TFrame"); row.pack(fill="x")
        ttk.Button(row,text="TRANSMIT",style="Accent.TButton",command=self._cw_transmit).pack(side="left",padx=(0,8))
        ttk.Button(row,text="STOP",command=self._cw_stop).pack(side="left",padx=4)
        ttk.Button(row,text="CLEAR",command=lambda:self.cw_message.delete("1.0","end")).pack(side="left",padx=4)
        ttk.Button(row,text="OPEN CW SKIMMER",command=self._cw_open_skimmer).pack(side="right")
        self.cw_skimmer_path=tk.StringVar(value=self.saved_settings.get("cw_skimmer_path",""))
        pathrow=ttk.Frame(shell,style="Panel.TFrame"); pathrow.pack(fill="x",pady=(8,0))
        ttk.Label(pathrow,text="CW SKIMMER EXE").pack(side="left"); ttk.Entry(pathrow,textvariable=self.cw_skimmer_path).pack(side="left",fill="x",expand=True,padx=6)
        ttk.Button(pathrow,text="BROWSE",command=self._cw_browse_skimmer).pack(side="left")
        self.cw_status=tk.StringVar(value="READY — CONNECT TO START LIVE CW RECEIVE")
        ttk.Label(shell,textvariable=self.cw_status,style="Sub.TLabel").pack(anchor="w",pady=(8,0))
        ttk.Label(shell,text="TX safety: TX ENABLE and TRANSMIT are both required. Live CAT frequency is read from the connected radio; the selected ARES band is shown separately. Confirm VAC routing, keying interface, mode, power and antenna before transmitting.",style="Sub.TLabel",wraplength=1100).pack(anchor="w",pady=(5,0))
        self.band_choice.trace_add("write",lambda *_:self._cw_update_radio_display())

    def _cw_refresh_inputs(self):
        self.refresh_audio_devices()
        if hasattr(self,"cw_audio_input_box"):
            self.cw_audio_input_box.configure(values=self.audio_box.cget("values"))
            if self.cw_audio_input.get() not in self.audio_box.cget("values"):
                self.cw_audio_input.set(self.audio_device.get())

    def _cw_update_radio_display(self):
        band=self.band_choice.get().split(" — ",1)[0] if hasattr(self,"band_choice") else "—"
        self.cw_band.set("ARES BAND: "+band)
        if self.cat_connected and self.cat and self.cat.frequency_hz:
            self.cw_live_frequency=self.cat.frequency_hz
            self.cw_frequency.set(f"LIVE CAT: {self.cat.frequency_hz/1e6:.6f} MHz")
        else:
            self.cw_live_frequency=None
            self.cw_frequency.set("CAT FREQUENCY: NOT CONNECTED")

    def _cw_connect_rx(self):
        if self._cw_rx_active:return
        try:
            import sounddevice as sd
            selected=self.cw_audio_input.get()
            device=None if selected=="Default input" else int(selected.split(" | ",1)[0])
            info=sd.query_devices(device,"input")
            rate=int(round(float(info.get("default_samplerate") or 48000)))
            channels=max(1,min(2,int(info.get("max_input_channels",1))))
            sd.check_input_settings(device=device,samplerate=rate,channels=channels,dtype="float32")
        except Exception as exc:
            messagebox.showerror("CW receive audio",f"Select the VAC recording/input endpoint and check its Windows routing.\n\n{exc}");return
        self._cw_rx_stop.clear(); self._cw_rx_active=True
        self.cw_status.set(f"CONNECTED — LISTENING {rate} Hz • {info['name']}")
        self._cw_rx_thread=threading.Thread(target=self._cw_rx_worker,args=(device,rate,channels),daemon=True);self._cw_rx_thread.start()
        self._log(f"CW receive connected to {info['name']} at {rate} Hz.")

    def _cw_disconnect_rx(self):
        self._cw_rx_stop.set(); self._cw_rx_active=False
        try:
            if self._cw_rx_stream:self._cw_rx_stream.stop();self._cw_rx_stream.close()
        except Exception:pass
        self._cw_rx_stream=None
        if hasattr(self,"cw_status"):self.cw_status.set("CW RECEIVE DISCONNECTED")

    def _cw_rx_worker(self,device,rate,channels):
        try:
            import sounddevice as sd
            q=self._cw_rx_queue
            state={"key":False,"edge":time.monotonic(),"symbols":"","text":"","noise":0.0008,"last_emit":0.0}
            def callback(indata,frames,time_info,status):
                x=indata.mean(axis=1).astype(np.float32,copy=False)
                n=len(x)
                if n<8:return
                t=np.arange(n,dtype=np.float32)/rate; tone=max(300,min(1200,int(self.cw_tone.get())))
                c=np.cos(2*np.pi*tone*t); si=np.sin(2*np.pi*tone*t)
                energy=float(np.sqrt(np.mean(x*x))+1e-12)
                band=float(2*np.sqrt(np.mean(x*c)**2+np.mean(x*si)**2))
                now=time.monotonic()
                # Track a slow noise floor; require a clear tone component above it.
                state["noise"] = state["noise"]*0.995 + min(energy,0.02)*0.005
                keyed=(band>max(0.0018,state["noise"]*2.8) and energy>0.002)
                if keyed!=state["key"]:
                    q.put(("edge",now,keyed));state["key"]=keyed
            with sd.InputStream(device=device,samplerate=rate,channels=channels,dtype="float32",callback=callback,blocksize=max(256,int(rate*0.02))):
                self._cw_rx_stream=True
                while not self._cw_rx_stop.wait(0.02):
                    try:kind,stamp,key=q.get_nowait()
                    except queue.Empty:continue
                    if kind!="edge":continue
                    elapsed=max(0.001,stamp-state["edge"]);state["edge"]=stamp
                    dot=1.2/max(5,min(60,int(self.cw_wpm.get())))
                    if key:
                        if elapsed>dot*2.2 and state["symbols"]:
                            self._cw_rx_emit_letter(state)
                        if elapsed>dot*6.0 and state["text"] and not state["text"].endswith(" "):
                            self._cw_rx_emit_space(state)
                    else:
                        dot=1.2/max(5,min(60,int(self.cw_wpm.get())))
                        if elapsed<dot*2.0:state["symbols"]+="."
                        else:state["symbols"]+="-"
                        if elapsed>dot*7: self._cw_rx_emit_letter(state)
                    # Gaps are finalized by the idle timer below.
                    idle=time.monotonic()-state["edge"]
                    dot=1.2/max(5,min(60,int(self.cw_wpm.get())))
                    if not state["key"] and state["symbols"] and idle>dot*3.0:self._cw_rx_emit_letter(state)
                    if not state["key"] and state["text"] and idle>dot*7.0:self._cw_rx_emit_space(state)
            self._cw_rx_stream=None
        except Exception as exc:
            self.after(0,lambda e=str(exc):self.cw_status.set("CW RX ERROR: "+e))
        finally:
            self._cw_rx_active=False
            try:self.after(0,lambda:self.cw_status.set("CW RECEIVE STOPPED"))
            except Exception:pass

    def _cw_rx_emit_letter(self,state):
        code=state["symbols"];state["symbols"]=""
        if not code:return
        reverse={v:k for k,v in self._MORSE.items()};ch=reverse.get(code,"?");state["text"]+=ch
        try:self.after(0,lambda c=ch:self._cw_append_decode(c))
        except Exception:pass

    def _cw_rx_emit_space(self,state):
        state["text"]+=" ";
        try:self.after(0,lambda:self._cw_append_decode(" "))
        except Exception:pass

    def _cw_append_decode(self,ch):
        if not hasattr(self,"cw_decode_text"):return
        self.cw_decode_text.configure(state="normal");self.cw_decode_text.insert("end",ch);self.cw_decode_text.see("end");self.cw_decode_text.configure(state="disabled")

    def _cw_enter_transmit(self,event=None):
        self._cw_transmit()
        return "break"

    def _cw_browse_skimmer(self):
        path=filedialog.askopenfilename(title="Select CW Skimmer",filetypes=[("Applications","*.exe"),("All files","*.*")])
        if path:self.cw_skimmer_path.set(path); self._save_settings()

    def _cw_open_skimmer(self):
        import subprocess
        path=self.cw_skimmer_path.get().strip()
        if not path or not os.path.isfile(path):
            messagebox.showinfo("CW Skimmer","Browse to your CW Skimmer executable first."); return
        try:
            subprocess.Popen([path],cwd=os.path.dirname(path) or None)
            self.cw_status.set("CW SKIMMER LAUNCHED")
        except Exception as exc: messagebox.showerror("CW Skimmer",str(exc))

    def _cw_stop(self):
        self._cw_stop_event.set()
        self._cw_disconnect_rx()
        try:
            import sounddevice as sd
            sd.stop()
        except Exception: pass
        try:
            if getattr(self,"_cw_serial",None):
                self._cw_serial.rts=False; self._cw_serial.dtr=False; self._cw_serial.close(); self._cw_serial=None
        except Exception: pass
        self.cw_status.set("STOP REQUESTED — KEYING RELEASED")

    def _cw_transmit(self):
        import threading
        if not self.cw_tx_enable.get():
            messagebox.showwarning("CW transmit disabled","Enable TX ENABLE before transmitting. Check your radio, frequency, antenna, and keying method.")
            return
        if not self.cat_connected or not self.cat or not self.cat.frequency_hz:
            messagebox.showwarning("Radio CAT not connected","Connect ARES-X CAT first. CW transmit is blocked until the radio's live frequency is confirmed.")
            return
        try:
            self.cat.set_mode("CWL" if self.cw_mode.get()=="CWL" else "CWU")
        except Exception as exc:
            messagebox.showerror("CW mode command failed",str(exc));return
        msg=self.cw_message.get("1.0","end-1c").strip().upper()
        if not msg:return
        if self.cw_method.get()=="VAC AUDIO":
            threading.Thread(target=self._cw_send_audio,args=(msg,),daemon=True).start()
        else:
            threading.Thread(target=self._cw_send_serial,args=(msg,),daemon=True).start()

    def _cw_send_audio(self,msg):
        try:
            self._cw_stop_event.clear()
            import sounddevice as sd
            sr=48000; dot=1.2/max(5,min(60,int(self.cw_wpm.get())))
            tone=max(300,min(1200,int(self.cw_tone.get())))
            chunks=[]
            def silence(units): chunks.append(np.zeros(int(sr*dot*units),dtype=np.float32))
            def mark(units):
                n=int(sr*dot*units); t=np.arange(n,dtype=np.float32)/sr
                chunks.append((0.22*np.sin(2*np.pi*tone*t)).astype(np.float32))
            for wi,word in enumerate(msg.split()):
                for ci,ch in enumerate(word):
                    code=self._MORSE.get(ch)
                    if not code: continue
                    for si,sym in enumerate(code):
                        mark(1 if sym=="." else 3)
                        if si<len(code)-1:silence(1)
                    if ci<len(word)-1:silence(3)
                if wi<len(msg.split())-1:silence(4)
            audio=np.concatenate(chunks) if chunks else np.zeros(1,dtype=np.float32)
            self.after(0,lambda:self.cw_status.set("TRANSMITTING CW VIA AUDIO"))
            output_choice=self.cw_audio_output.get()
            output_device=None
            if output_choice!="Default output":
                output_device=int(output_choice.split(":",1)[0])
            sd.play(audio,sr,device=output_device,blocking=True)
            self.after(0,lambda:self.cw_status.set("CW MESSAGE COMPLETE"))
        except Exception as exc:
            self.after(0,lambda e=str(exc):self.cw_status.set("VAC AUDIO ERROR: "+e))
            self.after(0,lambda e=str(exc):messagebox.showerror("CW audio transmit",e))

    def _cw_send_serial(self,msg):
        ser=None
        try:
            import serial, time
            port=self.cw_key_port.get().strip()
            if not port: raise RuntimeError("Enter the dedicated CW keying COM port.")
            ser=serial.Serial(port,baudrate=9600,timeout=0)
            self._cw_serial=ser
            use_rts=self.cw_method.get()=="SERIAL RTS"
            dot=1.2/max(5,min(60,int(self.cw_wpm.get())))
            self.after(0,lambda:self.cw_status.set("TRANSMITTING CW VIA SERIAL KEYER"))
            self._cw_stop_event.clear()
            for wi,word in enumerate(msg.split()):
                if self._cw_stop_event.is_set(): break
                for ci,ch in enumerate(word):
                    if self._cw_stop_event.is_set(): break
                    code=self._MORSE.get(ch)
                    if not code: continue
                    for si,sym in enumerate(code):
                        if self._cw_stop_event.is_set(): break
                        if use_rts: ser.rts=True
                        else: ser.dtr=True
                        time.sleep(dot*(1 if sym=="." else 3))
                        if use_rts: ser.rts=False
                        else: ser.dtr=False
                        if si<len(code)-1 and not self._cw_stop_event.is_set():time.sleep(dot)
                    if ci<len(word)-1 and not self._cw_stop_event.is_set():time.sleep(dot*3)
                if wi<len(msg.split())-1 and not self._cw_stop_event.is_set():time.sleep(dot*4)
            self.after(0,lambda:self.cw_status.set("CW MESSAGE COMPLETE"))
        except Exception as exc:
            self.after(0,lambda e=str(exc):self.cw_status.set("SERIAL KEYER ERROR: "+e))
            self.after(0,lambda e=str(exc):messagebox.showerror("CW serial transmit",e))
        finally:
            try:
                if ser:
                    ser.rts=False; ser.dtr=False; ser.close()
                self._cw_serial=None
            except Exception:pass

    def _build_wide_graph_page(self, parent):
        """Full-size live audio spectrum/waterfall workspace, reusing the existing VAC FFT source."""
        shell=ttk.Frame(parent,style="Panel.TFrame",padding=8); shell.pack(fill="both",expand=True)
        top=ttk.Frame(shell,style="Panel.TFrame"); top.pack(fill="x",pady=(0,6))
        ttk.Label(top,text="WIDE GRAPH • LIVE SIGNAL DISPLAY",style="Title.TLabel").pack(side="left")
        self.wg_status=tk.StringVar(value="WAITING FOR LIVE AUDIO")
        ttk.Label(top,textvariable=self.wg_status,style="Sub.TLabel").pack(side="right")
        self.wg_ruler=tk.Canvas(shell,height=34,bg="#071522",highlightthickness=0); self.wg_ruler.pack(fill="x")
        self.wg_waterfall=tk.Canvas(shell,height=300,bg="#030a12",highlightthickness=0); self.wg_waterfall.pack(fill="both",expand=True,pady=(0,6))
        self.wg_spectrum=tk.Canvas(shell,height=190,bg="#030a12",highlightthickness=0); self.wg_spectrum.pack(fill="x",pady=(0,8))
        controls=ttk.Frame(shell,style="Panel.TFrame"); controls.pack(fill="x",pady=4)
        self.wg_rx=tk.DoubleVar(value=1500.0); self.wg_tx=tk.DoubleVar(value=1500.0)
        ttk.Label(controls,text="RX AUDIO (Hz)",style="PanelTitle.TLabel").grid(row=0,column=0,sticky="w")
        self.wg_rx_read=tk.StringVar(value="1500 Hz")
        ttk.Label(controls,textvariable=self.wg_rx_read,style="Sub.TLabel").grid(row=0,column=2,sticky="e")
        ttk.Scale(controls,from_=200,to=4000,variable=self.wg_rx,command=lambda v:self._wide_graph_slider_changed("RX",v)).grid(row=0,column=1,sticky="ew",padx=10)
        ttk.Label(controls,text="TX AUDIO (Hz)",style="PanelTitle.TLabel").grid(row=1,column=0,sticky="w")
        self.wg_tx_read=tk.StringVar(value="1500 Hz")
        ttk.Label(controls,textvariable=self.wg_tx_read,style="Sub.TLabel").grid(row=1,column=2,sticky="e")
        ttk.Scale(controls,from_=200,to=4000,variable=self.wg_tx,command=lambda v:self._wide_graph_slider_changed("TX",v)).grid(row=1,column=1,sticky="ew",padx=10)
        controls.columnconfigure(1,weight=1)
        footer=ttk.Frame(shell,style="Panel.TFrame"); footer.pack(fill="x",pady=(5,0))
        ttk.Label(footer,text="VAC AUDIO FFT • RX/TX markers are audio-frequency references; RF tuning remains controlled by the radio/CAT interface.",style="Sub.TLabel").pack(anchor="w")
        self.wg_waterfall.bind("<Configure>",lambda _e:self._wide_graph_render_waterfall())
        self.wg_ruler.bind("<Configure>",lambda _e:self._wide_graph_draw_ruler())
        self._wide_graph_draw_ruler()

    def _wide_graph_slider_changed(self,which,value):
        value=float(value)
        if which=="RX": self.wg_rx_read.set(f"{value:.0f} Hz")
        else: self.wg_tx_read.set(f"{value:.0f} Hz")
        self._wide_graph_draw_ruler()
        self._wide_graph_render_waterfall()

    def _wide_graph_draw_ruler(self,sample_rate=None):
        if not hasattr(self,"wg_ruler"): return
        c=self.wg_ruler; c.delete("all"); w=max(100,c.winfo_width()); sr=float(sample_rate or getattr(self,"audio_sample_rate",48000) or 48000)
        ny=sr/2
        c.create_text(8,2,anchor="nw",fill="#76cfff",text=f"AUDIO FREQUENCY • 0–{ny/1000:.1f} kHz")
        y=18; c.create_line(8,y,w-8,y,fill="#45627a")
        for j in range(9):
            x=8+j*(w-16)/8; hz=ny*j/8
            c.create_line(x,y-4,x,y+5,fill="#8bb7d5")
            c.create_text(x,33,anchor="s",fill="#a9c5d9",font=("Consolas",8),text=f"{hz/1000:.1f}k")

    def _wide_graph_render_waterfall(self):
        """Render the waterfall as one raster image, not thousands of Tk canvas items."""
        if not hasattr(self, "wg_waterfall"):
            return
        c = self.wg_waterfall
        w = max(100, c.winfo_width())
        h = max(60, c.winfo_height())
        history = getattr(self, "_waterfall_history", [])
        c.delete("wg_waterfall_image")
        if not history:
            c.delete("wg_waterfall_empty")
            c.create_text(w/2, h/2, fill="#ffca69",
                          text="Start LISTEN TO INPUT to display live signals",
                          tags="wg_waterfall_empty")
            return
        # Keep the raster modest; Tk receives a single image item per refresh.
        rows = min(len(history), h, 360)
        cols = min(w, 900)
        values = np.empty((rows, cols), dtype=np.float32)
        for ri, vals in enumerate(history[:rows]):
            arr = np.asarray(vals, dtype=np.float32)
            if arr.size < 2:
                values[ri, :] = -120.0
                continue
            values[ri, :] = np.interp(np.linspace(0, arr.size-1, cols),
                                      np.arange(arr.size), arr)
        # Vectorized palette lookup avoids per-pixel Tk canvas calls.
        floor = np.percentile(values, 12)
        span = max(12.0, float(np.percentile(values, 99)) - float(floor))
        norm = np.clip((values - floor) / span, 0.0, 1.0)
        palette_name = self.waterfall_palette.get() if hasattr(self, "waterfall_palette") else "Classic"
        palettes = {
            "Classic": [(0.0,(0,0,18)),(0.25,(0,35,110)),(0.5,(0,180,210)),(0.75,(245,220,30)),(1.0,(255,255,255))],
            "Default": [(0.0,(0,0,18)),(0.25,(0,35,110)),(0.5,(0,180,210)),(0.75,(245,220,30)),(1.0,(255,255,255))],
            "Spectrum": [(0.0,(20,0,50)),(0.25,(0,50,220)),(0.5,(0,220,100)),(0.75,(255,220,0)),(1.0,(255,30,20))],
            "Blue": [(0.0,(0,0,12)),(0.5,(0,70,150)),(1.0,(130,220,255))],
        }
        stops = palettes.get(palette_name, palettes["Classic"])
        rgb = np.zeros((rows, cols, 3), dtype=np.uint8)
        for ch in range(3):
            xp = np.array([v[0] for v in stops], dtype=np.float32)
            fp = np.array([v[1][ch] for v in stops], dtype=np.float32)
            rgb[:,:,ch] = np.interp(norm, xp, fp).astype(np.uint8)
        raster = Image.fromarray(rgb, mode="RGB").resize((w, h), Image.Resampling.BILINEAR)
        self._wg_waterfall_photo = ImageTk.PhotoImage(raster)
        c.create_image(0, 0, image=self._wg_waterfall_photo, anchor="nw", tags="wg_waterfall_image")
        c.tag_lower("wg_waterfall_image")

    def _wide_graph_update(self, samples, sample_rate):
        """Low-cost Wide Graph refresh; cap canvas work to 8 frames per second."""
        if not hasattr(self, "wg_spectrum"):
            return
        now = time.monotonic()
        if now - getattr(self, "_wg_last_update", 0.0) < 0.125:
            return
        self._wg_last_update = now
        c = self.wg_spectrum
        w = max(300, c.winfo_width())
        h = max(100, c.winfo_height())
        c.delete("all")
        for xg in range(0, w, 64):
            c.create_line(xg, 0, xg, h, fill="#183047")
        for yg in range(0, h, 32):
            c.create_line(0, yg, w, yg, fill="#183047")
        n = min(16384, len(samples))
        if n < 64:
            return
        x = np.asarray(samples[-n:], dtype=np.float32)
        x = x - np.mean(x)
        spec = 20*np.log10(np.maximum(np.abs(np.fft.rfft(x*np.hanning(n))), 1e-8))[1:]
        if len(spec) < 2:
            return
        lo = float(np.percentile(spec, 10))
        span = max(10.0, float(np.percentile(spec, 99.5))-lo)
        # Decimate to screen resolution before creating the canvas polyline.
        count = min(700, w)
        sampled = np.interp(np.linspace(0, len(spec)-1, count), np.arange(len(spec)), spec)
        px = np.linspace(1, w-2, count)
        py = h-8-(sampled-lo)/span*(h-24)
        py = np.clip(py, 8, h-8)
        pts = np.column_stack((px, py)).ravel().tolist()
        c.create_line(*pts, fill="#16d6a4", width=1.5, smooth=False)
        ny = float(sample_rate)/2.0
        for val, color, label in ((self.wg_rx.get(), "#38c9ff", "RX"),
                                  (self.wg_tx.get(), "#ffb454", "TX")):
            xx = max(0, min(w-1, float(val)/max(1.0, ny)*w))
            c.create_line(xx, 0, xx, h, fill=color, width=2, dash=(5,3))
            c.create_text(min(w-30, max(25, xx)), 10, fill=color,
                          text=label, font=("Segoe UI", 9, "bold"))
        self.wg_status.set("LIVE VAC AUDIO • FFT ACTIVE")
        self._wide_graph_draw_ruler(sample_rate)
        # Waterfall is refreshed independently at 4 Hz, not on every audio block.
        if now - getattr(self, "_wg_last_waterfall", 0.0) >= 0.25:
            self._wg_last_waterfall = now
            self._wide_graph_render_waterfall()

    def _init_logbook_db(self):
        self.logbook_db.execute("""
            CREATE TABLE IF NOT EXISTS qsos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                call TEXT NOT NULL, qso_date TEXT NOT NULL, time_on TEXT NOT NULL,
                band TEXT DEFAULT '', mode TEXT DEFAULT '', freq TEXT DEFAULT '',
                rst_sent TEXT DEFAULT '', rst_rcvd TEXT DEFAULT '', grid TEXT DEFAULT '',
                name TEXT DEFAULT '', comment TEXT DEFAULT '', operator_call TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self.logbook_db.execute("CREATE INDEX IF NOT EXISTS idx_qsos_call ON qsos(call)")
        self.logbook_db.execute("CREATE INDEX IF NOT EXISTS idx_qsos_date ON qsos(qso_date)")
        self.logbook_db.commit()

    def _build_logbook_page(self, parent):
        bg="#07111e"; panel="#0c1b2b"; panel2="#10283d"; border="#1b5877"
        cyan="#63d5ff"; muted="#8ba9bf"; white="#eaf5ff"; green="#20df85"
        parent.configure(style="TFrame")
        parent.columnconfigure(0,weight=1); parent.rowconfigure(2,weight=1)
        # Page header / status
        head=tk.Frame(parent,bg=bg); head.grid(row=0,column=0,sticky="ew",pady=(2,12))
        tk.Label(head,text="ADVANCED QSO LOGBOOK",bg=bg,fg=white,font=("Segoe UI",21,"bold")).pack(side="left")
        self.logbook_stats=tk.StringVar(value="0 QSOs  •  0 unique calls")
        tk.Label(head,textvariable=self.logbook_stats,bg=bg,fg=cyan,font=("Segoe UI",9,"bold")).pack(side="right",anchor="s",pady=5)
        # Entry card
        form=tk.Frame(parent,bg=panel,highlightthickness=1,highlightbackground=border,padx=12,pady=10)
        form.grid(row=1,column=0,sticky="ew",pady=(0,10))
        tk.Label(form,text="NEW QSO  /  OPERATOR CONFIRMED",bg=panel,fg=cyan,font=("Segoe UI",9,"bold")).grid(row=0,column=0,columnspan=12,sticky="w",pady=(0,9))
        self.lb_vars={k:tk.StringVar() for k in ("call","date","time","band","mode","freq","rst_sent","rst_rcvd","grid","name","comment","operator_call")}
        now=datetime.datetime.now(datetime.timezone.utc)
        self.lb_vars["date"].set(now.strftime("%Y%m%d")); self.lb_vars["time"].set(now.strftime("%H%M"))
        self.lb_vars["mode"].set("FT8"); self.lb_vars["band"].set("20m")
        self.lb_vars["rst_sent"].set("-10"); self.lb_vars["rst_rcvd"].set("-10")
        fields=[("CALLSIGN","call",16),("DATE UTC","date",10),("TIME UTC","time",8),("BAND","band",9),("MODE","mode",9),("FREQ MHz","freq",11),
                ("RST SENT","rst_sent",9),("RST RCVD","rst_rcvd",9),("GRID","grid",10),("NAME","name",15),("OPERATOR","operator_call",14)]
        # Responsive six-column field layout
        for idx,(label,key,width) in enumerate(fields):
            row=1+(idx//6)*2; col=(idx%6)*2
            tk.Label(form,text=label,bg=panel,fg=muted,font=("Segoe UI",8,"bold")).grid(row=row,column=col,sticky="w",padx=(3,8),pady=(2,3))
            ent=ttk.Entry(form,textvariable=self.lb_vars[key],width=width)
            ent.grid(row=row+1,column=col,sticky="ew",padx=(3,12),pady=(0,7),ipady=3)
            form.grid_columnconfigure(col,weight=1)
        tk.Label(form,text="COMMENTS",bg=panel,fg=muted,font=("Segoe UI",8,"bold")).grid(row=5,column=0,sticky="w",padx=3,pady=(0,3))
        ttk.Entry(form,textvariable=self.lb_vars["comment"]).grid(row=6,column=0,columnspan=10,sticky="ew",padx=(3,12),pady=(0,3),ipady=3)
        actions=tk.Frame(form,bg=panel); actions.grid(row=6,column=10,columnspan=2,sticky="e",padx=3)
        ttk.Button(actions,text="ADD QSO",style="Accent.TButton",command=self._logbook_add).pack(side="left",padx=(0,5))
        ttk.Button(actions,text="CLEAR",style="Logbook.TButton",command=self._logbook_clear).pack(side="left")
        # Search and database actions
        toolbar=tk.Frame(parent,bg=bg); toolbar.grid(row=2,column=0,sticky="ew",pady=(0,7))
        tk.Label(toolbar,text="SEARCH",bg=bg,fg=cyan,font=("Segoe UI",8,"bold")).pack(side="left",padx=(1,6))
        self.lb_search=tk.StringVar()
        search=ttk.Entry(toolbar,textvariable=self.lb_search,width=28); search.pack(side="left",ipady=3)
        search.bind("<KeyRelease>",lambda _e:self._logbook_refresh())
        ttk.Button(toolbar,text="REFRESH",style="Logbook.TButton",command=self._logbook_refresh).pack(side="left",padx=6)
        ttk.Button(toolbar,text="IMPORT ADIF",style="Logbook.TButton",command=self._logbook_import_adif).pack(side="right",padx=(5,0))
        ttk.Button(toolbar,text="EXPORT ADIF",style="Logbook.TButton",command=self._logbook_export_adif).pack(side="right",padx=5)
        ttk.Button(toolbar,text="DELETE SELECTED",style="Logbook.TButton",command=self._logbook_delete).pack(side="right",padx=5)
        # Dark table card
        table_card=tk.Frame(parent,bg=panel,highlightthickness=1,highlightbackground=border)
        table_card.grid(row=3,column=0,sticky="nsew")
        parent.rowconfigure(3,weight=1)
        style=ttk.Style(self)
        style.configure("Logbook.Treeview",background="#081827",foreground="#dceeff",fieldbackground="#081827",
                        rowheight=29,borderwidth=0,font=("Segoe UI",9))
        style.configure("Logbook.Treeview.Heading",background="#12334b",foreground=cyan,
                        font=("Segoe UI",8,"bold"),relief="flat",padding=(7,7))
        style.map("Logbook.Treeview",background=[("selected","#075d91")],foreground=[("selected","#ffffff")])
        style.configure("Logbook.TButton",background="#12334b",foreground="#eaf5ff",padding=(9,6),font=("Segoe UI",8,"bold"))
        style.map("Logbook.TButton",background=[("active","#185477"),("pressed","#087bdc")],foreground=[("active","#ffffff")])
        cols=("date","time","call","band","mode","freq","sent","rcvd","grid","name")
        self.logbook_tree=ttk.Treeview(table_card,columns=cols,show="headings",selectmode="browse",style="Logbook.Treeview")
        titles=("DATE UTC","TIME","CALLSIGN","BAND","MODE","FREQ MHz","SENT","RCVD","GRID","NAME")
        widths=(105,75,145,75,75,90,70,70,90,150)
        for col,title,width in zip(cols,titles,widths):
            self.logbook_tree.heading(col,text=title); self.logbook_tree.column(col,width=width,stretch=col in {"call","name"},anchor="w")
        sy=ttk.Scrollbar(table_card,orient="vertical",command=self.logbook_tree.yview)
        sx=ttk.Scrollbar(parent,orient="horizontal",command=self.logbook_tree.xview)
        self.logbook_tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        self.logbook_tree.pack(side="left",fill="both",expand=True,padx=(5,0),pady=5)
        sy.pack(side="right",fill="y",padx=(0,5),pady=5)
        sx.grid(row=4,column=0,sticky="ew")
        self.logbook_tree.bind("<<TreeviewSelect>>",self._logbook_select)
        foot=tk.Frame(parent,bg=bg); foot.grid(row=5,column=0,sticky="ew",pady=(7,0))
        tk.Label(foot,text="● LOCAL DATABASE",bg=bg,fg=green,font=("Segoe UI",8,"bold")).pack(side="left")
        tk.Label(foot,text="Records are stored locally in SQLite  •  Decodes are never automatically logged as completed QSOs",bg=bg,fg=muted,font=("Segoe UI",8)).pack(side="left",padx=12)
        self._logbook_refresh()

    def _logbook_clear(self):
        for key,var in self.lb_vars.items(): var.set("")
        now=datetime.datetime.now(datetime.timezone.utc)
        self.lb_vars["date"].set(now.strftime("%Y%m%d")); self.lb_vars["time"].set(now.strftime("%H%M"))
        self.lb_vars["band"].set("20m"); self.lb_vars["mode"].set("FT8")
        self.lb_vars["rst_sent"].set("-10"); self.lb_vars["rst_rcvd"].set("-10")
        self.logbook_selected_id=None

    def _logbook_add(self):
        v={k:x.get().strip() for k,x in self.lb_vars.items()}
        v["call"]=v["call"].upper(); v["band"]=v["band"].lower(); v["mode"]=v["mode"].upper()
        if not v["call"]:
            messagebox.showwarning("ARES-X Logbook","Enter a callsign before adding a QSO."); return
        if not re.fullmatch(r"\d{8}",v["date"]) or not re.fullmatch(r"\d{4}",v["time"]):
            messagebox.showwarning("ARES-X Logbook","Use UTC date YYYYMMDD and time HHMM."); return
        duplicate=self.logbook_db.execute("""SELECT id FROM qsos WHERE upper(call)=? AND qso_date=? AND time_on=? AND lower(band)=? AND upper(mode)=?""",
            (v["call"],v["date"],v["time"],v["band"],v["mode"])).fetchone()
        if duplicate:
            if not messagebox.askyesno("Possible duplicate QSO",f"{v['call']} already has a contact at {v['date']} {v['time']} UTC on {v['band']} {v['mode']}. Add another record anyway?"):
                return
        self.logbook_db.execute("""INSERT INTO qsos(call,qso_date,time_on,band,mode,freq,rst_sent,rst_rcvd,grid,name,comment,operator_call)
            VALUES(:call,:date,:time,:band,:mode,:freq,:rst_sent,:rst_rcvd,:grid,:name,:comment,:operator_call)""",v)
        self.logbook_db.commit(); self._logbook_refresh(); self._log(f"QSO manually entered in logbook: {v['call']} {v['band']} {v['mode']} {v['date']} {v['time']} UTC")
        self._logbook_clear()

    def _logbook_refresh(self):
        if not hasattr(self,"logbook_tree"): return
        query=self.lb_search.get().strip() if hasattr(self,"lb_search") else ""
        rows=self.logbook_db.execute("""SELECT * FROM qsos WHERE (?='' OR call LIKE ? OR grid LIKE ? OR name LIKE ? OR band LIKE ? OR mode LIKE ? OR qso_date LIKE ?)
            ORDER BY qso_date DESC,time_on DESC,id DESC LIMIT 5000""",
            (query, f"%{query}%",f"%{query}%",f"%{query}%",f"%{query}%",f"%{query}%",f"%{query}%")).fetchall()
        self.logbook_tree.delete(*self.logbook_tree.get_children())
        for row in rows:
            self.logbook_tree.insert("", "end", iid=str(row["id"]), values=(row["qso_date"],row["time_on"],row["call"],row["band"],row["mode"],row["freq"],row["rst_sent"],row["rst_rcvd"],row["grid"],row["name"]))
        total=self.logbook_db.execute("SELECT COUNT(*) FROM qsos").fetchone()[0]
        worked=self.logbook_db.execute("SELECT COUNT(DISTINCT upper(call)) FROM qsos").fetchone()[0]
        self.logbook_stats.set(f"{total} QSOs  •  {worked} unique calls")

    def _logbook_select(self,_event=None):
        sel=self.logbook_tree.selection()
        if not sel:return
        row=self.logbook_db.execute("SELECT * FROM qsos WHERE id=?",(int(sel[0]),)).fetchone()
        if not row:return
        self.logbook_selected_id=row["id"]
        mapping={"call":"call","date":"qso_date","time":"time_on","band":"band","mode":"mode","freq":"freq","rst_sent":"rst_sent","rst_rcvd":"rst_rcvd","grid":"grid","name":"name","comment":"comment","operator_call":"operator_call"}
        for key,col in mapping.items(): self.lb_vars[key].set(row[col] or "")

    def _logbook_delete(self):
        sel=self.logbook_tree.selection()
        if not sel:
            messagebox.showinfo("Delete QSO","Select a QSO row first."); return
        row=self.logbook_db.execute("SELECT call,qso_date,time_on FROM qsos WHERE id=?",(int(sel[0]),)).fetchone()
        if not row:return
        if not messagebox.askyesno("Confirm delete",f"Delete logged QSO with {row['call']} on {row['qso_date']} at {row['time_on']} UTC?"):return
        self.logbook_db.execute("DELETE FROM qsos WHERE id=?",(int(sel[0]),)); self.logbook_db.commit()
        self._logbook_refresh(); self._log(f"Operator deleted QSO record for {row['call']}.")

    @staticmethod
    def _adif_value(tag, value):
        value=str(value or "")
        return f"<{tag}:{len(value)}>{value}"

    def _logbook_export_adif(self):
        path=filedialog.asksaveasfilename(title="Export ARES-X Logbook",defaultextension=".adi",filetypes=[("ADIF files","*.adi *.adif"),("All files","*.*")])
        if not path:return
        rows=self.logbook_db.execute("SELECT * FROM qsos ORDER BY qso_date,time_on").fetchall()
        fields={"CALL":"call","QSO_DATE":"qso_date","TIME_ON":"time_on","BAND":"band","MODE":"mode","FREQ":"freq","RST_SENT":"rst_sent","RST_RCVD":"rst_rcvd","GRIDSQUARE":"grid","NAME":"name","COMMENT":"comment","OPERATOR":"operator_call"}
        try:
            with open(path,"w",encoding="utf-8") as f:
                f.write("ADIF Export from ARES-X 0.9.3\n<ADIF_VER:5>3.1.4<EOH>\n")
                for row in rows:
                    parts=[self._adif_value(tag,row[col]) for tag,col in fields.items() if row[col] not in (None,"")]
                    f.write("".join(parts)+"<EOR>\n")
            messagebox.showinfo("ADIF Export",f"Exported {len(rows)} QSO records.")
            self._log(f"Exported {len(rows)} QSO records to ADIF: {path}")
        except Exception as exc: messagebox.showerror("ADIF Export",str(exc))

    def _logbook_import_adif(self):
        path=filedialog.askopenfilename(title="Import ADIF Logbook",filetypes=[("ADIF files","*.adi *.adif *.txt"),("All files","*.*")])
        if not path:return
        try:
            raw=Path(path).read_text(encoding="utf-8",errors="replace")
            records=re.split(r"<EOR\s*>",raw,flags=re.I)
            parsed=[]
            for rec in records:
                fields={}
                for m in re.finditer(r"<([A-Z0-9_]+):(\d+)(?::[^>]*)?>([^<]*)",rec,flags=re.I):
                    fields[m.group(1).upper()]=m.group(3)[:int(m.group(2))]
                call=fields.get("CALL","").strip().upper()
                if not call:continue
                date=fields.get("QSO_DATE",fields.get("QSO_DATE_OFF",""))
                tm=fields.get("TIME_ON",fields.get("TIME_OFF","0000"))[:4].ljust(4,"0")
                parsed.append((call,date,tm,fields.get("BAND",""),fields.get("MODE",""),fields.get("FREQ",""),
                    fields.get("RST_SENT",""),fields.get("RST_RCVD",""),fields.get("GRIDSQUARE",fields.get("MY_GRIDSQUARE","")),
                    fields.get("NAME",""),fields.get("COMMENT",""),fields.get("OPERATOR","")))
            if not parsed:
                messagebox.showinfo("ADIF Import","No QSO records with CALL fields were found.");return
            added=dupes=0
            for rec in parsed:
                if not re.fullmatch(r"\d{8}",rec[1]):continue
                exists=self.logbook_db.execute("SELECT 1 FROM qsos WHERE upper(call)=? AND qso_date=? AND time_on=? AND lower(band)=? AND upper(mode)=?",
                    (rec[0],rec[1],rec[2],rec[3].lower(),rec[4].upper())).fetchone()
                if exists:dupes+=1;continue
                self.logbook_db.execute("""INSERT INTO qsos(call,qso_date,time_on,band,mode,freq,rst_sent,rst_rcvd,grid,name,comment,operator_call)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",rec);added+=1
            self.logbook_db.commit();self._logbook_refresh()
            messagebox.showinfo("ADIF Import",f"Imported: {added}\nSkipped duplicates/invalid: {dupes + len(parsed)-added-dupes}")
            self._log(f"ADIF import complete: {added} added, {dupes} duplicates skipped.")
        except Exception as exc:messagebox.showerror("ADIF Import",str(exc))

    @staticmethod
    def _weather_description(code):
        descriptions={0:("Clear sky","☀️"),1:("Mainly clear","🌤️"),2:("Partly cloudy","⛅"),3:("Overcast","☁️"),
            45:("Fog","🌫️"),48:("Rime fog","🌫️"),51:("Light drizzle","🌦️"),53:("Drizzle","🌦️"),55:("Heavy drizzle","🌧️"),
            56:("Freezing drizzle","🌧️"),57:("Heavy freezing drizzle","🌧️"),61:("Light rain","🌦️"),63:("Rain","🌧️"),65:("Heavy rain","🌧️"),
            66:("Freezing rain","🌧️"),67:("Heavy freezing rain","🌧️"),71:("Light snow","🌨️"),73:("Snow","❄️"),75:("Heavy snow","❄️"),
            77:("Snow grains","🌨️"),80:("Rain showers","🌦️"),81:("Showers","🌧️"),82:("Heavy showers","⛈️"),
            85:("Snow showers","🌨️"),86:("Heavy snow showers","❄️"),95:("Thunderstorm","⛈️"),96:("Thunderstorm / hail","⛈️"),99:("Severe thunderstorm","⛈️")}
        return descriptions.get(int(code or -1),("Conditions unavailable","🌡️"))

    def _update_weather_clock(self):
        try:
            now=datetime.datetime.now()
            if hasattr(self,"weather_date_var"):
                self.weather_date_var.set(now.strftime("%A, %B %d, %Y"))
                self.weather_clock_var.set("Local time  "+now.strftime("%I:%M:%S %p"))
            if self.winfo_exists(): self.after(1000,self._update_weather_clock)
        except Exception: pass

    def refresh_local_weather(self):
        """Auto-detect approximate location from public IP and fetch current plus 5-day weather."""
        if getattr(self,"_weather_fetching",False): return
        self._weather_fetching=True
        self.weather_status.set("DETECTING LOCATION • CONNECTING TO WEATHER FEED…")
        def worker():
            try:
                headers={"User-Agent":"ARES-X-N2MDX/0.9.2 (local weather dashboard)"}
                # IP geolocation is approximate (city/region level); no device GPS is accessed.
                req=urllib.request.Request("https://ipapi.co/json/",headers=headers)
                with urllib.request.urlopen(req,timeout=15) as response:
                    geo=json.loads(response.read().decode("utf-8"))
                if geo.get("error") or not geo.get("latitude") or not geo.get("longitude"):
                    raise ValueError("Automatic location unavailable. Check internet access or try again.")
                lat=float(geo["latitude"]); lon=float(geo["longitude"])
                city=geo.get("city") or "Local area"; region=geo.get("region") or ""
                country=geo.get("country_name") or ""
                location=", ".join(x for x in (city,region,country) if x)
                tz=geo.get("timezone") or "auto"
                url=(f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
                    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl"
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
                    "&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch"
                    f"&timezone={urllib.parse.quote(tz)}&forecast_days=5")
                req=urllib.request.Request(url,headers=headers)
                with urllib.request.urlopen(req,timeout=20) as response:
                    data=json.loads(response.read().decode("utf-8"))
                cur=data.get("current",{}); daily=data.get("daily",{})
                desc,icon=self._weather_description(cur.get("weather_code"))
                observed=cur.get("time","")
                details={
                    "feels":f'{cur.get("apparent_temperature","—")} °F',
                    "wind":f'{cur.get("wind_speed_10m","—")} mph • {cur.get("wind_direction_10m","—")}°',
                    "humidity":f'{cur.get("relative_humidity_2m","—")}%',
                    "pressure":f'{cur.get("pressure_msl","—")} hPa',
                    "rain":f'{cur.get("precipitation","—")} in now',
                }
                forecast=[]
                dates=daily.get("time",[])
                for i in range(min(5,len(dates))):
                    ddesc,dicon=self._weather_description((daily.get("weather_code") or [None]*5)[i])
                    hi=(daily.get("temperature_2m_max") or ["—"]*5)[i]
                    lo=(daily.get("temperature_2m_min") or ["—"]*5)[i]
                    pop=(daily.get("precipitation_probability_max") or ["—"]*5)[i]
                    daydate=datetime.datetime.strptime(dates[i],"%Y-%m-%d").date()
                    forecast.append((daydate.strftime("%a • %b %d"),dicon,ddesc,f"{hi}° / {lo}° F",f"Rain {pop}%"))
                err=None
            except Exception as exc:
                details=None; forecast=[]; err=str(exc); location=None; desc=None; icon=None; observed=None; cur={}
            def apply():
                self._weather_fetching=False
                if err:
                    self.weather_status.set("WEATHER OFFLINE • "+err)
                    return
                self._weather_location_data={"latitude":lat,"longitude":lon,"timezone":tz}
                self.weather_location_var.set(location)
                self.weather_icon_var.set(icon)
                self.weather_temp_var.set(f'{cur.get("temperature_2m","—")}°F')
                self.weather_condition_var.set(desc)
                for key,value in details.items(): self.weather_detail_vars[key].set(str(value))
                for idx,card in enumerate(self.weather_forecast_cards):
                    if idx<len(forecast):
                        for var,value in zip(card,forecast[idx]): var.set(value)
                    else:
                        for var in card: var.set("—")
                self.weather_status.set("LIVE • LOCATION AUTO-DETECTED")
                self.weather_updated_var.set("Last update: "+str(observed)+" local")
                # Continue refreshing while the app remains open.
                if self.winfo_exists(): self.after(15*60*1000,self.refresh_local_weather)
            try: self.after(0,apply)
            except Exception: self._weather_fetching=False
        threading.Thread(target=worker,daemon=True).start()

    def _build_tools_tab(self, parent):
        """Tools dashboard. Live external data sources are explicitly marked until configured."""
        top = ttk.Frame(parent); top.pack(fill="x", pady=(0,8))
        ttk.Label(top, text="N2MDX TOOLS CENTER", style="Title.TLabel").pack(side="left")
        ttk.Label(top, text="GRID • WORLD MAP • SATELLITES • WEATHER • UTC", style="Sub.TLabel").pack(side="left", padx=16, pady=(10,0))
        self.tools_tabs = ttk.Notebook(parent); self.tools_tabs.pack(fill="both", expand=True)
        gridtab = ttk.Frame(self.tools_tabs, padding=10)
        maptab = ttk.Frame(self.tools_tabs, padding=10)
        sattab = ttk.Frame(self.tools_tabs, padding=10)
        weathertab = ttk.Frame(self.tools_tabs, padding=10)
        clocktab = ttk.Frame(self.tools_tabs, padding=10)
        compasstab = ttk.Frame(self.tools_tabs, padding=10)
        propagationtab = ttk.Frame(self.tools_tabs, padding=10)
        eventstab = ttk.Frame(self.tools_tabs, padding=10)
        for frame, title in [(gridtab,"X-TRACKER"),(maptab,"WORLD MAP"),(sattab,"SATELLITES"),(weathertab,"WEATHER"),(clocktab,"CLOCKS"),(compasstab,"COMPASS"),(propagationtab,"HF PROPAGATION"),(eventstab,"CONTESTS & EVENTS")]:
            self.tools_tabs.add(frame, text=f"  {title}  ")

        # Locator / callsign panel: never infer a station's exact location from a callsign alone.
        gridtab.columnconfigure(0, weight=3); gridtab.columnconfigure(1, weight=2); gridtab.rowconfigure(1, weight=1)
        controls = ttk.Frame(gridtab); controls.grid(row=0,column=0,columnspan=2,sticky="ew",pady=(0,10))
        ttk.Label(controls,text="Station callsign / locator").pack(side="left")
        self.lookup_call = tk.StringVar(value=self.saved_settings.get("callsign", ""))
        ttk.Entry(controls,textvariable=self.lookup_call,width=16).pack(side="left",padx=4)
        self.lookup_grid = tk.StringVar(value=self.saved_settings.get("locator", ""))
        ttk.Entry(controls,textvariable=self.lookup_grid,width=12).pack(side="left",padx=4)
        ttk.Button(controls,text="PLOT LOCATOR",command=self._plot_grid_station).pack(side="left",padx=6)
        self.grid_map = tk.Canvas(gridtab,bg="#04101d",height=420,highlightthickness=0)
        self.grid_map.grid(row=1,column=0,sticky="nsew",padx=(0,8))
        self.grid_map.bind("<Configure>",lambda _e:self.after_idle(self._draw_grid_map))
        side = ttk.Frame(gridtab,style="Panel.TFrame",padding=10); side.grid(row=1,column=1,sticky="nsew")
        ttk.Label(side,text="GRID / STATION DETAILS",style="PanelTitle.TLabel").pack(anchor="w")
        self.grid_info = tk.StringVar(value="Select an incoming decode or enter a callsign and Maidenhead locator.")
        ttk.Label(side,textvariable=self.grid_info,wraplength=300,justify="left").pack(anchor="w",pady=(6,10))
        ttk.Label(side,text="INCOMING STATIONS",style="PanelTitle.TLabel").pack(anchor="w",pady=(2,4))
        incoming_wrap=ttk.Frame(side); incoming_wrap.pack(fill="both",expand=True)
        self.grid_station_tree=ttk.Treeview(incoming_wrap,columns=("call","grid","mode","snr"),show="headings",height=10,selectmode="browse")
        for col,title,width in [("call","Call / Decode",125),("grid","Grid",55),("mode","Mode",48),("snr","SNR",45)]:
            self.grid_station_tree.heading(col,text=title); self.grid_station_tree.column(col,width=width,stretch=(col=="call"),anchor="w")
        grid_scroll=ttk.Scrollbar(incoming_wrap,orient="vertical",command=self.grid_station_tree.yview)
        self.grid_station_tree.configure(yscrollcommand=grid_scroll.set)
        self.grid_station_tree.pack(side="left",fill="both",expand=True); grid_scroll.pack(side="right",fill="y")
        self.grid_station_tree.bind("<<TreeviewSelect>>",self._select_grid_station)

        map_controls = ttk.Frame(maptab)
        map_controls.pack(fill="x", pady=(0,6))
        ttk.Label(map_controls,text="MAP LANGUAGE").pack(side="left")
        self.map_language_box = ttk.Combobox(map_controls,textvariable=self.map_language,
            values=("English","Español","Français","Deutsch"),state="readonly",width=12)
        self.map_language_box.pack(side="left",padx=(5,14))
        self.map_language_box.bind("<<ComboboxSelected>>",lambda _e:self._draw_world_map())
        ttk.Label(map_controls,text="ZOOM").pack(side="left")
        self.map_zoom_label = tk.StringVar(value="1.0×")
        ttk.Button(map_controls,text="−",width=3,command=lambda:self._change_map_zoom(1/1.25)).pack(side="left",padx=3)
        ttk.Label(map_controls,textvariable=self.map_zoom_label,width=5).pack(side="left")
        ttk.Button(map_controls,text="+",width=3,command=lambda:self._change_map_zoom(1.25)).pack(side="left",padx=3)
        ttk.Button(map_controls,text="RESET VIEW",command=self._reset_map_view).pack(side="left",padx=8)
        ttk.Label(map_controls,text="Scroll to zoom • Drag to pan • City names appear at closer zoom",
                  style="Sub.TLabel").pack(side="left",padx=10)
        self.world_canvas = tk.Canvas(maptab,bg="#03101d",height=540,highlightthickness=0)
        self.world_canvas.pack(fill="both",expand=True)
        self.world_canvas.bind("<Configure>",lambda _e:self.after_idle(self._draw_world_map))
        self.world_canvas.bind("<MouseWheel>",self._map_mousewheel)
        self.world_canvas.bind("<Button-4>",lambda e:self._map_mousewheel(e,1))
        self.world_canvas.bind("<Button-5>",lambda e:self._map_mousewheel(e,-1))
        self.world_canvas.bind("<ButtonPress-1>",self._map_pan_start)
        self.world_canvas.bind("<B1-Motion>",self._map_pan_move)
        ttk.Label(maptab,text="Decoded stations with a Maidenhead locator are plotted automatically. Country names appear on the world view; zoom in for major city labels. Scroll to zoom and drag to pan.",foreground="#ffca69",wraplength=1000).pack(anchor="w",pady=(6,0))
        self.after(150,self._draw_world_map)

        sathead=ttk.Frame(sattab); sathead.pack(fill="x")
        ttk.Label(sathead,text="SATELLITE TRACKING",style="Title.TLabel").pack(anchor="w")
        ttk.Label(sattab,text="Live satellite positions, pass predictions, AOS/LOS, and orbital trails require current TLE/ephemeris data. This build provides the workspace but does not pretend a static orbit is live telemetry.",wraplength=1000).pack(anchor="w",pady=10)
        self.sat_status=tk.StringVar(value="Satellite data: NOT CONNECTED")
        ttk.Label(sattab,textvariable=self.sat_status,style="Sub.TLabel").pack(anchor="w")
        self.sat_canvas=tk.Canvas(sattab,bg="#04101d",height=380,highlightthickness=0)
        self.sat_canvas.pack(fill="both",expand=True,pady=10)
        self._draw_satellite_placeholder()
        ttk.Button(sathead,text="OPEN LIVE SATELLITE DATA SOURCE",command=lambda:webbrowser.open("https://celestrak.org/NORAD/elements/")).pack(side="right")

        # Automatic local weather: approximate location from the public IP address.
        ttk.Label(weathertab,text="LOCAL WEATHER • AUTOMATIC LOCATION",style="Title.TLabel").pack(anchor="w")
        self.weather_status=tk.StringVar(value="Detecting your location…")
        ttk.Label(weathertab,textvariable=self.weather_status,style="Sub.TLabel").pack(anchor="w",pady=(5,8))
        weather_head=tk.Frame(weathertab,bg="#0a1d30",highlightthickness=1,highlightbackground="#1c5876")
        weather_head.pack(fill="x",pady=(0,10))
        hero_left=tk.Frame(weather_head,bg="#0a1d30"); hero_left.pack(side="left",fill="both",expand=True,padx=18,pady=12)
        self.weather_icon_var=tk.StringVar(value="🌤")
        tk.Label(hero_left,textvariable=self.weather_icon_var,font=("Segoe UI Emoji",42),fg="#ffd166",bg="#0a1d30").pack(side="left",padx=(0,18))
        hero_text=tk.Frame(hero_left,bg="#0a1d30"); hero_text.pack(side="left",fill="y")
        self.weather_location_var=tk.StringVar(value="Finding your area…")
        tk.Label(hero_text,textvariable=self.weather_location_var,font=("Segoe UI",15,"bold"),fg="#62d9ff",bg="#0a1d30").pack(anchor="w")
        self.weather_temp_var=tk.StringVar(value="—°")
        tk.Label(hero_text,textvariable=self.weather_temp_var,font=("Segoe UI",30,"bold"),fg="#ffffff",bg="#0a1d30").pack(anchor="w")
        self.weather_condition_var=tk.StringVar(value="Waiting for current conditions")
        tk.Label(hero_text,textvariable=self.weather_condition_var,font=("Segoe UI",11),fg="#b6c9d8",bg="#0a1d30").pack(anchor="w")
        hero_right=tk.Frame(weather_head,bg="#0a1d30"); hero_right.pack(side="right",padx=18,pady=12)
        self.weather_date_var=tk.StringVar(value="—")
        tk.Label(hero_right,textvariable=self.weather_date_var,font=("Segoe UI",12,"bold"),fg="#ffffff",bg="#0a1d30").pack(anchor="e")
        self.weather_clock_var=tk.StringVar(value="Local time —")
        tk.Label(hero_right,textvariable=self.weather_clock_var,font=("Segoe UI",11),fg="#62d9ff",bg="#0a1d30").pack(anchor="e",pady=(5,0))
        weather_actions=ttk.Frame(weathertab); weather_actions.pack(fill="x",pady=(0,8))
        ttk.Button(weather_actions,text="DETECT LOCATION",command=self.refresh_local_weather).pack(side="left")
        ttk.Button(weather_actions,text="REFRESH WEATHER",command=self.refresh_local_weather).pack(side="left",padx=6)
        self.weather_updated_var=tk.StringVar(value="Waiting for first weather update")
        ttk.Label(weather_actions,textvariable=self.weather_updated_var,style="Sub.TLabel").pack(side="right")
        self.weather_detail_vars={}
        details=tk.Frame(weathertab,bg="#071523")
        details.pack(fill="x",pady=(0,10))
        for i,(key,label,accent) in enumerate((("feels","FEELS LIKE","#ffca69"),("wind","WIND","#66d9ef"),("humidity","HUMIDITY","#63d9b8"),("pressure","PRESSURE","#b69cff"),("rain","RAIN CHANCE","#66b8ff"))):
            card=tk.Frame(details,bg="#10263a",highlightthickness=1,highlightbackground="#1b4964")
            card.grid(row=0,column=i,sticky="nsew",padx=3,pady=3)
            details.grid_columnconfigure(i,weight=1)
            tk.Label(card,text=label,font=("Segoe UI",8,"bold"),fg=accent,bg="#10263a").pack(anchor="w",padx=9,pady=(8,2))
            var=tk.StringVar(value="—")
            self.weather_detail_vars[key]=var
            tk.Label(card,textvariable=var,font=("Segoe UI",12,"bold"),fg="#ffffff",bg="#10263a").pack(anchor="w",padx=9,pady=(1,8))
        ttk.Label(weathertab,text="5-DAY FORECAST",style="PanelTitle.TLabel").pack(anchor="w",pady=(3,5))
        self.weather_forecast_frame=tk.Frame(weathertab,bg="#071523")
        self.weather_forecast_frame.pack(fill="both",expand=True)
        self.weather_forecast_cards=[]
        for i in range(5):
            card=tk.Frame(self.weather_forecast_frame,bg="#10263a",highlightthickness=1,highlightbackground="#24516a")
            card.grid(row=0,column=i,sticky="nsew",padx=4,pady=4)
            self.weather_forecast_frame.grid_columnconfigure(i,weight=1)
            day=tk.StringVar(value="—"); icon=tk.StringVar(value="🌤"); desc=tk.StringVar(value="—")
            hi_lo=tk.StringVar(value="—° / —°"); rain=tk.StringVar(value="Rain —")
            tk.Label(card,textvariable=day,font=("Segoe UI",10,"bold"),fg="#62d9ff",bg="#10263a").pack(pady=(10,3))
            tk.Label(card,textvariable=icon,font=("Segoe UI Emoji",27),fg="#ffd166",bg="#10263a").pack(pady=2)
            tk.Label(card,textvariable=desc,font=("Segoe UI",9),fg="#dceaf4",bg="#10263a",wraplength=130).pack(pady=2)
            tk.Label(card,textvariable=hi_lo,font=("Segoe UI",12,"bold"),fg="#ffffff",bg="#10263a").pack(pady=(5,2))
            tk.Label(card,textvariable=rain,font=("Segoe UI",9),fg="#66b8ff",bg="#10263a").pack(pady=(0,10))
            self.weather_forecast_cards.append((day,icon,desc,hi_lo,rain))
        ttk.Label(weathertab,text="Automatic location uses approximate IP-based geolocation. Weather and 5-day forecast are from Open-Meteo; refreshes every 15 minutes while ARES-X is running.",foreground="#ffca69",wraplength=1100).pack(anchor="w",pady=8)
        self._weather_location_data=None
        self._weather_fetching=False
        self.after(1200,self.refresh_local_weather)
        self.after(1000,self._update_weather_clock)

        clocks=ttk.Frame(clocktab); clocks.pack(fill="both",expand=True)
        self.local_clock_var=tk.StringVar(value="Local: —")
        self.utc_clock_var=tk.StringVar(value="UTC: —")
        for var,caption in [(self.local_clock_var,"LOCAL TIME"),(self.utc_clock_var,"UTC / ZULU")]:
            panel=ttk.Frame(clocks,style="Panel.TFrame",padding=24); panel.pack(side="left",fill="both",expand=True,padx=8,pady=8)
            ttk.Label(panel,text=caption,style="PanelTitle.TLabel").pack(anchor="center",pady=8)
            ttk.Label(panel,textvariable=var,font=("Consolas",24,"bold"),foreground="#63d5ff").pack(anchor="center",pady=12)
        self._update_clocks()

        ttk.Label(compasstab,text="COMPASS",style="Title.TLabel").pack(anchor="w")
        ttk.Label(compasstab,text="A software compass needs a heading sensor or a chosen bearing. This panel can show a manually entered bearing; it does not claim to read a physical compass.",wraplength=900).pack(anchor="w",pady=8)
        comp = ttk.Frame(compasstab); comp.pack(anchor="center",pady=18)
        self.bearing_var=tk.DoubleVar(value=0)
        self.bearing_label=tk.StringVar(value="Bearing: 000° N")
        ttk.Scale(comp,from_=0,to=359,variable=self.bearing_var,command=self._update_compass,orient="horizontal",length=360).pack()
        ttk.Label(comp,textvariable=self.bearing_label,style="Sub.TLabel").pack(pady=8)
        self.compass_canvas=tk.Canvas(comp,bg="#07111e",width=280,height=280,highlightthickness=0)
        self.compass_canvas.pack()
        self._draw_compass()

        # HF propagation: NOAA SWPC solar radio flux and planetary K-index are fetched
        # asynchronously. Band outlook is explicitly an estimate, not a claim that a
        # band is currently open; actual openings depend on path, time, mode and reports.
        ttk.Label(propagationtab,text="HF BAND PROPAGATION",style="Title.TLabel").pack(anchor="w")
        ttk.Label(propagationtab,text="Solar conditions + band-by-band outlook • 160m through 6m",style="Sub.TLabel").pack(anchor="w",pady=(2,10))
        pbar=ttk.Frame(propagationtab); pbar.pack(fill="x",pady=(0,8))
        self.propagation_status=tk.StringVar(value="NOAA space-weather data not loaded")
        ttk.Label(pbar,textvariable=self.propagation_status,style="Sub.TLabel").pack(side="left",fill="x",expand=True)
        ttk.Button(pbar,text="REFRESH LIVE SOLAR DATA",style="Accent.TButton",command=self.refresh_propagation).pack(side="right")
        summary=ttk.Frame(propagationtab,style="Panel.TFrame",padding=12); summary.pack(fill="x",pady=(0,10))
        self.solar_summary=tk.StringVar(value="Solar flux: —    Planetary Kp: —    Updated: —")
        ttk.Label(summary,textvariable=self.solar_summary,style="PanelTitle.TLabel").pack(anchor="w")
        cols=("band","freq","day","night","outlook","basis")
        self.band_tree=ttk.Treeview(propagationtab,columns=cols,show="headings",height=9)
        for col,title,width in [("band","HF Band",100),("freq","Typical range",130),("day","Daytime",130),("night","Nighttime",130),("outlook","Solar outlook",150),("basis","Notes",430)]:
            self.band_tree.heading(col,text=title); self.band_tree.column(col,width=width,stretch=(col=="basis"),anchor="w")
        self.band_tree.pack(fill="both",expand=True)
        self.band_tree.bind("<Double-1>", self._tune_clicked_propagation_band)
        ttk.Label(propagationtab,text="Double-click a band row to tune the radio to its common FT8 frequency.",foreground="#63d5ff").pack(anchor="w",pady=(4,0))
        for row in [("160 m","1.8–2.0 MHz","Limited","Often better","Awaiting data","Local noise and nighttime path dominate"),("80 m","3.5–4.0 MHz","Limited","Often favorable","Awaiting data","Regional/nighttime coverage often improves"),("60 m","5 MHz","Variable","Variable","Awaiting data","Channel and regional rules apply"),("40 m","7 MHz","Variable","Often good","Awaiting data","Useful day and night; path dependent"),("30 m","10 MHz","Often useful","Often useful","Awaiting data","Digital/CW allocation rules apply"),("20 m","14 MHz","Often favorable","Variable","Awaiting data","Daytime long-distance work often benefits"),("17 m","18 MHz","Solar dependent","Solar dependent","Awaiting data","More sensitive to solar conditions"),("15 m","21 MHz","Solar dependent","Often limited","Awaiting data","Higher solar activity generally helps"),("12 m","24 MHz","Solar dependent","Often limited","Awaiting data","Higher solar activity generally helps"),("10 m","28 MHz","Solar dependent","Often limited","Awaiting data","Solar activity and sporadic-E can matter"),("6 m","50–54 MHz","Sporadic-E / solar dependent","Sporadic-E / aurora","Awaiting data","VHF propagation: sporadic-E, aurora, meteor scatter and openings; solar flux alone does not confirm openings")]: self.band_tree.insert("","end",values=row)
        ttk.Label(propagationtab,text="Important: NOAA solar indices are not direct proof of an open/closed band. A future version can combine these indicators with live WSPR/PSK Reporter spots for observed openings.",wraplength=1100,foreground="#ffca69").pack(anchor="w",pady=(8,0))

        # Event calendar is honest about provenance and links to authoritative live calendars.
        ttk.Label(eventstab,text="CONTESTS & SPECIAL EVENTS",style="Title.TLabel").pack(anchor="w")
        ttk.Label(eventstab,text="Upcoming operating events • dates shown in UTC where published",style="Sub.TLabel").pack(anchor="w",pady=(2,10))
        evbar=ttk.Frame(eventstab); evbar.pack(fill="x",pady=(0,8))
        ttk.Button(evbar,text="OPEN ARRL CONTEST CALENDAR",style="Accent.TButton",command=lambda:webbrowser.open("https://contests.arrl.org/calendar.php")).pack(side="left",padx=(0,6))
        ttk.Button(evbar,text="OPEN WA7BNM CONTEST CALENDAR",command=lambda:webbrowser.open("https://www.contestcalendar.com/")).pack(side="left",padx=6)
        ttk.Button(evbar,text="OPEN ARRL SPECIAL EVENTS",command=lambda:webbrowser.open("https://www.arrl.org/special-event-stations")).pack(side="left",padx=6)
        self.events_status=tk.StringVar(value="Calendar links open the publishers' current listings; the local shortlist is a dated snapshot.")
        ttk.Label(eventstab,textvariable=self.events_status,wraplength=1000).pack(anchor="w",pady=(0,8))
        ecols=("date","event","focus","source")
        self.events_tree=ttk.Treeview(eventstab,columns=ecols,show="headings",height=12)
        for col,title,width in [("date","Date",150),("event","Contest / Event",360),("focus","Bands / mode",260),("source","Source",180)]:
            self.events_tree.heading(col,text=title); self.events_tree.column(col,width=width,stretch=(col=="event"),anchor="w")
        self.events_tree.pack(fill="both",expand=True)
        upcoming=[("Oct 31–Nov 1, 2026","ARRL EME Contest","50 MHz–1296 MHz / EME","ARRL"),("Nov 7–9, 2026","ARRL November Sweepstakes – CW","HF / CW","ARRL"),("Nov 21–23, 2026","ARRL November Sweepstakes – Phone","HF / SSB","ARRL"),("Nov 28–29, 2026","ARRL EME Contest","50 MHz–1296 MHz / EME","ARRL"),("Dec 4–6, 2026","ARRL 160-Meter Contest","160 m","ARRL"),("Dec 12–13, 2026","ARRL 10-Meter Contest","10 m / all modes per rules","ARRL"),("Dec 20, 2026","ARRL Rookie Roundup – CW","HF / CW","ARRL")]
        today=datetime.date.today()
        for date_text,name,focus,source in upcoming: self.events_tree.insert("","end",values=(date_text,name,focus,source))
        ttk.Label(eventstab,text="Event list is a built-in upcoming-events snapshot, not an automatic live feed. Use the official calendars above to verify rules, start/stop times, and newly added special-event stations.",wraplength=1100,foreground="#ffca69").pack(anchor="w",pady=(8,0))

    def refresh_propagation(self):
        self.propagation_status.set("Fetching NOAA SWPC solar data…")
        threading.Thread(target=self._fetch_propagation_data,daemon=True).start()

    def _fetch_propagation_data(self):
        """Fetch NOAA SWPC indices with tolerant parsing and useful diagnostics."""
        errors=[]
        def fetch(url):
            req=urllib.request.Request(url,headers={"User-Agent":"ARES-X-N2MDX/0.6.2 (amateur-radio space-weather dashboard)"})
            with urllib.request.urlopen(req,timeout=12) as response:
                if getattr(response,"status",200) != 200:
                    raise ValueError(f"HTTP {getattr(response,'status','?')}")
                return json.loads(response.read().decode("utf-8-sig"))

        def rows_from(data):
            # NOAA feeds are usually arrays of objects, but some product feeds
            # use a header row followed by positional rows or wrap rows in a dict.
            if isinstance(data,list):
                if data and isinstance(data[0],list):
                    headers=[str(x).strip().lower() for x in data[0]]
                    return [dict(zip(headers,row)) for row in data[1:] if isinstance(row,list)]
                return [r for r in data if isinstance(r,dict)]
            if isinstance(data,dict):
                for key in ("data","values","observations","results"):
                    if isinstance(data.get(key),list):
                        return rows_from(data[key])
                return [data]
            return []

        def latest_numeric(data, aliases):
            rows=rows_from(data)
            # Walk newest-to-oldest where the source is time ordered.
            for row in reversed(rows):
                norm={str(k).strip().lower().replace(" ","_").replace("-","_"):v for k,v in row.items()}
                stamp=next((str(norm[k]) for k in ("time_tag","time","timestamp","date_time","datetime") if norm.get(k) not in (None,"")),"unknown")
                for key in aliases:
                    value=norm.get(key)
                    if isinstance(value,dict):
                        value=value.get("value")
                    try:
                        if value not in (None,"") and str(value).strip().lower() not in ("null","nan","-","none"):
                            return float(value),stamp
                    except (TypeError,ValueError):
                        continue
            return None,None

        flux_sources=[
            ("solar radio flux", "https://services.swpc.noaa.gov/json/solar-radio-flux.json", ["observed_flux","flux","f10.7","f107","f107_flux","adjusted_flux","value"]),
            ("F10.7 flux", "https://services.swpc.noaa.gov/json/f107_cm_flux.json", ["observed_flux","flux","f10.7","f107","adjusted_flux","value"]),
        ]
        kp_sources=[
            ("planetary K-index", "https://services.swpc.noaa.gov/json/planetary_k_index_1m.json", ["kp_index","kp","k_index","estimated_kp","value"]),
            ("planetary K-index", "https://services.swpc.noaa.gov/json/boulder_k_index_1m.json", ["kp_index","kp","k_index","estimated_kp","value"]),
        ]
        fval=ftime=kval=ktime=None
        for label,url,aliases in flux_sources:
            try:
                fval,ftime=latest_numeric(fetch(url),aliases)
                if fval is not None: break
                errors.append(f"{label}: feed loaded but no recognized numeric field")
            except Exception as exc:
                errors.append(f"{label}: {exc}")
        for label,url,aliases in kp_sources:
            try:
                kval,ktime=latest_numeric(fetch(url),aliases)
                if kval is not None: break
                errors.append(f"{label}: feed loaded but no recognized numeric field")
            except Exception as exc:
                errors.append(f"{label}: {exc}")
        if fval is None or kval is None:
            missing=[]
            if fval is None: missing.append("solar flux (F10.7)")
            if kval is None: missing.append("planetary K-index")
            detail="; ".join(errors[-4:])
            message="Could not read " + " and ".join(missing) + ". " + detail
            self.after(0,lambda msg=message:self.propagation_status.set("NOAA refresh failed — " + msg))
            return
        self.after(0,lambda:self._apply_propagation(fval,kval,ftime if ftime!="unknown" else ktime))

    def _apply_propagation(self,flux,kp,timestamp):
        self.solar_summary.set(f"Solar flux (F10.7): {flux:.1f}    Planetary Kp: {kp:.1f}    Latest source timestamp: {timestamp}")
        if kp>=5: condition="Geomagnetic disturbance"; note="Disturbed conditions may degrade HF paths; verify with live spots."
        elif flux>=150: condition="Higher solar flux"; note="Higher bands may benefit; confirm openings with spots/beacons."
        elif flux>=100: condition="Moderate solar flux"; note="Mid-HF may be usable; higher-band openings are path dependent."
        else: condition="Lower solar flux"; note="Lower bands may be more reliable; verify conditions with spots/beacons."
        for iid in self.band_tree.get_children():
            band=self.band_tree.item(iid,"values")[0]
            if band in ("160 m","80 m"): day="Often limited"; night="Often favored"
            elif band in ("40 m","30 m"): day="Variable"; night="Often useful"
            elif band in ("20 m","17 m"): day="Potentially useful"; night="Variable"
            elif band == "6 m": day="Sporadic-E / aurora"; night="Sporadic-E / meteor scatter"
            else: day="Solar dependent"; night="Often limited"
            self.band_tree.item(iid,values=(self.band_tree.item(iid,"values")[0],self.band_tree.item(iid,"values")[1],day,night,condition,note))
        self.propagation_status.set("NOAA SWPC data loaded. These are broad indicators, not confirmed open/closed bands.")
        self._log(f"NOAA propagation indicators refreshed: F10.7={flux:.1f}, Kp={kp:.1f}; not direct band-open measurements.")

    def _update_clocks(self):
        import datetime
        now=datetime.datetime.now().astimezone()
        utc=datetime.datetime.now(datetime.timezone.utc)
        self.local_clock_var.set(now.strftime("%A, %b %d  |  %I:%M:%S %p %Z"))
        self.utc_clock_var.set(utc.strftime("%A, %b %d  |  %H:%M:%S UTC"))
        self.after(1000,self._update_clocks)

    def _draw_grid_map(self):
        c=self.grid_map
        if not c.winfo_exists(): return
        self._draw_geographic_map(c, "MAIDENHEAD GRID TRACKER")
        self._draw_station_pin(c)

    def _plot_grid_station(self):
        call=self.lookup_call.get().strip().upper(); loc=self.lookup_grid.get().strip().upper()
        self._save_settings()
        try:
            lat, lon = self._maidenhead_center(loc)
        except ValueError as exc:
            messagebox.showinfo("Grid Tracker", str(exc) + " Example: FN20 or FN20ab."); return
        self.grid_info.set(f"Station: {call or 'Unknown'}\nLocator: {loc}\nCenter: {abs(lat):.3f}° {'N' if lat >= 0 else 'S'}, {abs(lon):.3f}° {'E' if lon >= 0 else 'W'}\n\nPosition is based on the supplied Maidenhead locator.")
        self._draw_world_map()
        self._draw_grid_map()
        self.tools_tabs.select(1)
        self.main_tabs.select(1)

    def _select_grid_station(self, _event=None):
        selected=self.grid_station_tree.selection()
        if not selected: return
        vals=self.grid_station_tree.item(selected[0],"values")
        if len(vals)<4: return
        call,loc,mode,snr=vals
        self.lookup_call.set(call if call and call!="—" else "")
        self.lookup_grid.set(loc if loc and loc!="—" else "")
        if loc and loc!="—":
            self._plot_grid_station()
        else:
            self.grid_info.set(f"Station/decode: {call}\nMode: {mode}\nSNR: {snr} dB\n\nNo Maidenhead locator was present in this decode, so a map position cannot be plotted yet.")

    @staticmethod
    def _maidenhead_center(locator):
        """Convert a Maidenhead locator (4, 6, or 8 characters) to its cell center."""
        loc=locator.strip().upper()
        if len(loc) not in (4,6,8):
            raise ValueError("Use a 4-, 6-, or 8-character Maidenhead locator.")
        if not ('A'<=loc[0]<='R' and 'A'<=loc[1]<='R' and loc[2].isdigit() and loc[3].isdigit()):
            raise ValueError("Invalid Maidenhead locator format.")
        lon=-180+(ord(loc[0])-ord('A'))*20
        lat=-90+(ord(loc[1])-ord('A'))*10
        lon_size,lat_size=20.0,10.0
        if len(loc)>=6:
            if not ('A'<=loc[4]<='X' and 'A'<=loc[5]<='X'):
                raise ValueError("Invalid Maidenhead subsquare.")
            lon += int(loc[2])*2; lat += int(loc[3])*1
            lon += (ord(loc[4])-ord('A'))*(2.0/24)
            lat += (ord(loc[5])-ord('A'))*(1.0/24)
            lon_size,lat_size=2.0/24,1.0/24
        if len(loc)==8:
            if not loc[6].isdigit() or not loc[7].isdigit():
                raise ValueError("Invalid Maidenhead extended square.")
            lon += int(loc[6])*(2.0/240); lat += int(loc[7])*(1.0/240)
            lon_size,lat_size=2.0/240,1.0/240
        return lat+lat_size/2, lon+lon_size/2

    def _map_project(self, lon, lat, canvas):
        w=max(canvas.winfo_width(),500); h=max(canvas.winfo_height(),300)
        left,right,top,bottom=10,w-10,42,h-28
        map_w=right-left; map_h=bottom-top
        base_x=left+(lon+180.0)/360.0*map_w
        base_y=top+(85.0-lat)/170.0*map_h
        cx=(left+right)/2; cy=(top+bottom)/2
        return (cx+(base_x-cx)*self.map_zoom+self.map_pan_x,
                cy+(base_y-cy)*self.map_zoom+self.map_pan_y)

    def _change_map_zoom(self, factor):
        self.map_zoom=max(1.0,min(12.0,self.map_zoom*factor))
        self.map_zoom_label.set(f"{self.map_zoom:.1f}×")
        self._draw_world_map()

    def _reset_map_view(self):
        self.map_zoom=1.0; self.map_pan_x=0.0; self.map_pan_y=0.0
        self.map_zoom_label.set("1.0×")
        self._draw_world_map()

    def _map_mousewheel(self,event,direction=None):
        delta=direction if direction is not None else (1 if event.delta>0 else -1)
        self._change_map_zoom(1.2 if delta>0 else 1/1.2)
        return "break"

    def _map_pan_start(self,event):
        self.map_drag_anchor=(event.x,event.y,self.map_pan_x,self.map_pan_y)

    def _map_pan_move(self,event):
        if not self.map_drag_anchor:return
        x,y,px,py=self.map_drag_anchor
        self.map_pan_x=px+(event.x-x); self.map_pan_y=py+(event.y-y)
        self._draw_world_map()

    def _map_continent(self,lon,lat):
        if lat < -60:return "Antarctica"
        if lon < -30 and lat > 5:return "North America"
        if lon < -30 and lat <= 5:return "South America"
        if lon > -20 and lon < 50 and lat > 34:return "Europe"
        if lon > -20 and lon < 52 and lat <= 34 and lat > -36:return "Africa"
        if lon >= 50 or (lon >= -20 and lat > 35):return "Asia"
        if lon > 110 and lat < 0:return "Oceania"
        if lon > 110 and lat < 25:return "Oceania"
        return "Other"

    def _atlas_country_color(self, country_id):
        # Stable traditional political-atlas palette; neighboring countries get varied hues.
        palette=("#e6a15b","#75b9a3","#d47c79","#8eabd9","#d6c36f","#a98acb",
                 "#78a9b7","#d995b5","#a8bd72","#c58f65","#7f9e8d","#c7a1d2",
                 "#e0b47e","#80b7a9","#bd8585","#91a9c5","#c8b36c","#9b8dc0",
                 "#78a4a0","#d5a18e","#a2b978","#b28d70","#83b4cf","#c99aaf")
        value=sum((i+1)*ord(ch) for i,ch in enumerate(str(country_id)))
        return palette[value % len(palette)]

    def _draw_geographic_map(self, canvas, title):
        """Render the bundled Natural Earth country atlas and zoom-dependent city labels."""
        if not canvas.winfo_exists(): return
        canvas.delete("all")
        w=max(canvas.winfo_width(),500); h=max(canvas.winfo_height(),300)
        left,right,top,bottom=10,w-10,42,h-28
        for lon in range(-180,181,30):
            x1,y1=self._map_project(lon,-85,canvas); x2,y2=self._map_project(lon,85,canvas)
            canvas.create_line(x1,y1,x2,y2,fill="#18384b",width=1)
        for lat in range(-60,81,30):
            x1,y1=self._map_project(-180,lat,canvas); x2,y2=self._map_project(180,lat,canvas)
            canvas.create_line(x1,y1,x2,y2,fill="#18384b",width=1)

        countries=self.world_atlas.get("countries", [])
        if countries:
            for country in countries:
                color=self._atlas_country_color(country.get("id",country.get("en","")))
                for ring in country.get("rings",[]):
                    pts=[]
                    for lon,lat in ring:
                        x,y=self._map_project(lon,lat,canvas); pts.extend((x,y))
                    if len(pts)>=6:
                        try: canvas.create_polygon(*pts,fill=color,outline="#344e5d",width=1,tags=("country",))
                        except tk.TclError: pass
            # Collision-aware labels: prioritize larger country names at overview scale.
            if self.map_zoom >= 1.05:
                lang={"English":"en","Español":"es","Français":"fr","Deutsch":"de"}.get(self.map_language.get(),"en")
                placed=[]
                for country in sorted(countries,key=lambda item:len(item.get("rings",[])),reverse=True):
                    lon,lat=country.get("label",[0,0]); x,y=self._map_project(lon,lat,canvas)
                    if not (left+8<x<right-8 and top+5<y<bottom-5): continue
                    name=country.get(lang) or country.get("en","")
                    if not name: continue
                    if any(abs(x-px)<max(26,len(name)*3.2) and abs(y-py)<13 for px,py in placed): continue
                    placed.append((x,y))
                    fs=8 if self.map_zoom<2.0 else 9
                    canvas.create_text(x,y,text=name,fill="#17232b",font=("Segoe UI",fs,"bold"),
                        justify="center",tags=("country_label",))

            # Capitals appear first; additional major cities progressively appear at higher zoom.
            if self.map_zoom >= 1.8:
                max_rank=2 if self.map_zoom<2.8 else (4 if self.map_zoom<4.0 else 8)
                city_lang={"English":"en","Español":"es","Français":"fr","Deutsch":"de"}.get(self.map_language.get(),"en")
                city_count=0
                for city in self.world_atlas.get("cities",[]):
                    if not city.get("capital") and int(city.get("rank",99))>max_rank: continue
                    x,y=self._map_project(city["lon"],city["lat"],canvas)
                    if not (left+3<x<right-3 and top+3<y<bottom-3): continue
                    label=city.get(city_lang) or city.get("name","")
                    canvas.create_oval(x-2,y-2,x+2,y+2,fill="#27313a",outline="#fff1c2",width=1)
                    canvas.create_text(x+4,y-4,text=label,anchor="sw",fill="#fff4d5",
                        font=("Segoe UI",8,"bold" if city.get("capital") else "normal"),tags=("city_label",))
                    city_count+=1
                    if city_count>=260: break
        else:
            # Backward-compatible fallback if the atlas data file is missing.
            for polygon in self.world_geo_data.get("land_polygons", []):
                if not polygon: continue
                points=[]
                for plon,plat in polygon:
                    x,y=self._map_project(plon,plat,canvas); points.extend((x,y))
                if len(points)>=6:
                    try: canvas.create_polygon(*points,fill="#5b8e91",outline="#a8c4d0",width=1)
                    except tk.TclError: pass

        lang=self.map_language.get()
        canvas.create_text(w/2,20,text=f"ARES-X • {title}",fill="#63d5ff",font=("Segoe UI",14,"bold"))
        canvas.create_rectangle(left,top,right,bottom,outline="#1d5269",width=1)
        canvas.create_text(w/2,h-12,text=f"NATURAL EARTH WORLD ATLAS • {lang.upper()} • ZOOM {self.map_zoom:.1f}×",
            fill="#ffca69",font=("Segoe UI",9))

    def _draw_station_pin(self, canvas):
        """Plot the currently entered station locator on a geographic map."""
        call=self.lookup_call.get().strip().upper()
        locator=self.lookup_grid.get().strip().upper()
        if not locator:
            return
        try:
            lat,lon=self._maidenhead_center(locator)
        except (ValueError, AttributeError):
            return
        x,y=self._map_project(lon,lat,canvas)
        canvas.create_oval(x-7,y-7,x+7,y+7,fill="#ff4f67",outline="white",width=2,
                           tags=("station_pin",))
        canvas.create_text(x,y+17,text=f"{call or 'STATION'} • {locator}",fill="white",
                           anchor="n",tags=("station_pin",))

    def _draw_world_map(self):
        c=self.world_canvas
        if not c.winfo_exists(): return
        self._draw_geographic_map(c, "WORLD MAP")
        self._draw_station_pin(c)

    def _draw_satellite_placeholder(self):
        c=self.sat_canvas; c.delete("all"); w=900; h=360
        c.create_oval(w/2-120,h/2-120,w/2+120,h/2+120,fill="#0b304a",outline="#39bde8",width=2)
        c.create_oval(w/2-165,h/2-70,w/2+165,h/2+70,outline="#ffca69",width=2,dash=(6,4))
        c.create_oval(w/2-220,h/2-120,w/2+220,h/2+120,outline="#237b9a",width=2,dash=(3,5))
        c.create_text(w/2,h/2,text="EARTH\nSATELLITE FEED OFFLINE",fill="#d8f4ff",font=("Segoe UI",12,"bold"))
        c.create_text(20,h-18,text="Illustrative orbital rings only — no live satellite position is being shown",fill="#ffca69",anchor="w")

    def _update_compass(self, _value=None):
        bearing=int(self.bearing_var.get())%360
        cardinal="N" if bearing<22.5 or bearing>=337.5 else "E" if bearing<112.5 else "S" if bearing<202.5 else "W"
        self.bearing_label.set(f"Bearing: {bearing:03d}° {cardinal}")
        self._draw_compass()

    def _draw_compass(self):
        import math
        c=self.compass_canvas; c.delete("all"); cx=cy=140; r=105
        c.create_oval(cx-r,cy-r,cx+r,cy+r,outline="#287b9b",width=2)
        for deg in range(0,360,30):
            a=math.radians(deg-90); x1=cx+math.cos(a)*(r-8); y1=cy+math.sin(a)*(r-8); x2=cx+math.cos(a)*r; y2=cy+math.sin(a)*r
            c.create_line(x1,y1,x2,y2,fill="#63d5ff",width=2)
        for deg,label in [(0,"N"),(90,"E"),(180,"S"),(270,"W")]:
            a=math.radians(deg-90); c.create_text(cx+math.cos(a)*(r-22),cy+math.sin(a)*(r-22),text=label,fill="#e6f2ff",font=("Segoe UI",12,"bold"))
        a=math.radians(float(self.bearing_var.get())-90)
        c.create_line(cx,cy,cx+math.cos(a)*(r-35),cy+math.sin(a)*(r-35),fill="#ff4f67",width=4,arrow="last")
        c.create_oval(cx-4,cy-4,cx+4,cy+4,fill="#f3f8ff",outline="")

    def refresh_audio_devices(self):
        try:
            import sounddevice as sd
            devices=sd.query_devices()
            choices=["Default input"]
            self.audio_devices=[]
            for i,d in enumerate(devices):
                if int(d.get("max_input_channels",0))>0:
                    label=f"{i} | {d['name']}"
                    choices.append(label); self.audio_devices.append((i,d['name']))
            self.audio_box.configure(values=choices)
            if self.audio_device.get() not in choices: self.audio_device.set("Default input")
            self._log(f"Audio devices refreshed: {len(choices)-1} input endpoint(s). Select the virtual cable recording endpoint.")
        except Exception as e:
            self._log("Could not enumerate audio devices: "+str(e))

    def toggle_cat(self):
        if self.cat_connected:
            if self.cat: self.cat.disconnect()
            self.cat=None; self.cat_connected=False; self.cat_button.configure(text="CONNECT CAT")
            self.radio_readout.set("Frequency: —   Mode: —"); self._cw_update_radio_display() if hasattr(self,"cw_frequency") else None; self._log("Radio CAT disconnected."); return
        model=self.radio_model.get()
        if ("Icom" in model or ("Yaesu" in model and model != "Yaesu FTDX10")):
            messagebox.showwarning("Radio adapter unavailable","This radio model does not have a native CAT adapter in this release.")
            return
        port=self.com_port.get().strip()
        try:
            baud=int(self.baud.get())
            if not port: raise ValueError("Choose a COM port, e.g. COM3.")
            if model == "Yaesu FTDX10":
                self.cat=YaesuFTDX10CAT(port,baud,on_update=self._cat_update,on_error=self._cat_error)
            else:
                self.cat=ThetisCAT(port,baud,on_update=self._cat_update,on_error=self._cat_error)
            self.cat.connect(); self.cat_connected=True; self.cat_button.configure(text="DISCONNECT")
            self._log(f"{model} CAT verified on {port} at {baud} baud.")
        except Exception as e:
            self.cat=None; self.cat_connected=False
            messagebox.showerror("Radio CAT connection",str(e)); self._log("CAT connect failed: "+str(e))

    def _cat_update(self,frequency,mode):
        def update():
            if not self.winfo_exists(): return
            freq="—" if frequency is None else f"{frequency/1e6:.6f} MHz"
            raw = getattr(self.cat, "mode_code", None) if self.cat else None
            raw_text = f" (CAT MD{raw})" if raw is not None else ""
            self.radio_readout.set(f"Frequency: {freq}   Mode: {mode or '—'}{raw_text}")
            if frequency is not None and mode: self.status.set("THETIS CAT CONNECTED — RX ONLY")
            if hasattr(self,"cw_frequency"):
                self.cw_live_frequency=frequency
                self.cw_frequency.set(f"LIVE CAT: {frequency/1e6:.6f} MHz" if frequency else "CAT FREQUENCY: NOT CONNECTED")
        try: self.after(0,update)
        except tk.TclError: pass

    def _cat_error(self,err):
        try: self.after(0,lambda e=err:self._log("CAT communication: "+e))
        except tk.TclError: pass

    def _draw_placeholder(self):
        c=self.canvas; c.delete("all"); w=560; h=210
        for x in range(0,w,25): c.create_line(x,0,x,h,fill="#10243a")
        for y in range(0,h,22): c.create_line(0,y,w,y,fill="#10243a")
        c.create_text(12,10,anchor="nw",fill="#76cfff",text="LAB DISPLAY — simulated until audio is analyzed")
        import random
        random.seed(12); pts=[]
        for x in range(0,w,3):
            y=h*.53+random.randint(-6,6)
            for center,amp in [(w*.28,60),(w*.52,75),(w*.73,45)]: y-=amp*np.exp(-((x-center)/8)**2)
            pts.extend((x,y))
        c.create_line(*pts,fill="#16d6a4",width=1.5)
        c.create_text(10,h-8,anchor="sw",fill="#547a9a",text="Illustrative until live spectrum processing is implemented")

    def start_wsjtx_bridge(self):
        if self.wsjtx_bridge is not None:
            self._log("WSJT-X UDP bridge is already running.")
            return
        try:
            host=self.wsjtx_host.get().strip(); port=int(self.wsjtx_port.get())
            self.wsjtx_bridge = WSJTXBridge(host, port)
            self.wsjtx_bridge.start()
            self._log(f"WSJT-X UDP bridge listening on {host}:{port}. Supported mode decodes will appear in DECODER OUTPUT; connection/status details appear here in EVENT LOG.")
            self._log("Bridge started. In WSJT-X Settings > Reporting, enable UDP Server and Accept UDP requests. Select the operating mode inside WSJT-X; ARES-X receives its decode/status reports.")
            self.after(250, self._poll_wsjtx_bridge)
        except Exception as e:
            self.wsjtx_bridge = None
            self._log(f"ERROR starting WSJT-X bridge: {type(e).__name__}: {e}")
            messagebox.showerror("WSJT-X bridge", f"Could not start UDP listener on 127.0.0.1:2237.\\n{type(e).__name__}: {e}\\nCheck whether another application is using this port.")

    def _poll_wsjtx_bridge(self):
        if self.wsjtx_bridge is None:
            return
        for state in self.wsjtx_bridge.drain_status():
            # Hold each bar until WSJT-X reports the corresponding state has ended.
            self._set_rx_activity(state.get("decoding", False) and not state.get("transmitting", False))
            self._set_tx_activity(state.get("transmitting", False))
            active_mode = (state.get("mode") or "").strip()
            if active_mode and active_mode != getattr(self, "_last_wsjtx_mode", None):
                self._last_wsjtx_mode = active_mode
                self._log(f"WSJT-X reports active mode: {active_mode}")
        for item in self.wsjtx_bridge.drain():
            line = (f"WSJT-X {item.mode} {item.utc}  SNR {item.snr_db:+d} dB  "
                    f"DT {item.delta_time:+.1f}s  {item.audio_hz} Hz\n"
                    f"{item.message}\n")
            self.result.insert("end", line)
            self.result.see("end")
            self._log(f"WSJT-X decoded {item.mode}: {item.message}")
            if item.is_new:
                self._add_station_row(item)
                self._track_cq_decode(item)
        self.after(250, self._poll_wsjtx_bridge)

    def _add_station_row(self, item):
        # Deduplicate repeated copies of the same decode while retaining latest metadata.
        key = f"{item.utc}|{item.mode}|{item.audio_hz}|{item.message}"
        values=(item.utc, item.mode, item.message, f"{item.snr_db:+d}", f"{item.delta_time:+.1f}", str(item.audio_hz))
        if key in self.station_rows:
            try: self.station_tree.item(key, values=values)
            except tk.TclError: self.station_rows.pop(key, None)
        if key not in self.station_rows:
            self.station_tree.insert("", "end", iid=key, values=values)
            self.station_rows[key] = item
        # Mirror every fresh WSJT-X decode into Grid Tracker. A locator is only plotted
        # when it is explicitly present in the decoded message; no location is guessed.
        import re
        words=item.message.strip().upper().split()
        locator=next((word for word in words if re.fullmatch(r"[A-R]{2}[0-9]{2}(?:[A-X]{2}(?:[0-9]{2})?)?",word)), "—")
        callsign=self._callsign_from_cq(item.message) or next((word for word in words if re.fullmatch(r"(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]{3,12}(?:/[A-Z0-9]{1,5})?",word)), item.message[:24])
        grid_iid=key
        if not self.grid_station_tree.exists(grid_iid):
            self.grid_station_tree.insert("", "end", iid=grid_iid, values=(callsign,locator,item.mode,f"{item.snr_db:+d}"))
        else:
            self.grid_station_tree.item(grid_iid,values=(callsign,locator,item.mode,f"{item.snr_db:+d}"))
        grid_children=self.grid_station_tree.get_children()
        while len(grid_children)>100:
            self.grid_station_tree.delete(grid_children[0]); grid_children=self.grid_station_tree.get_children()
        children=self.station_tree.get_children()
        while len(children)>150:
            old=children[0]; self.station_tree.delete(old); self.station_rows.pop(old,None); children=self.station_tree.get_children()
        self.station_tree.selection_set(key); self.station_tree.see(key)

    @staticmethod
    def _callsign_from_cq(message):
        import re
        words = message.strip().upper().split()
        if not words or words[0] not in {"CQ", "QRZ"}:
            return ""
        # Skip common CQ qualifiers (DX, POTA, SOTA, TEST, etc.) and select
        # the first callsign-shaped token following the CQ prefix.
        pattern = re.compile(r"^(?=.*[A-Z])(?=.*\d)[A-Z0-9]{3,12}(?:/[A-Z0-9]{1,5})?$")
        for word in words[1:]:
            if word in {"DX", "POTA", "SOTA", "WW", "TEST", "FD", "QRP", "OTA", "NA", "EU"}:
                continue
            if pattern.match(word):
                return word
        return ""

    def _track_cq_decode(self, item):
        call = self._callsign_from_cq(item.message)
        if not call:
            return
        key = call.upper()
        record = self.worked_stations.get(key)
        if record is None:
            self.worked_stations[key] = {"call": call, "mode": item.mode, "last_message": item.message,
                                         "snr": item.snr_db, "status": "Heard CQ", "item": item,
                                         "first_seen": item.utc}
        else:
            record.update({"mode": item.mode, "last_message": item.message, "snr": item.snr_db, "item": item})
        self._refresh_worked_tree(key)

    def _track_reply_attempt(self, item):
        call = self._callsign_from_cq(item.message)
        if not call:
            return
        key = call.upper()
        self.worked_stations[key] = {"call": call, "mode": item.mode, "last_message": item.message,
                                     "snr": item.snr_db, "status": "QSO in progress / retry available",
                                     "item": item, "first_seen": item.utc}
        self._refresh_worked_tree(key)

    def open_worked_stations(self):
        if self.worked_window is not None and self.worked_window.winfo_exists():
            self.worked_window.deiconify(); self.worked_window.lift(); self._refresh_worked_tree()
            return
        win = tk.Toplevel(self)
        self.worked_window = win
        win.title("ARES-X — Worked Stations / QSO Tracker")
        win.geometry("980x540")
        win.minsize(760, 400)
        win.attributes("-topmost", True)
        win.configure(bg="#07111e")
        win.protocol("WM_DELETE_WINDOW", win.withdraw)
        outer = ttk.Frame(win, padding=14); outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="WORKED STATIONS / QSO TRACKER", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="CQ stations heard and reply attempts are kept here for this session. Select a row to retry a CQ reply.", style="Sub.TLabel", wraplength=730).pack(anchor="w", pady=(2,10))
        wrap = ttk.Frame(outer, style="Panel.TFrame"); wrap.pack(fill="both", expand=True)
        cols = ("call", "mode", "snr", "status", "message")
        tree = ttk.Treeview(wrap, columns=cols, show="headings", height=11, selectmode="browse")
        self.worked_tree = tree
        for col, title, width in [("call","Station",100),("mode","Mode",55),("snr","SNR",55),("status","QSO status",190),("message","Last decoded message",330)]:
            tree.heading(col, text=title); tree.column(col, width=width, stretch=(col in {"status","message"}), anchor="w")
        sb = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview); tree.configure(yscrollcommand=sb.set)
        tree.pack(side="left", fill="both", expand=True); sb.pack(side="right", fill="y")
        tree.bind("<Double-1>", lambda _e: self.retry_worked_station())
        actions = ttk.Frame(outer); actions.pack(fill="x", pady=(10,4))
        ttk.Button(actions, text="ENABLE TX / REPLY TO SELECTED", style="Accent.TButton", command=self.retry_worked_station).pack(side="left", fill="x", expand=True, padx=(0,4))
        ttk.Button(actions, text="HALT TX NOW", command=self.halt_tx).pack(side="left", padx=4)
        ttk.Button(actions, text="MARK QSO COMPLETE", command=self.mark_worked_complete).pack(side="left", padx=4)
        ttk.Button(actions, text="CLOSE", command=win.withdraw).pack(side="right", padx=(4,0))
        ttk.Label(outer, text="Enable TX / Reply starts a selected CQ reply through WSJT-X. WSJT-X's UDP interface cannot directly toggle its Enable Tx checkbox; Halt TX is sent immediately through UDP.", foreground="#ffca69", wraplength=730).pack(anchor="w", pady=(5,0))
        self._refresh_worked_tree()

    def _refresh_worked_tree(self, select_key=None):
        tree = self.worked_tree
        if tree is None:
            return
        try:
            if not tree.winfo_exists():
                self.worked_tree = None; return
            existing = set(tree.get_children())
            for key in existing - set(self.worked_stations):
                tree.delete(key)
            for key, rec in self.worked_stations.items():
                values = (rec["call"], rec["mode"], f'{rec["snr"]:+d} dB', rec["status"], rec["last_message"])
                if tree.exists(key): tree.item(key, values=values)
                else: tree.insert("", "end", iid=key, values=values)
            if select_key and tree.exists(select_key):
                tree.selection_set(select_key); tree.see(select_key)
        except tk.TclError:
            self.worked_tree = None

    def retry_worked_station(self):
        tree = self.worked_tree
        if tree is None or not tree.selection():
            messagebox.showinfo("ARES-X QSO Tracker", "Select a station in the Worked Stations window first.")
            return
        key = tree.selection()[0]
        record = self.worked_stations.get(key)
        if not record:
            return
        item = record.get("item")
        if not item or not item.message.strip().upper().startswith(("CQ ", "QRZ ")):
            messagebox.showinfo("ARES-X QSO Tracker", "A retry needs a recent CQ/QRZ decode from that station. Wait for the station to call CQ again, then select its new decode in Incoming Stations.")
            return
        # Reuse the same guarded reply workflow as the Incoming Stations list.
        if self.wsjtx_bridge is None:
            messagebox.showwarning("WSJT-X reply", "Start the FT4/FT8 bridge first."); return
        confirm = messagebox.askyesno("Confirm FT4/FT8 transmission", f"Start/restart a reply to {record['call']}?\n\n{item.message}\nMode: {item.mode}\n\nThis can initiate RF transmission. Verify Thetis PTT, VAC routing, power and frequency.")
        if not confirm:
            return
        try:
            target = self.wsjtx_bridge.reply_to_cq(item)
            record["status"] = "QSO in progress / retry sent"
            self._refresh_worked_tree(key)
            self._log(f"Worked Stations: reply/retry request sent for {record['call']} via {target[0]}:{target[1]}.")
            self.status.set(f"REPLY REQUEST SENT — {record['call']}")
        except Exception as e:
            messagebox.showerror("WSJT-X reply failed", str(e)); self._log(f"WSJT-X retry failed: {e}")

    def halt_tx(self):
        if self.wsjtx_bridge is None:
            messagebox.showwarning("Halt TX", "Start the WSJT-X FT4/FT8 bridge first and wait for a decode.")
            return
        if not messagebox.askyesno("Halt TX immediately", "Send HALT TX to WSJT-X now? This requests an immediate stop to transmission and disables automatic T/R sequencing."):
            return
        try:
            target = self.wsjtx_bridge.halt_tx()
            self.status.set("HALT TX COMMAND SENT TO WSJT-X")
            self._log(f"HALT TX command sent to WSJT-X at {target[0]}:{target[1]}.")
            messagebox.showinfo("Halt TX", "Halt TX command sent to WSJT-X. Confirm that WSJT-X and Thetis have returned to receive.")
        except Exception as e:
            messagebox.showerror("Halt TX failed", str(e)); self._log(f"Halt TX failed: {e}")

    def mark_worked_complete(self):
        tree = self.worked_tree
        if tree is None or not tree.selection():
            messagebox.showinfo("ARES-X QSO Tracker", "Select a station first."); return
        key = tree.selection()[0]
        record = self.worked_stations.get(key)
        if record:
            record["status"] = "Marked complete by operator"
            self._refresh_worked_tree(key)
            self._log(f"Operator marked {record['call']} QSO complete. This is a manual status, not an automatic WSJT-X log confirmation.")

    def reply_selected_station(self):
        if self.wsjtx_bridge is None:
            messagebox.showwarning("WSJT-X reply", "Start the FT4/FT8 bridge first and wait for a fresh WSJT-X decode.")
            return
        selected=self.station_tree.selection()
        if not selected:
            messagebox.showinfo("WSJT-X reply", "Select a CQ or QRZ decode in the Incoming Stations list first.")
            return
        item=self.station_rows.get(selected[0])
        if not item:
            messagebox.showwarning("WSJT-X reply", "That decode is no longer available. Select a current row.")
            return
        if not item.message.strip().upper().startswith(("CQ ", "QRZ ")):
            messagebox.showinfo("WSJT-X reply", "WSJT-X Reply is for CQ/QRZ decodes. Select a row beginning with CQ or QRZ.")
            return
        confirm=messagebox.askyesno("Confirm FT4/FT8 transmission", f"Ask WSJT-X to reply to this station?\n\n{item.message}\nMode: {item.mode}\nAudio offset: {item.audio_hz} Hz\n\nThis can initiate RF transmission. Confirm Thetis PTT, audio routing, power, and the correct operating frequency before proceeding.")
        if not confirm: return
        try:
            target=self.wsjtx_bridge.reply_to_cq(item)
            self._track_reply_attempt(item)
            self.status.set(f"WSJT-X REPLY REQUEST SENT — {item.message}")
            self._log(f"Reply request sent to WSJT-X for {item.message} via {target[0]}:{target[1]}. Check WSJT-X and Thetis TX status.")
        except Exception as e:
            messagebox.showerror("WSJT-X reply failed", str(e))
            self._log(f"WSJT-X reply failed: {type(e).__name__}: {e}")

    def _log(self,msg):
        if hasattr(self,"log"):
            self.log.insert("end",time.strftime("%H:%M:%S")+"  "+msg+"\n"); self.log.see("end")

    def _on_digital_mode_selected(self, _event=None):
        selected = self.kind.get().strip()
        external_modes = {"FST4", "FT4", "FT8", "JT4", "JT9", "JT65", "Q65", "MSK144", "FST4W", "WSPR", "Echo", "FreqCal"}
        if selected in external_modes:
            self.status.set(f"{selected} SELECTED — WSJT-X MODE")
            self.result.insert("end", f"\n{selected} selected. ARES-X is connecting to WSJT-X UDP so its reports can be received here. Select {selected} in WSJT-X itself; the UDP protocol does not provide a general remote mode-switch command.\n")
            self.result.see("end")
            if self.wsjtx_bridge is None:
                self.start_wsjtx_bridge()
            self._log(f"{selected} selected for WSJT-X integration.")

    def run_sim(self):
        try:
            selected_format = self.kind.get().strip()
            external_modes = {"FST4", "FT4", "FT8", "JT4", "JT9", "JT65", "Q65", "MSK144", "FST4W", "WSPR", "Echo", "FreqCal"}
            if selected_format in external_modes:
                self.result.delete("1.0", "end")
                self.result.insert("end", f"{selected_format} SELECTED — WSJT-X EXTERNAL MODE\n\nARES-X uses the WSJT-X UDP reporting interface for this mode. Start WSJT-X, select {selected_format} in WSJT-X, and enable UDP Server plus Accept UDP requests under Settings > Reporting. Incoming WSJT-X reports will appear in this decoder.\n\nARES-X does not generate or decode these standardized mode waveforms itself.")
                self.status.set(f"{selected_format} SELECTED — WSJT-X LINK")
                if self.wsjtx_bridge is None:
                    self.start_wsjtx_bridge()
                return
            payload=self.payload.get().strip().encode("ascii")
            if not payload or len(payload)>7: raise ValueError("Payload must be 1–7 ASCII bytes.")
            kind=["CQ / Beacon (type 1)","Call (type 2)","Report (type 3)","Ack (type 4)"].index(selected_format)+1
            cfg=ax.Config(); packet=ax.make_packet(kind,payload); symbols=ax.encode_frame(packet,cfg)
            samples=ax.synthesize(symbols,cfg,snr_db=float(self.snr.get()),freq_offset_hz=float(self.freq.get()),seed=1234)
            self.last_wave=samples
            self._show_decode(samples,"SIMULATION")
        except Exception as e: messagebox.showerror("ARES-X",str(e))

    def _show_decode(self,samples,source):
        self.result.delete("1.0","end")
        self.result.insert("end",f"Source: {source}\nSamples: {len(samples)}\n")
        try:
            decoded=ax.decode_frame(np.asarray(samples,dtype=float),ax.Config())
            self.result.insert("end",f"VALID PACKET — CRC PASS\nType: {decoded['type']}\nPayload: {decoded['payload'].decode('ascii',errors='replace')}\nSync start: {decoded['sync_start_sample']} samples\n")
            self.status.set(f"VALID PACKET — {source}")
            self._log(f"Decode passed from {source}: {decoded['payload']!r}")
        except Exception as e:
            self.result.insert("end",f"NO VALID DECODE\n{e}\n")
            self.status.set(f"NO VALID DECODE — {source}")
            self._log(f"Decode failed from {source}: {e}")

    def run_test(self):
        try:
            ax.self_test()
            self.status.set("SELF-TEST PASSED")
            self._log("PASS: packet, CRC rejection, FEC round-trip, timing acquisition baseline.")
            messagebox.showinfo("ARES-X","Protocol self-test passed.")
        except Exception as e:
            self.status.set("SELF-TEST FAILED"); self._log(f"Self-test failed: {e}")
            messagebox.showerror("ARES-X test",str(e))

    def export_wav(self):
        if self.last_wave is None:
            messagebox.showinfo("ARES-X","Run ENCODE + SIMULATE first."); return
        path=filedialog.asksaveasfilename(defaultextension=".wav",initialfile="ARES-X_AX1_LAB.wav",filetypes=[("WAV audio","*.wav")])
        if not path: return
        x=np.asarray(self.last_wave,dtype=float); peak=max(float(np.max(np.abs(x))),1e-9)
        pcm=np.int16(np.clip(x/peak*.75,-1,1)*32767)
        with wave.open(path,"wb") as f:
            f.setnchannels(1); f.setsampwidth(2); f.setframerate(ax.Config().fs); f.writeframes(pcm.tobytes())
        self._log(f"Exported lab WAV: {path}")
        messagebox.showinfo("ARES-X","WAV exported for laboratory testing. It is not an on-air-ready signal.")

    def open_wav(self):
        path=filedialog.askopenfilename(filetypes=[("WAV audio","*.wav")])
        if not path: return
        try:
            with wave.open(path,"rb") as f:
                channels=f.getnchannels(); width=f.getsampwidth(); rate=f.getframerate(); raw=f.readframes(f.getnframes())
            if width==2: x=np.frombuffer(raw,dtype="<i2").astype(np.float32)/32768
            elif width==4: x=np.frombuffer(raw,dtype="<i4").astype(np.float32)/2147483648
            elif width==1: x=(np.frombuffer(raw,dtype=np.uint8).astype(np.float32)-128)/128
            else: raise ValueError("Unsupported PCM sample width.")
            if channels>1: x=x.reshape(-1,channels).mean(axis=1)
            if rate!=ax.Config().fs:
                raise ValueError(f"WAV is {rate} Hz; this prototype currently requires {ax.Config().fs} Hz mono or multichannel PCM.")
            self._show_decode(x,"WAV FILE")
        except Exception as e: messagebox.showerror("WAV decode",str(e))

    def start_listen(self):
        if self.recording: return
        try:
            import sounddevice as sd
        except ImportError:
            messagebox.showerror("Audio input unavailable","Install dependencies using build_windows.bat. The sounddevice package is required for live audio input.")
            return
        selected=self.audio_device.get()
        device=None if selected=="Default input" else int(selected.split(" | ",1)[0])
        try:
            devices=sd.query_devices()
            dev_info=sd.query_devices(device, "input")
            native_rate=int(round(float(dev_info.get("default_samplerate") or 48000)))
            channels=max(1,min(2,int(dev_info.get("max_input_channels",1))))
            # VAC devices commonly expose 44.1/48 kHz, while AX-1's lab decoder
            # operates at 12 kHz. Capture at the device's native rate and resample.
            sd.check_input_settings(device=device, samplerate=native_rate, channels=channels, dtype="float32")
        except Exception as e:
            messagebox.showerror("Audio device settings",f"Could not open the selected input device. Try the VAC recording endpoint, not its playback endpoint.\n\n{e}")
            return
        self.recording=True; self.rx_buffer=np.zeros(0,dtype=np.float32); self.latest_audio_block=np.zeros(0,dtype=np.float32)
        self.spectrum_audio_buffer=np.zeros(0,dtype=np.float32)
        self.audio_sample_rate=native_rate
        def worker():
            try:
                def callback(indata,frames,time_info,status):
                    mono=indata.mean(axis=1).astype(np.float32,copy=True)
                    self.latest_audio_block=mono
                    # Retain enough native-rate VAC samples for the 16,384-point FFT.
                    self.spectrum_audio_buffer=np.concatenate((self.spectrum_audio_buffer,mono))[-16384:]
                    # Convert to the decoder's 12 kHz rate using interpolation. This is
                    # suitable for the prototype monitor; production DSP should use a
                    # proper anti-aliasing resampler.
                    target_rate=ax.Config().fs
                    if native_rate != target_rate and len(mono)>1:
                        n=max(1,int(round(len(mono)*target_rate/native_rate)))
                        old=np.arange(len(mono),dtype=np.float64)/native_rate
                        new_t=np.arange(n,dtype=np.float64)/target_rate
                        mono=np.interp(new_t,old,mono).astype(np.float32)
                    self.rx_buffer=np.concatenate((self.rx_buffer,mono))
                    maxlen=12*target_rate
                    if len(self.rx_buffer)>maxlen: self.rx_buffer=self.rx_buffer[-maxlen:]
                with sd.InputStream(device=device,samplerate=native_rate,channels=channels,dtype="float32",callback=callback,blocksize=0):
                    self.after(0,lambda:self.status.set(f"LIVE AUDIO — {native_rate} Hz input; AX-1 monitor at {ax.Config().fs} Hz"))
                    self.after(0,lambda:self._log(f"Audio stream opened: {dev_info['name']} at {native_rate} Hz, {channels} channel(s)."))
                    while self.recording:
                        time.sleep(1.0)
                        buf=self.rx_buffer.copy()
                        # Best-effort experimental decoder only. The display/audio meter
                        # updates independently even when no valid ARES-X frame is present.
                        if len(buf)>=ax.Config().fs*2:
                            try:
                                decoded=ax.decode_frame(buf,ax.Config(),max_start=ax.Config().sps*2)
                                key=(decoded["type"],decoded["payload"])
                                if key!=self.last_decode_key:
                                    self.last_decode_key=key
                                    self.after(0,lambda d=decoded:self._live_result(d))
                            except Exception:
                                pass
            except Exception as e:
                self.after(0,lambda err=str(e):self._audio_error(err))
            finally:
                self.recording=False
        self.audio_thread=threading.Thread(target=worker,daemon=True); self.audio_thread.start()
        self._log("Live audio requested. Confirm Thetis VAC is routed to this selected Windows recording/input endpoint.")

    def _audio_spectrum_window(self, sample_rate, fft_bins):
        """Return the visible live-audio FFT bin range for the pan/zoom controls."""
        nyquist = max(1.0, float(sample_rate) / 2.0)
        zoom = max(1.0, min(32.0, float(self.band_view_zoom.get())))
        visible_hz = nyquist / zoom
        center_fraction = float(self.band_view_center.get()) / 100.0
        center_hz = center_fraction * nyquist
        start_hz = max(0.0, min(nyquist - visible_hz, center_hz - visible_hz / 2.0))
        end_hz = start_hz + visible_hz
        bin_hz = nyquist / max(1, fft_bins)
        first = max(0, min(fft_bins - 1, int(start_hz / bin_hz)))
        last = max(first + 1, min(fft_bins, int(end_hz / bin_hz) + 1))
        return first, last, start_hz, end_hz, nyquist, zoom

    def _update_band_view(self):
        """Redraw the current live FFT immediately when either slider moves."""
        try:
            if getattr(self, "recording", False) and len(getattr(self, "spectrum_audio_buffer", [])) >= 64:
                block = self.spectrum_audio_buffer.copy()
                self._draw_live_spectrum(block, self.audio_sample_rate or 48000,
                                         float(np.max(np.abs(block))))
            else:
                self._draw_band_frequency_ruler()
        except Exception:
            pass

    def _on_band_view_changed(self):
        self._update_band_view()

    def _draw_band_frequency_ruler(self, sample_rate=None, fft_bins=None):
        if not hasattr(self, "band_frequency_ruler"):
            return
        c = self.band_frequency_ruler
        c.delete("all")
        w = max(100, c.winfo_width())
        sr = float(sample_rate or getattr(self, "audio_sample_rate", 48000) or 48000)
        bins = int(fft_bins or 2048)
        _, _, start_hz, end_hz, nyquist, zoom = self._audio_spectrum_window(sr, bins)
        selected_band = self.band_choice.get().split(" — ", 1)[0] if hasattr(self, "band_choice") else "Band"
        try:
            dial_hz = dict(self._band_table()).get(selected_band)
            band_label = f"{selected_band} ({dial_hz/1e6:.3f} MHz)" if dial_hz else selected_band
        except Exception:
            band_label = selected_band
        c.create_text(6, 2, anchor="nw", fill="#76cfff",
                      text=f"{band_label}  |  AUDIO: {start_hz/1000:.2f}–{end_hz/1000:.2f} kHz  |  {zoom:.1f}×")
        y0 = 18
        c.create_line(8, y0, w-8, y0, fill="#45627a")
        for j in range(5):
            x = 8 + j * (w-16) / 4
            f = start_hz + (end_hz-start_hz) * j / 4
            c.create_line(x, y0-4, x, y0+4, fill="#8bb7d5")
            label = f"{f/1000:.2f}k" if f >= 1000 else f"{f:.0f}"
            c.create_text(x, 29, anchor="s", fill="#a9c5d9", font=("Consolas", 8), text=label)

    def _refresh_live_display(self):
        try:
            if self.recording and len(self.latest_audio_block):
                level_block=self.latest_audio_block.copy()
                block=self.spectrum_audio_buffer.copy() if len(self.spectrum_audio_buffer) else level_block
                rms=float(np.sqrt(np.mean(level_block.astype(np.float64)**2))) if len(level_block) else 0.0
                peak=float(np.max(np.abs(level_block))) if len(level_block) else 0.0
                self.audio_level.set(f"Audio RMS {20*np.log10(max(rms,1e-7)):.0f} dBFS")
                self._draw_live_spectrum(block, self.audio_sample_rate or 48000, peak)
                self._wide_graph_update(block, self.audio_sample_rate or 48000)
            elif not self.recording:
                self.audio_level.set("Audio: —")
        except Exception:
            pass
        if self.winfo_exists(): self.after(150, self._refresh_live_display)

    def _draw_live_spectrum(self, samples, sample_rate, peak):
        c=self.canvas; w=max(300,c.winfo_width()); h=max(150,c.winfo_height())
        c.delete("all")
        for x in range(0,w,25): c.create_line(x,0,x,h,fill="#10243a")
        for y in range(0,h,22): c.create_line(0,y,w,y,fill="#10243a")
        n=min(16384,len(samples))
        if n<64:
            c.create_text(w/2,h/2,fill="#ffca69",text="Waiting for audio samples…")
            self._draw_band_frequency_ruler(sample_rate, max(1,n//2))
            return
        x=np.asarray(samples[-n:],dtype=np.float32); x=x-np.mean(x); win=np.hanning(n)
        full_spec=20*np.log10(np.maximum(np.abs(np.fft.rfft(x*win)),1e-8))
        # Omit DC, then select the visible frequency slice controlled by Spectrum and Zoom.
        spec=full_spec[1:]
        # On the first usable live block, center the strongest audio peak in the viewport.
        # The operator can then use the Spectrum slider for manual left/right panning.
        if not self._spectrum_auto_centered and len(spec) > 8:
            peak_index = int(np.argmax(spec))
            peak_hz = (peak_index + 1) * (float(sample_rate) / n)
            self.band_view_zoom.set(max(4.0, float(self.band_view_zoom.get())))
            nyquist_for_center = max(1.0, float(sample_rate) / 2.0)
            self.band_view_center.set(max(0.0, min(100.0, peak_hz / nyquist_for_center * 100.0)))
            self._spectrum_auto_centered = True
        first,last,start_hz,end_hz,nyquist,zoom=self._audio_spectrum_window(sample_rate,len(spec))
        visible=spec[first:last]
        if len(visible)<2:
            visible=spec
            first=0
            start_hz=0.0
            end_hz=nyquist
        lo=float(np.percentile(visible,10)); hi=float(np.percentile(visible,99.5)); span=max(hi-lo,10.0)
        points=[]
        for i,v in enumerate(visible):
            xx=i*(w-2)/(len(visible)-1 if len(visible)>1 else 1)+1
            yy=h-8-(float(v)-lo)/span*(h-32)
            points.extend((xx,max(24,min(h-8,yy))))
        if len(points)>=4: c.create_line(*points,fill="#16d6a4",width=1.4)
        if not hasattr(self,"_waterfall_history"):
            self._waterfall_history=[]
        self._waterfall_history.insert(0,visible.copy())
        self._waterfall_history=self._waterfall_history[:self._waterfall_max_rows]
        self._append_waterfall_row(visible)
        selected_band = self.band_choice.get().split(" — ", 1)[0] if hasattr(self, "band_choice") else "Band"
        try:
            dial_hz = dict(self._band_table()).get(selected_band)
            band_label = f"{selected_band} • {dial_hz/1e6:.3f} MHz dial" if dial_hz else selected_band
        except Exception:
            band_label = selected_band
        c.create_text(12,10,anchor="nw",fill="#76cfff",
                      text=f"{band_label}  |  LIVE AUDIO FFT {start_hz:.0f}–{end_hz:.0f} Hz  |  {zoom:.1f}×  |  peak {peak:.3f}")
        c.create_text(10,h-6,anchor="sw",fill="#547a9a",
                      text="Live VAC audio spectrum • drag Spectrum to pan; Zoom narrows the displayed frequency range")
        self._draw_band_frequency_ruler(sample_rate,len(spec))

    def _on_waterfall_palette_selected(self):
        if self.waterfall_palette.get() == "Custom…":
            self._open_waterfall_color_mixer()
        else:
            self._redraw_waterfall()

    def _open_waterfall_color_mixer(self):
        """Simple three-stop color mixer with live preview and saved custom colors."""
        win=tk.Toplevel(self)
        win.title("ARES-X Waterfall Color Mixer")
        win.configure(bg="#0b1a29")
        win.transient(self)
        win.grab_set()
        colors=list(getattr(self,"waterfall_custom_colors",["#000018","#00bec0","#fffff5"]))
        if len(colors)!=3:
            colors=["#000018","#00bec0","#fffff5"]
        labels=("Background / Weak Signal","Mid Signal","Strong Signal")
        buttons=[]
        def refresh_button(index):
            buttons[index].configure(bg=colors[index],activebackground=colors[index])
        def choose_color(index):
            picked=colorchooser.askcolor(color=colors[index],parent=win,title=f"Choose {labels[index]} color")
            if picked and picked[1]:
                colors[index]=picked[1]
                refresh_button(index)
                self.waterfall_custom_colors=list(colors)
                self.waterfall_palette.set("Custom…")
                self._redraw_waterfall()
        ttk.Label(win,text="BUILD YOUR OWN WATERFALL COLORS",style="PanelTitle.TLabel").pack(anchor="w",padx=14,pady=(14,8))
        ttk.Label(win,text="Choose three colors. ARES-X blends smoothly between them.",foreground="#9db2c5",background="#0b1a29").pack(anchor="w",padx=14,pady=(0,10))
        for idx,label in enumerate(labels):
            row=ttk.Frame(win); row.pack(fill="x",padx=14,pady=5)
            ttk.Label(row,text=label,width=25).pack(side="left")
            btn=tk.Button(row,text=colors[idx],width=13,relief="flat",fg="white",
                          command=lambda i=idx:choose_color(i))
            btn.pack(side="left")
            buttons.append(btn)
        preview=tk.Canvas(win,height=26,bg="#030a12",highlightthickness=0)
        preview.pack(fill="x",padx=14,pady=10)
        def draw_preview():
            preview.delete("all")
            width=max(100,preview.winfo_width())
            stops=[(0,colors[0]),(0.5,colors[1]),(1,colors[2])]
            for x in range(width):
                pos=x/max(1,width-1)
                if pos<=0.5:
                    a,b,t=0,1,pos*2
                else:
                    a,b,t=1,2,(pos-0.5)*2
                ca=tuple(int(colorspec,16) for colorspec in [colors[a][1:3],colors[a][3:5],colors[a][5:7]])
                cb=tuple(int(colorspec,16) for colorspec in [colors[b][1:3],colors[b][3:5],colors[b][5:7]])
                rgb=tuple(int(ca[k]+(cb[k]-ca[k])*t) for k in range(3))
                preview.create_line(x,0,x,26,fill="#%02x%02x%02x"%rgb)
        preview.bind("<Configure>",lambda _e:draw_preview())
        actions=ttk.Frame(win); actions.pack(fill="x",padx=14,pady=(0,14))
        def apply():
            self.waterfall_custom_colors=list(colors)
            self.waterfall_palette.set("Custom…")
            self.saved_settings["waterfall_custom_colors"]=list(colors)
            self.saved_settings["waterfall_palette"]="Custom…"
            self._save_settings()
            self._redraw_waterfall()
            win.destroy()
        ttk.Button(actions,text="APPLY & SAVE",command=apply).pack(side="right")
        ttk.Button(actions,text="CLOSE",command=win.destroy).pack(side="right",padx=6)
        win.geometry("440x260")
        self.after(100,draw_preview)

    def _waterfall_color(self, value):
        """Map normalized signal intensity (0..1) into the selected waterfall palette."""
        value=max(0.0,min(1.0,float(value)))
        palettes={
            "Classic":[(0.0,(0,0,18)),(0.25,(0,28,100)),(0.5,(0,190,190)),(0.75,(255,220,0)),(1.0,(255,255,245))],
            "Fire":[(0.0,(8,0,0)),(0.25,(100,0,0)),(0.5,(235,45,0)),(0.75,(255,170,0)),(1.0,(255,255,190))],
            "Ice":[(0.0,(0,5,24)),(0.25,(0,55,110)),(0.5,(0,170,220)),(0.75,(120,235,255)),(1.0,(255,255,255))],
            "Spectrum":[(0.0,(20,0,50)),(0.25,(0,50,220)),(0.5,(0,220,100)),(0.75,(255,220,0)),(1.0,(255,30,20))],
            "Green":[(0.0,(0,8,0)),(0.25,(0,65,12)),(0.5,(0,150,35)),(0.75,(100,230,35)),(1.0,(230,255,180))]
        }
        if self.waterfall_palette.get() == "Custom…":
            custom=getattr(self,"waterfall_custom_colors",["#000018","#00bec0","#fffff5"])
            try:
                rgb=[tuple(int(c[i:i+2],16) for i in (1,3,5)) for c in custom]
                stops=[(0.0,rgb[0]),(0.5,rgb[1]),(1.0,rgb[2])]
            except Exception:
                stops=palettes["Classic"]
        else:
            stops=palettes.get(self.waterfall_palette.get(),palettes["Classic"])
        for idx in range(len(stops)-1):
            a,ca=stops[idx]; b,cb=stops[idx+1]
            if value<=b:
                t=(value-a)/(b-a)
                rgb=tuple(int(ca[k]+(cb[k]-ca[k])*t) for k in range(3))
                return "#%02x%02x%02x"%rgb
        return "#ffffff"

    def _render_waterfall_history(self):
        """Render as many historical lines as fit; a taller pane reveals more history."""
        if not hasattr(self,"waterfall_canvas"):
            return
        c=self.waterfall_canvas
        c.delete("all")
        self._waterfall_rows=[]
        history=getattr(self,"_waterfall_history",[])
        width=max(100,c.winfo_width())
        height=max(40,c.winfo_height())
        # Aim for roughly 2.5-pixel rows. Taller pane => more visible time history.
        visible_count=max(1,min(len(history),int(height/2.5)))
        if visible_count<=0:
            return
        row_height=height/visible_count
        for row_index,values in enumerate(history[:visible_count]):
            vals=np.asarray(values,dtype=float)
            bins=min(self._waterfall_bins,len(vals))
            if bins<2:
                continue
            floor=float(np.percentile(vals,15))
            ceiling=float(np.percentile(vals,99))
            dynamic=max(12.0,ceiling-floor)
            sampled=np.interp(np.linspace(0,len(vals)-1,bins),np.arange(len(vals)),vals)
            y0=row_index*row_height
            y1=(row_index+1)*row_height+0.5
            for i,value in enumerate(sampled):
                color=self._waterfall_color((float(value)-floor)/dynamic)
                x0=i*width/bins
                x1=(i+1)*width/bins+0.5
                c.create_rectangle(x0,y0,x1,y1,fill=color,outline="")
        self._waterfall_visible_rows=visible_count

    def _append_waterfall_row(self, spectrum_values):
        """Refresh waterfall after a new live FFT row, paced to keep the UI responsive."""
        if not hasattr(self,"waterfall_canvas"):
            return
        now=time.monotonic()
        if now-getattr(self,"_waterfall_last_draw",0.0)<0.25:
            return
        self._waterfall_last_draw=now
        self._render_waterfall_history()

    def _redraw_waterfall(self):
        """Recolor retained history and adapt visible history to current pane height."""
        self._render_waterfall_history()

    def _live_result(self,d):
        self.result.delete("1.0","end")
        self.result.insert("end",f"VALID PACKET — LIVE AUDIO (experimental)\nType: {d['type']}\nPayload: {d['payload'].decode('ascii',errors='replace')}\n")
        self.status.set("PACKET DECODED — LIVE AUDIO")
        self._log(f"Live decode: {d['payload']!r}")

    def _audio_error(self,err):
        self.status.set("AUDIO INPUT ERROR"); self._log("Audio error: "+err)
        messagebox.showerror("Audio input",err)

    def stop_listen(self):
        self.recording=False
        self.status.set("LISTEN STOPPED")
        self.audio_level.set("Audio: —")
        self._log("Audio listening stopped.")

    def destroy(self):
        self.recording=False
        if self.cat: self.cat.disconnect()
        super().destroy()

if __name__=="__main__":
    AresXApp().mainloop()
