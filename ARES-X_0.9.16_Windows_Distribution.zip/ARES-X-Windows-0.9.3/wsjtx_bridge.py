"""WSJT-X UDP receive bridge for ARES-X.

WSJT-X remains the FT4/FT8 modem/decoder. This module receives its decoded
message notifications over the documented WSJT-X UDP protocol; it does not
implement FT4/FT8 modulation or decoding itself.
"""
from __future__ import annotations
import socket
import struct
import threading
import queue
from dataclasses import dataclass

MAGIC = 0xADBCCBDA

@dataclass
class DecodedMessage:
    utc: str
    snr_db: int
    delta_time: float
    audio_hz: int
    mode: str
    message: str
    low_confidence: bool = False
    off_air: bool = False
    is_new: bool = True
    client_id: str = ""
    source_addr: tuple | None = None

class QtReader:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0
    def take(self, n):
        if self.pos + n > len(self.data):
            raise ValueError("truncated Qt datagram")
        b = self.data[self.pos:self.pos+n]
        self.pos += n
        return b
    def u8(self): return self.take(1)[0]
    def boolean(self): return self.u8() != 0
    def i32(self): return struct.unpack(">i", self.take(4))[0]
    def u32(self): return struct.unpack(">I", self.take(4))[0]
    def i64(self): return struct.unpack(">q", self.take(8))[0]
    def f64(self): return struct.unpack(">d", self.take(8))[0]
    def qbytearray(self):
        n = self.u32()
        if n == 0xffffffff: return b""
        if n > 100000: raise ValueError("oversized QByteArray")
        return self.take(n)
    def qstring(self):
        raw = self.qbytearray()
        return raw.decode("utf-16-be", errors="replace") if raw else ""
    def qtime(self):
        # QTime is serialized as milliseconds since midnight (quint32).
        ms = self.u32()
        if ms == 0xffffffff: return ""
        sec = ms // 1000
        return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}"

def parse_decode_datagram(data: bytes, source_addr=None):
    r = QtReader(data)
    if r.u32() != MAGIC: return None
    schema = r.u32()
    msg_type = r.u32()
    # Every WSJT-X UDP message includes a QString client ID after the common header.
    client_id = r.qbytearray().decode("utf-8", errors="replace")
    if schema > 3 or msg_type not in (2, 10): return None
    is_new = r.boolean()
    utc = r.qtime()
    snr = r.i32()
    delta_time = r.f64()
    audio_hz = r.u32()
    if msg_type == 10:
        # WSJT-X WSPRDecode: callsign, locator, and transmitter power.
        callsign = r.qbytearray().decode("utf-8", errors="replace")
        locator = r.qbytearray().decode("utf-8", errors="replace")
        power = r.i32()
        mode = "WSPR"
        message = f"{callsign} {locator} {power} dBm".strip()
        low_confidence = False
        off_air = False
    else:
        # WSJT-X protocol encodes Mode and Message as UTF-8 QByteArrays,
        # not Qt QStrings. Decoding these as UTF-16 produces garbled glyphs.
        mode = r.qbytearray().decode("utf-8", errors="replace")
        message = r.qbytearray().decode("utf-8", errors="replace")
        low_confidence = r.boolean()
        off_air = r.boolean()
    if not message.strip(): return None
    return DecodedMessage(utc, snr, delta_time, audio_hz, mode, message,
                          low_confidence, off_air, is_new, client_id, source_addr)

def parse_status_datagram(data: bytes):
    """Parse WSJT-X Status (message type 1) TX/decode state fields."""
    r = QtReader(data)
    if r.u32() != MAGIC: return None
    schema = r.u32()
    msg_type = r.u32()
    client_id = r.qbytearray().decode("utf-8", errors="replace")
    if schema > 3 or msg_type != 1: return None
    # WSJT-X Status message fields in protocol order.
    r.f64()                         # dial frequency
    mode = r.qbytearray().decode("utf-8", errors="replace")
    r.qbytearray()                  # DX call
    r.qbytearray()                  # report
    r.qbytearray()                  # TX mode
    tx_enabled = r.boolean()
    transmitting = r.boolean()
    decoding = r.boolean()
    return {"client_id": client_id, "mode": mode, "tx_enabled": tx_enabled,
            "transmitting": transmitting, "decoding": decoding}

class WSJTXBridge:
    def __init__(self, host="127.0.0.1", port=2237):
        self.host, self.port = host, int(port)
        self.messages = queue.Queue()
        self.status_updates = queue.Queue()
        self._sock = None
        self._thread = None
        self._stop = threading.Event()
    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._stop.clear()
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.settimeout(0.4)
        self._sock.bind((self.host, self.port))
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
    def _run(self):
        while not self._stop.is_set():
            try:
                data, addr = self._sock.recvfrom(65535)
                try:
                    state = parse_status_datagram(data)
                    if state:
                        self.status_updates.put(state)
                        continue
                    item = parse_decode_datagram(data, addr)
                    if item:
                        self.last_source_addr = addr
                        self.last_client_id = item.client_id
                        self.messages.put(item)
                except (ValueError, struct.error, UnicodeError):
                    continue
            except socket.timeout:
                continue
            except OSError:
                break
    @staticmethod
    def _qbytearray(value):
        raw = value.encode("utf-8") if isinstance(value, str) else bytes(value)
        return struct.pack(">I", len(raw)) + raw

    def reply_to_cq(self, item):
        """Ask WSJT-X to reply to a previously decoded CQ/QRZ.

        This command can initiate transmission; callers must gate it behind an
        explicit operator action and confirmation.
        """
        if not item or not item.source_addr or not item.client_id:
            raise RuntimeError("No WSJT-X source endpoint is known yet. Wait for a fresh decode.")
        parts = item.message.strip().split()
        if not parts or parts[0].upper() not in {"CQ", "QRZ"}:
            raise ValueError("Only a decoded CQ or QRZ message can be started with Reply. Select a CQ/QRZ row.")
        payload = struct.pack(">III", MAGIC, 3, 4)
        payload += self._qbytearray(item.client_id)
        # Reply payload mirrors the selected decode, exactly as WSJT-X expects.
        ms = 0
        if item.utc:
            try:
                hh, mm, ss = (int(x) for x in item.utc.split(":"))
                ms = ((hh * 3600 + mm * 60 + ss) * 1000)
            except (ValueError, TypeError):
                ms = 0
        payload += struct.pack(">IidI", ms, item.snr_db, item.delta_time, item.audio_hz)
        payload += self._qbytearray(item.mode)
        payload += self._qbytearray(item.message)
        payload += struct.pack(">BB", int(item.low_confidence), 0)  # no modifier keys
        if not self._sock:
            raise RuntimeError("WSJT-X bridge is not running.")
        self._sock.sendto(payload, item.source_addr)
        return item.source_addr

    def halt_tx(self, item=None, auto_tx_only=False):
        """Send WSJT-X Halt Tx command to the most recently heard client.

        The UDP API supports Halt Tx but does not expose a direct Enable Tx
        toggle. Starting a QSO is done with Reply (or Free Text send).
        """
        if not self._sock:
            raise RuntimeError("WSJT-X bridge is not running.")
        if item is not None and item.source_addr and item.client_id:
            target = item.source_addr
            client_id = item.client_id
        else:
            target = getattr(self, "last_source_addr", None)
            client_id = getattr(self, "last_client_id", "")
        if not target or not client_id:
            raise RuntimeError("No WSJT-X client has sent a decode yet. Wait for a fresh decode.")
        payload = struct.pack(">III", MAGIC, 3, 8)
        payload += self._qbytearray(client_id)
        payload += struct.pack(">B", int(bool(auto_tx_only)))
        self._sock.sendto(payload, target)
        return target

    def stop(self):
        self._stop.set()
        if self._sock:
            try: self._sock.close()
            except OSError: pass
        self._sock = None
    def drain(self, limit=100):
        out=[]
        for _ in range(limit):
            try: out.append(self.messages.get_nowait())
            except queue.Empty: break
        return out

    def drain_status(self, limit=100):
        """Return queued WSJT-X status updates without blocking the UI poll."""
        out=[]
        for _ in range(limit):
            try: out.append(self.status_updates.get_nowait())
            except queue.Empty: break
        return out
