# ARES-X AX-1 Protocol Core — Draft 0.2

**Owner:** N2MDX project
**Status:** Experimental lab prototype; not frozen, not approved for on-air use.

## Physical layer candidate
- Continuous-phase 4-FSK test waveform.
- 12 symbols/s, 12 Hz tone spacing, 12 kHz sample rate, 1500 Hz audio center in the current harness. These are lab parameters and do not by themselves establish a 50–100 Hz occupied bandwidth.
- 16-symbol known synchronization sequence.
- Hard-decision rate-1/2 convolutional FEC, constraint length 7, generator polynomials 171 and 133 octal, terminated with six zero bits.
- CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF).

## Packet format
`MAGIC[2] | VERSION[1] | TYPE[1] | PAYLOAD_LENGTH[1] | PAYLOAD[0..7] | CRC16[2]`

- MAGIC: ASCII `AX`
- VERSION: `1`
- TYPE: application message type byte
- PAYLOAD_LENGTH: 0 through 7 bytes
- CRC16: big-endian CRC over all preceding packet bytes

This compact generic packet is a protocol-core scaffold. Callsign compression, grid/report encoding, reserved message types, nonstandard callsign support, and final QSO state transitions are not yet specified.

## Decoder behavior
- Searches integer-sample timing offsets within one symbol period using a known sync sequence.
- Detects tones using per-symbol tone-energy comparison.
- Uses hard-decision Viterbi decoding.
- Validates magic, version, length, and CRC before returning a packet.
- Does not yet estimate carrier-frequency offset, handle multiple overlapping stations, or use soft-decision metrics.

## Initial validation
Run `python ares_x_ax1_v02.py --test`. Tests cover packet encode/decode, CRC corruption rejection, clean-channel FEC round-trip, and a small timing offset. These tests prove only basic implementation correctness, not sensitivity or superiority to FT8.

## Next gates
1. Add frequency-offset search and soft-decision metrics.
2. Design a compact callsign/QSO message schema.
3. Add Monte Carlo performance harness with matched FT8 reference.
4. Measure false-decode probability and confidence intervals.
5. Implement a Windows audio I/O and waterfall application after protocol stabilization.
6. Review applicable FCC rules and band plans before any on-air testing.
