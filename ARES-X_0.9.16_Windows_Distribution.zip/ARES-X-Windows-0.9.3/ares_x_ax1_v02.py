"""ARES-X AX-1 protocol-core prototype 0.2 (N2MDX research build).

Lab-only software. Not approved or recommended for on-air use.
Requirements: Python 3.10+, NumPy
Run: python ares_x_ax1_v02.py --test
      python ares_x_ax1_v02.py --snr 0
"""
from __future__ import annotations
import argparse, math, struct
from dataclasses import dataclass
from typing import Sequence
import numpy as np

VERSION = "ARES-X AX-1 protocol-core prototype 0.2"
MAGIC = b"AX"
PROTOCOL_VERSION = 1
SYNC = (0,3,1,2,3,0,2,1,1,3,0,2,1,0,3,2)
# 4-FSK lab profile. 12 sym/s gives 83.3 ms/symbol; a 7-byte payload with
# CRC16 and rate-1/2 terminated convolutional FEC fits near the 5-10 s target.
@dataclass(frozen=True)
class Config:
    fs: int = 12000
    symbol_rate: float = 12.0
    tone_spacing: float = 12.0
    center_hz: float = 1500.0
    sync: tuple[int,...] = SYNC
    @property
    def sps(self):
        n=self.fs/self.symbol_rate
        if abs(n-round(n))>1e-9: raise ValueError("fs/symbol_rate must be integer")
        return int(round(n))

# CRC-16/CCITT-FALSE: poly 0x1021, init 0xFFFF, no reflection, xorout 0.
def crc16(data: bytes) -> int:
    crc=0xFFFF
    for b in data:
        crc ^= b << 8
        for _ in range(8): crc=((crc<<1)^0x1021)&0xFFFF if crc&0x8000 else (crc<<1)&0xFFFF
    return crc

def bytes_to_bits(data: bytes) -> list[int]:
    return [(b >> i)&1 for b in data for i in range(7,-1,-1)]
def bits_to_bytes(bits: Sequence[int]) -> bytes:
    if len(bits)%8: raise ValueError("bit length must be divisible by 8")
    return bytes(sum((int(bits[j+k])&1)<<(7-k) for k in range(8)) for j in range(0,len(bits),8))

def conv_encode(bits: Sequence[int]) -> list[int]:
    """Rate-1/2, constraint length 7 convolutional encoder, generators 171/133 octal."""
    state=0; out=[]; mask=0o171; mask2=0o133
    for bit in list(bits)+[0]*6:
        reg=((state<<1)|int(bit))&0x7F
        out.append((reg&mask).bit_count()&1)
        out.append((reg&mask2).bit_count()&1)
        state=reg&0x3F
    return out

def viterbi_decode(coded: Sequence[int]) -> list[int]:
    """Hard-decision Viterbi decoder for the terminated K=7 code."""
    if len(coded)%2: raise ValueError("coded bit count must be even")
    pairs=[(int(coded[i]),int(coded[i+1])) for i in range(0,len(coded),2)]
    nstates=64; inf=10**9
    metrics=[inf]*nstates; metrics[0]=0
    paths=[None]*nstates; paths[0]=[]
    for y0,y1 in pairs:
        newm=[inf]*nstates; newp=[None]*nstates
        for state in range(nstates):
            if metrics[state]>=inf: continue
            for bit in (0,1):
                reg=((state<<1)|bit)&0x7F
                ns=reg&0x3F
                expected=((reg&0o171).bit_count()&1,(reg&0o133).bit_count()&1)
                dist=(expected[0]!=y0)+(expected[1]!=y1)
                cand=metrics[state]+dist
                if cand<newm[ns]:
                    newm[ns]=cand; newp[ns]=paths[state]+[bit]
        metrics,paths=newm,newp
    decoded=paths[0]
    if decoded is None: raise ValueError("Viterbi decode failed")
    return decoded[:-6]  # remove six terminating zero bits

def make_packet(kind: int, payload: bytes) -> bytes:
    """Packet: magic(2), version(1), type(1), payload_len(1), payload(0..7), CRC16(2)."""
    if not 0<=kind<=255: raise ValueError("kind must be 0..255")
    if len(payload)>7: raise ValueError("payload limited to 7 bytes in this prototype profile")
    body=MAGIC+bytes([PROTOCOL_VERSION,kind,len(payload)])+payload
    return body+struct.pack('>H',crc16(body))

def parse_packet(packet: bytes) -> dict:
    if len(packet)<7: raise ValueError("packet too short")
    if packet[:2]!=MAGIC: raise ValueError("bad magic")
    if packet[2]!=PROTOCOL_VERSION: raise ValueError("unsupported protocol version")
    n=packet[4]
    if n>7 or len(packet)!=5+n+2: raise ValueError("invalid packet length")
    expected=struct.unpack('>H',packet[-2:])[0]
    if crc16(packet[:-2])!=expected: raise ValueError("CRC mismatch")
    return {"version":packet[2],"type":packet[3],"payload":packet[5:-2]}

def bits_to_4fsk(bits: Sequence[int]) -> list[int]:
    if len(bits)%2: raise ValueError("bit count must be even")
    return [(int(bits[i])<<1)|int(bits[i+1]) for i in range(0,len(bits),2)]
def fourfsk_to_bits(symbols: Sequence[int]) -> list[int]:
    return [b for s in symbols for b in ((int(s)>>1)&1,int(s)&1)]

def encode_frame(packet: bytes, cfg: Config=Config()) -> list[int]:
    coded=conv_encode(bytes_to_bits(packet))
    return list(cfg.sync)+bits_to_4fsk(coded)

def synthesize(symbols: Sequence[int], cfg: Config=Config(), snr_db: float=100,
               freq_offset_hz: float=0, timing_offset_samples: int=0, seed: int=1) -> np.ndarray:
    sps=cfg.sps; offsets=np.array([-1.5,-.5,.5,1.5])*cfg.tone_spacing
    phase=0.0; chunks=[]
    for sym in symbols:
        f=cfg.center_hz+freq_offset_hz+offsets[int(sym)]
        inc=2*np.pi*f/cfg.fs
        ph=phase+inc*np.arange(sps)
        chunks.append(np.cos(ph)); phase=float((phase+inc*sps)%(2*np.pi))
    signal=np.concatenate(chunks).astype(float)
    if timing_offset_samples>0: signal=np.r_[np.zeros(timing_offset_samples),signal]
    elif timing_offset_samples<0: signal=signal[min(len(signal),-timing_offset_samples):]
    if snr_db<90:
        rng=np.random.default_rng(seed); ps=float(np.mean(signal**2)); pn=ps/(10**(snr_db/10))
        signal=signal+rng.normal(0,math.sqrt(pn),len(signal))
    return signal

def tone_energies(x: np.ndarray, cfg: Config, freq_offset_hz: float=0) -> np.ndarray:
    sps=cfg.sps; offsets=np.array([-1.5,-.5,.5,1.5])*cfg.tone_spacing
    freqs=cfg.center_hz+freq_offset_hz+offsets; t=np.arange(sps)/cfg.fs
    refs=np.exp(-2j*np.pi*freqs[:,None]*t[None,:])
    return np.abs(refs@x)**2

def detect_symbols(samples: np.ndarray, count: int, cfg: Config=Config(), start: int=0,
                   freq_offset_hz: float=0) -> list[int]:
    sps=cfg.sps; out=[]
    for i in range(count):
        a=start+i*sps; b=a+sps
        if a<0 or b>len(samples): raise ValueError("not enough samples")
        out.append(int(np.argmax(tone_energies(samples[a:b],cfg,freq_offset_hz))))
    return out

def find_sync(samples: np.ndarray, cfg: Config=Config(), max_start: int|None=None) -> tuple[int,float]:
    sps=cfg.sps; max_start=sps if max_start is None else max_start
    best=(-1,-float('inf'))
    # Energy scoring for known sync tones. This first version assumes zero CFO;
    # frequency-offset acquisition is a required next milestone.
    for start in range(max_start):
        score=0.0; ok=True
        for i,expected in enumerate(cfg.sync):
            a=start+i*sps; b=a+sps
            if b>len(samples): ok=False; break
            e=tone_energies(samples[a:b],cfg)
            score+=float(e[expected]-np.mean(e))
        if ok and score>best[1]: best=(start,score)
    if best[0]<0: raise ValueError("sync not found in search window")
    return best

def decode_frame(samples: np.ndarray, cfg: Config=Config(), max_start: int|None=None) -> dict:
    start,score=find_sync(samples,cfg,max_start)
    sps=cfg.sps
    remain=max(0,(len(samples)-start)//sps-len(cfg.sync))
    syms=detect_symbols(samples,remain,cfg,start=start+len(cfg.sync)*sps)
    coded=fourfsk_to_bits(syms)
    # Payload length is protected by FEC but not known until decoding. Try each
    # allowed fixed packet length and accept only a structurally valid CRC packet.
    errors=[]
    for payload_len in range(8):
        packet_len=5+payload_len+2
        need=(packet_len*8+6)*2
        if len(coded)<need: continue
        try:
            decoded_bits=viterbi_decode(coded[:need])
            packet=bits_to_bytes(decoded_bits)
            parsed=parse_packet(packet)
            if len(parsed["payload"]) != payload_len: continue
            parsed.update({"sync_start_sample":start,"sync_score":score,"packet_bytes":packet})
            return parsed
        except (ValueError, IndexError):
            continue
    raise ValueError("no valid packet length passed header and CRC checks")

def self_test():
    cfg=Config()
    for payload in (b"",b"N2MDX",b"ARES-X"):
        p=make_packet(1,payload); frame=encode_frame(p,cfg)
        wave=synthesize(frame,cfg,snr_db=100)
        result=decode_frame(wave,cfg)
        assert result['type']==1 and result['payload']==payload,(payload,result)
    # Timing acquisition smoke test.
    p=make_packet(2,b"CQ"); wave=synthesize(encode_frame(p,cfg),cfg,timing_offset_samples=7)
    r=decode_frame(wave,cfg); assert r['payload']==b"CQ" and r['sync_start_sample']==7
    # CRC must reject corruption.
    bad=bytearray(make_packet(1,b"N2MDX")); bad[5]^=1
    try: parse_packet(bytes(bad))
    except ValueError: pass
    else: raise AssertionError("CRC failed to reject corrupted packet")
    print("PASS: packet format, CRC rejection, FEC round-trip, synchronization, timing offset")

def main():
    ap=argparse.ArgumentParser(description=VERSION)
    ap.add_argument('--test',action='store_true')
    ap.add_argument('--snr',type=float,default=100)
    ap.add_argument('--freq-offset',type=float,default=0)
    ap.add_argument('--timing-offset',type=int,default=0)
    ap.add_argument('--type',type=int,default=1)
    ap.add_argument('--payload',default='N2MDX')
    args=ap.parse_args()
    if args.test: self_test(); return
    cfg=Config(); packet=make_packet(args.type,args.payload.encode('ascii'))
    frame=encode_frame(packet,cfg)
    waveform=synthesize(frame,cfg,snr_db=args.snr,freq_offset_hz=args.freq_offset,
                        timing_offset_samples=args.timing_offset,seed=42)
    print(VERSION)
    print("LAB ONLY — not an on-air-ready mode; frequency-offset acquisition is not implemented.")
    print(f"Packet bytes: {len(packet)} | symbols: {len(frame)} | duration: {len(frame)/cfg.symbol_rate:.2f} s")
    try:
        got=decode_frame(waveform,cfg)
        print(f"Decoded type={got['type']} payload={got['payload']!r} sync_start={got['sync_start_sample']}")
    except Exception as exc:
        print(f"Decode failed: {exc}")

if __name__=='__main__': main()
