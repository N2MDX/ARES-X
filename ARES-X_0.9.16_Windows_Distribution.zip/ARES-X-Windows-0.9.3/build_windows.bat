@echo off
setlocal
cd /d "%~dp0"
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
py -m PyInstaller --noconfirm --clean --windowed --name ARES-X --hidden-import=serial.tools.list_ports --add-data "assets;assets" ares_x_windows.py
echo.
echo Build finished. Bundled Natural Earth map data is included in the application.
echo If successful, the executable is in dist\ARES-X\ARES-X.exe
pause
