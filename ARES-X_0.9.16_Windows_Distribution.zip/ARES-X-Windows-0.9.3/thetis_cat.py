"""Minimal Kenwood-compatible CAT polling for Thetis virtual COM ports."""
from __future__ import annotations
import threading, time

# Thetis/Flex CAT MD values are zero-based. Keep the raw CAT code visible
# in diagnostics so installations with a different CAT personality are easy to identify.
# Thetis configuration reported by this installation maps CAT MD6 to DIGL and MD9 to DIGU.
# Keep the other known mode labels unchanged; raw CAT MD remains visible in the GUI.
MODE_NAMES = {0:"LSB",1:"USB",2:"DSB",3:"CW",4:"FM",5:"AM",6:"DIGL",7:"CWL",8:"DIGL",9:"DIGU",10:"DRM"}

class ThetisCAT:
    def __init__(self, port: str, baudrate: int = 9600, on_update=None, on_error=None):
        self.port=port; self.baudrate=int(baudrate); self.on_update=on_update; self.on_error=on_error
        self._serial=None; self._thread=None; self._stop=threading.Event()
        self.frequency_hz=None; self.mode=None; self.mode_code=None

    def connect(self):
        try:
            import serial
        except ImportError as e:
            raise RuntimeError("pyserial is missing. Run build_windows.bat or install requirements.txt.") from e
        if self._serial: self.disconnect()
        self._serial=serial.Serial(self.port,self.baudrate,bytesize=serial.EIGHTBITS,parity=serial.PARITY_NONE,stopbits=serial.STOPBITS_ONE,timeout=0.6,write_timeout=0.6)
        self._stop.clear(); self._thread=threading.Thread(target=self._poll,daemon=True); self._thread.start()

    def _query(self, command):
        self._serial.reset_input_buffer()
        self._serial.write((command+';').encode('ascii'))
        deadline=time.monotonic()+1.0; data=bytearray()
        while time.monotonic()<deadline:
            b=self._serial.read(1)
            if b and b==b';': break
            if b: data.extend(b)
        return data.decode('ascii','ignore').strip()

    def _poll(self):
        while not self._stop.is_set() and self._serial:
            try:
                f=self._query('FA')
                m=self._query('MD')
                # Kenwood-compatible replies: FA00014074000; and MD2;
                if f.startswith('FA'):
                    digits=''.join(ch for ch in f[2:] if ch.isdigit())
                    if digits: self.frequency_hz=int(digits)
                if m.startswith('MD'):
                    code=''.join(ch for ch in m[2:] if ch.isdigit())
                    if code:
                        self.mode_code=int(code)
                        self.mode=MODE_NAMES.get(self.mode_code,f'MD{code}')
                if self.on_update: self.on_update(self.frequency_hz,self.mode)
                self._stop.wait(0.35)
            except Exception as e:
                if self.on_error: self.on_error(str(e))
                self._stop.wait(1.0)

    def set_frequency(self, frequency_hz: int):
        """Request a VFO A frequency change through Kenwood-compatible CAT."""
        if not self._serial or not self._serial.is_open:
            raise RuntimeError("Thetis CAT is not connected.")
        frequency_hz=int(frequency_hz)
        if frequency_hz < 100_000 or frequency_hz > 1_300_000_000:
            raise ValueError("Frequency is outside the supported safety range.")
        # Kenwood-compatible FA command accepts 11-digit Hz frequency.
        self._serial.write(f"FA{frequency_hz:011d};".encode("ascii"))


    def set_mode(self, mode: str):
        """Set CAT mode to CWU (Kenwood MD3) or CWL (Kenwood MD7)."""
        if not self._serial or not self._serial.is_open:
            raise RuntimeError("Thetis CAT is not connected.")
        code={"CWU":3,"CWL":7}.get(str(mode).upper())
        if code is None:
            raise ValueError("CW mode must be CWU or CWL.")
        self._serial.write(f"MD{code};".encode("ascii"))

    def disconnect(self):
        self._stop.set()
        s=self._serial; self._serial=None
        if s:
            try: s.close()
            except Exception: pass

    @staticmethod
    def available_ports():
        try:
            from serial.tools import list_ports
            return [p.device for p in list_ports.comports()]
        except Exception: return []
