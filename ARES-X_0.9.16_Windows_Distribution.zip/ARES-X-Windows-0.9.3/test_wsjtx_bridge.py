import unittest, struct
from wsjtx_bridge import QtReader, parse_decode_datagram, MAGIC

def qstr(s):
    b=s.encode("utf-8")
    return struct.pack(">I",len(b))+b

def qtime(ms):
    return struct.pack(">I",ms)

class BridgeTests(unittest.TestCase):
    def test_bad_magic_ignored(self):
        self.assertIsNone(parse_decode_datagram(b"\x00\x00\x00\x00"))

    def test_qstring(self):
        encoded = "FT8".encode("utf-16-be")
        data = struct.pack(">I", len(encoded)) + encoded
        self.assertEqual(QtReader(data).qstring(), "FT8")


    def test_wspr_decode_message(self):
        data = struct.pack(">III", MAGIC, 3, 10)
        data += qstr("WSJT-X")
        data += b"\x01"
        data += qtime((12*3600+34*60+56)*1000)
        data += struct.pack(">i", -18)
        data += struct.pack(">d", 0.5)
        data += struct.pack(">I", 14097100)
        data += qstr("K1ABC")
        data += qstr("FN31")
        data += struct.pack(">i", 37)
        item = parse_decode_datagram(data)
        self.assertEqual(item.mode, "WSPR")
        self.assertEqual(item.message, "K1ABC FN31 37 dBm")
        self.assertEqual(item.audio_hz, 14097100)

    def test_decode_message_with_client_id(self):
        # WSJT-X UDP Decode message: common header + client ID + Decode payload.
        data = struct.pack(">III", MAGIC, 3, 2)
        data += qstr("WSJT-X")
        data += b"\x01"                 # new decode
        data += qtime((12*3600+34*60+56)*1000)
        data += struct.pack(">i", -12)
        data += struct.pack(">d", 0.2)
        data += struct.pack(">I", 1500)
        data += qstr("FT8")
        data += qstr("CQ K1ABC FN31")
        data += b"\x00\x00"             # low confidence, off air
        item = parse_decode_datagram(data)
        self.assertEqual(item.mode, "FT8")
        self.assertEqual(item.message, "CQ K1ABC FN31")
        self.assertEqual(item.snr_db, -12)
        self.assertEqual(item.utc, "12:34:56")

if __name__ == "__main__":
    unittest.main()

class ReplyCommandTests(unittest.TestCase):
    def test_reply_to_cq_builds_wsjt_x_reply_packet(self):
        from wsjtx_bridge import WSJTXBridge, DecodedMessage
        class FakeSocket:
            def sendto(self, payload, addr):
                self.payload, self.addr = payload, addr
        bridge = WSJTXBridge()
        bridge._sock = FakeSocket()
        item = DecodedMessage("12:34:56", -12, 0.2, 1500, "FT8", "CQ K1ABC FN31",
                              False, False, True, "WSJT-X", ("127.0.0.1", 2237))
        target = bridge.reply_to_cq(item)
        self.assertEqual(target, ("127.0.0.1", 2237))
        packet = bridge._sock.payload
        self.assertEqual(struct.unpack(">III", packet[:12]), (MAGIC, 3, 4))
        self.assertEqual(bridge._sock.addr, ("127.0.0.1", 2237))

    def test_reply_rejects_non_cq_decode(self):
        from wsjtx_bridge import WSJTXBridge, DecodedMessage
        bridge = WSJTXBridge()
        bridge._sock = object()
        item = DecodedMessage("12:34:56", -12, 0.2, 1500, "FT8", "K1ABC N2MDX -12",
                              False, False, True, "WSJT-X", ("127.0.0.1", 2237))
        with self.assertRaises(ValueError):
            bridge.reply_to_cq(item)

class HaltTxCommandTests(unittest.TestCase):
    def test_halt_tx_builds_wsjt_x_command(self):
        from wsjtx_bridge import WSJTXBridge
        class FakeSocket:
            def sendto(self, payload, addr):
                self.payload, self.addr = payload, addr
        bridge = WSJTXBridge()
        bridge._sock = FakeSocket()
        bridge.last_source_addr = ("127.0.0.1", 2237)
        bridge.last_client_id = "WSJT-X"
        target = bridge.halt_tx()
        self.assertEqual(target, ("127.0.0.1", 2237))
        self.assertEqual(struct.unpack(">III", bridge._sock.payload[:12]), (MAGIC, 3, 8))
        self.assertEqual(bridge._sock.payload[-1], 0)
